import 'package:TheGymFaction/components/DietComponent/featured_diet_component.dart';
import 'package:TheGymFaction/utils/app_common.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../extensions/extension_util/widget_extensions.dart';
import '../../components/DietComponent/circular_chart_component.dart';
import '../../extensions/colors.dart';
import '../../extensions/text_styles.dart';
import '../../extensions/widgets.dart';
import '../../main.dart';
import '../../models/diet_list_model.dart';
import '../../network/rest_api.dart';
import 'diet_detail_screen.dart';

class DietScreen extends StatefulWidget {
  const DietScreen({super.key});

  @override
  State<DietScreen> createState() => _DietScreenState();
}

class _DietScreenState extends State<DietScreen> {
  DateFormat dateFormat = DateFormat("dd-MM-yyyy");
  List<DoughnutChart> doughnutChartData = [];

  DietListResponse dietListResponse = DietListResponse();
  List<Category> dietListData = [];
  bool checkData = false;
  bool refreshData = false;

  void fetchDietListResponse() {
    setState(() => checkData = true);
    dietListData.clear();
    getDietListResponseApi().then((value) {
      dietListResponse = value;
      for (var element in value.data!.categories!) {
        dietListData.add(element);
      }
      doughnutChartData.clear();
      if (dietListResponse.consumedCalories == 100) {
        doughnutChartData.add(DoughnutChart(
            'Consumed',
            double.parse(dietListResponse.consumedCalories!.toStringAsFixed(2)),
            '${dietListResponse.consumedCalories!.toStringAsFixed(2)}\nKcal',
            Colors.green));
      } else {
        doughnutChartData.add(DoughnutChart(
            'Consumed',
            double.parse(dietListResponse.consumedCalories!.toStringAsFixed(2)),
            '${dietListResponse.consumedCalories!.toStringAsFixed(2)}\nKcal',
            Colors.green));
        doughnutChartData.add(DoughnutChart(
            'Not Consume',
            double.parse((dietListResponse.totalCalories! -
                    dietListResponse.consumedCalories!)
                .toStringAsFixed(2)),
            '${(dietListResponse.totalCalories! - dietListResponse.consumedCalories!).toStringAsFixed(2)}\nKcal',
            black));
      }
      setState(() => checkData = false);
      return null;
    });
  }

  void fetchRefreshDietData(int id, index1) {
    setState(() => refreshData = true);
    Map<String, dynamic> req = {"diet_id": id};
    try {
      getRefreshDietApi(req).then((value) {
        if (value["success"] == true) {
          dietListData[index1].diets!.clear();
          for (var data in value["data"]) {
            DietListResponseDiet dietData = DietListResponseDiet.fromJson(data);
            dietListData[index1].diets!.add(dietData);
          }
        } else {
          toast(value["message"]);
        }
        setState(() => refreshData = false);
      });
    } catch (e) {
      toast("No Meal Plan Found");
      setState(() => refreshData = false);
    }
  }

  @override
  void initState() {
    fetchDietListResponse();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBarWidget(
        "Today Meal Plan (${dateFormat.format(DateTime.now())})",
        context: context,
        showBack: false,
        titleSpacing: 16,
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          children: [
            appStore.isLoading == true
                ? const SizedBox()
                : checkData
                    ? const SizedBox()
                    : CircularChart(
                        chartData: doughnutChartData,
                        calories: dietListResponse.consumedCalories!,
                      ),
            appStore.isLoading == true
                ? const ShimmerEffectScreen()
                : checkData
                    ? const ShimmerEffectScreen()
                    : ListView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: dietListData.length,
                        shrinkWrap: true,
                        itemBuilder: (context, index1) {
                          Category category = dietListData[index1];
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                category.categoryName!.toString(),
                                style: boldTextStyle(),
                              ),
                              category.diets!.isEmpty
                                  ? const NoDietFound()
                                  : ListView.builder(
                                      physics:
                                          const NeverScrollableScrollPhysics(),
                                      itemCount: category.diets!.length,
                                      shrinkWrap: true,
                                      itemBuilder: (context, index2) {
                                        return DietsScreen(
                                          refreshData: RefreshData(
                                            refreshOnPressed: () {
                                              fetchRefreshDietData(
                                                category.diets![index2].id!,
                                                index1,
                                              );
                                            },
                                            refreshData: refreshData,
                                          ),
                                          diets: category.diets![index2],
                                          onTap: () {
                                            DietDetailScreen(
                                              dietModel:
                                                  category.diets![index2],
                                            ).launch(context).then((value) {
                                              if (value) {
                                                fetchDietListResponse();
                                              }
                                              return null;
                                            });
                                          },
                                        );
                                      },
                                    ),
                            ],
                          );
                        },
                      ),
          ],
        ).paddingSymmetric(horizontal: 15),
      ),
    );
  }
}

class RefreshData extends StatelessWidget {
  const RefreshData(
      {super.key, this.refreshOnPressed, required this.refreshData});
  final void Function()? refreshOnPressed;
  final bool refreshData;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topRight,
      child: IconButton(
        onPressed: refreshOnPressed,
        icon: const CircleAvatar(
          backgroundColor: black,
          child: Icon(
            Icons.refresh,
            color: whiteColor,
          ),
        ),
      ).paddingSymmetric(horizontal: 4),
    );
    // return refreshData
    //     ? Align(
    //         alignment: Alignment.topRight,
    //         child: IconButton(
    //           onPressed: () {},
    //           icon: CircleAvatar(
    //             backgroundColor: black,
    //             child: Transform.scale(
    //               scale: 0.6,
    //               child: const CircularProgressIndicator(
    //                 color: whiteColor,
    //               ),
    //             ),
    //           ),
    //         ).paddingSymmetric(horizontal: 4),
    //       )
    //     : Align(
    //         alignment: Alignment.topRight,
    //         child: IconButton(
    //           onPressed: refreshOnPressed,
    //           icon: const CircleAvatar(
    //             backgroundColor: black,
    //             child: Icon(
    //               Icons.refresh,
    //               color: whiteColor,
    //             ),
    //           ),
    //         ).paddingSymmetric(horizontal: 4),
    //       );
  }
}

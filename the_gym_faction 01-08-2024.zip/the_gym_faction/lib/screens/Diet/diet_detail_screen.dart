import 'package:TheGymFaction/extensions/extension_util/context_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/double_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/string_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_vector_icons/flutter_vector_icons.dart';

import '../../components/HtmlWidget.dart';
import '../../extensions/app_button.dart';
import '../../extensions/colors.dart';
import '../../extensions/constants.dart';
import '../../extensions/system_utils.dart';
import '../../extensions/text_styles.dart';
import '../../main.dart';
import '../../models/diet_list_model.dart';
import '../../models/diet_response.dart';
import '../../network/rest_api.dart';
import '../../utils/app_colors.dart';
import '../../utils/app_common.dart';
import '../../utils/app_images.dart';

class DietDetailScreen extends StatefulWidget {
  final DietListResponseDiet? dietModel;
  final Function? onCall;
  final bool? isCategory;
  final bool? isFeatured;

  const DietDetailScreen({
    super.key,
    this.dietModel,
    this.onCall,
    this.isFeatured,
    this.isCategory,
  });

  @override
  State<DietDetailScreen> createState() => _DietDetailScreenState();
}

class _DietDetailScreenState extends State<DietDetailScreen> {
  bool select = true;
  bool setData = false;
  int page = 1;
  int? numPage;
  bool isLastPage = false;
  List<DietModel> mDietList = [];

  @override
  void initState() {
    super.initState();
  }

  Future<void> setDiet(int? id) async {
    appStore.setLoading(true);
    Map req = {"diet_id": id};
    await setDietFavApi(req).then((value) {
      toast(value.message);
      appStore.setLoading(false);
      setState(() {});
    }).catchError((e) {
      appStore.setLoading(false);
      setState(() {});
    });
  }

  void setDietConsumedData() {
    setState(() => setData = true);
    Map<String, dynamic> req = {"diet_id": widget.dietModel!.id};
    setDietConsumedApi(req).then((value) {
      Navigator.pop(context, true);
      setState(() => setData = false);
      return;
    });
  }

  @override
  Widget build(BuildContext context) {
    // final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      bottomNavigationBar: widget.dietModel!.consumed == 1
          ? Container(
              alignment: Alignment.center,
              height: 50,
              width: w,
              decoration: BoxDecoration(
                color: Colors.green,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Consumed",
                    style: boldTextStyle(
                      color: whiteColor,
                    ),
                  ),
                  10.width,
                  const CircleAvatar(
                    radius: 10,
                    backgroundColor: whiteColor,
                    child: Icon(
                      size: 16,
                      Icons.done,
                      color: Colors.green,
                    ),
                  ),
                ],
              ),
            ).paddingSymmetric(vertical: 20, horizontal: 20)
          : setData == true
              ? MaterialButton(
                  height: 50,
                  shape: defaultAppButtonShapeBorder,
                  color: appButtonBackgroundColorGlobal,
                  minWidth: context.width(),
                  onPressed: () {},
                  child: Transform.scale(
                    scale: 0.7,
                    child: const CircularProgressIndicator(
                      color: white,
                    ),
                  ),
                ).paddingSymmetric(vertical: 18, horizontal: 20)
              : AppButton(
                  text: languages.consumeFood,
                  onTap: () {
                    setDietConsumedData();
                  },
                ).paddingSymmetric(vertical: 20, horizontal: 20),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                cachedImage(widget.dietModel!.image!.validate(),
                    width: context.width(),
                    height: context.height() * 0.37,
                    fit: BoxFit.cover),
                Positioned(
                    top: context.statusBarHeight,
                    left: 0,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        IconButton(
                          onPressed: () {
                            finish(context);
                          },
                          icon: Icon(
                              appStore.selectedLanguageCode == 'ar'
                                  ? MaterialIcons.arrow_forward_ios
                                  : Octicons.chevron_left,
                              color: whiteColor),
                        ),
                      ],
                    )),
                Positioned(
                  left: 16,
                  right: 16,
                  bottom: 40,
                  child: Text(
                    widget.dietModel!.title.validate(),
                    style: boldTextStyle(color: Colors.white, size: 20),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            8.height,
            Row(
              children: [
                getVitamins(
                        ic_calories,
                        "${widget.dietModel!.caloriesForOne!.validate()} ${languages.lblKcal}",
                        languages.lblCalories)
                    .expand(),
                dividerHorizontalLine(),
                getVitamins(
                        ic_carbs,
                        "${widget.dietModel!.carbs.validate()} ${languages.lblG}",
                        languages.lblCarbs)
                    .expand(),
                dividerHorizontalLine(),
                getVitamins(
                        ic_fat,
                        "${widget.dietModel!.fat.validate()} ${languages.lblG}",
                        languages.lblFat)
                    .expand(),
                dividerHorizontalLine(),
                getVitamins(
                        ic_protein,
                        "${widget.dietModel!.protein.validate()} ${languages.lblG}",
                        languages.lblProtein)
                    .expand(),
              ],
            ).paddingSymmetric(horizontal: 10, vertical: 8),
            Divider(
                color:
                    appStore.isDarkMode ? Colors.white : context.dividerColor,
                indent: 16,
                endIndent: 16,
                height: 0.5),
            16.height,
            Row(
              children: [
                15.width,
                const Icon(Feather.clock, size: 16).paddingRight(4),
                Text(
                  "From Making This Recipe You Need ${widget.dietModel!.totalTime.validate()} Minutes",
                  style: boldTextStyle(size: 12),
                ),
              ],
            ),
            Container(
              padding: const EdgeInsets.only(top: 22),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          color: appStore.isDarkMode
                              ? whiteColor
                              : context.dividerColor,
                          width: 0.5))),
              child: Row(children: [
                Container(
                        padding: const EdgeInsets.only(bottom: 8),
                        decoration: BoxDecoration(
                            border: Border(
                                bottom: BorderSide(
                                    width: 1.5,
                                    color: select
                                        ? primaryColor
                                        : Colors.transparent))),
                        child: Text(languages.lblIngredients,
                                style: boldTextStyle(
                                    color: select
                                        ? primaryColor
                                        : textSecondaryColorGlobal))
                            .center())
                    .onTap(() {
                  setState(() {
                    select = !select;
                  });
                }).expand(),
                Container(
                  padding: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(
                      border: Border(
                          bottom: BorderSide(
                              width: 1.5,
                              color:
                                  select ? Colors.transparent : primaryColor))),
                  child: Text(languages.lblInstruction,
                          style: boldTextStyle(
                              color: select
                                  ? textSecondaryColorGlobal
                                  : primaryColor))
                      .center(),
                ).onTap(() {
                  setState(() {
                    select = !select;
                  });
                }).expand(),
              ]).paddingSymmetric(horizontal: 16),
            ),
            16.height,
            select ? ingredients() : instruction()
          ],
        ).paddingOnly(bottom: 16),
      ),
    );
  }

  Widget getVitamins(String image, String title, String subTitle) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Image.asset(image,
            height: 26, width: 26, fit: BoxFit.contain, color: primaryColor),
        8.height,
        Text(title, style: boldTextStyle(), textAlign: TextAlign.center),
        4.height,
        Text(subTitle, style: secondaryTextStyle()),
      ],
    );
  }

  Widget getIngredients(String title) {
    return Text(title, style: primaryTextStyle(color: scaffoldBackgroundColor));
  }

  Widget ingredients() {
    return HtmlWidget(postContent: widget.dietModel!.ingredients.toString())
        .paddingSymmetric(horizontal: 8);
  }

  Widget instruction() {
    return HtmlWidget(postContent: widget.dietModel!.description.toString())
        .paddingSymmetric(horizontal: 8);
  }

  Widget dividerHorizontalLine() {
    return SizedBox(
      height: 65,
      child: VerticalDivider(
          color: context.dividerColor,
          width: 10,
          thickness: 1,
          indent: 10,
          endIndent: 10),
    );
  }
}

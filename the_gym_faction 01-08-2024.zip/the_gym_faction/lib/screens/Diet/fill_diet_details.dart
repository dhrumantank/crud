import 'package:TheGymFaction/extensions/app_button.dart';
import 'package:TheGymFaction/extensions/app_text_field.dart';
import 'package:TheGymFaction/extensions/colors.dart';
import 'package:TheGymFaction/extensions/decorations.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/string_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:TheGymFaction/models/user_target_details_model.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:TheGymFaction/utils/app_colors.dart';
import 'package:animation_list/animation_list.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../../extensions/widgets.dart';
import '../../main.dart';
import '../../utils/app_common.dart';
import '../dashboard_screen.dart';

class FillDietDetails extends StatefulWidget {
  const FillDietDetails({super.key, this.title});
  final String? title;

  @override
  State<FillDietDetails> createState() => _FillDietDetailsState();
}

class _FillDietDetailsState extends State<FillDietDetails> {
  int newValue = -1;
  int goalValue = -1;
  List selectFood = [];
  List selectAllergy = [];
  ScrollController scrollController = ScrollController();
  TextEditingController weightController = TextEditingController();
  TextEditingController heightController = TextEditingController();
  UserTargetDetails userTargetDetails =
      UserTargetDetails(allergy: [], eatType: [], foodCategory: [], goal: []);
  bool getData = false;
  bool addData = false;

  void fetchUserTargetDetails() {
    setState(() => getData = true);
    getUserTargetDetailsApi().then((value) {
      userTargetDetails = value;
      if (value.userProfile!.weight != null) {
        weightController.text = value.userProfile!.weight.toString();
      }
      if (value.userProfile!.height != null) {
        heightController.text = value.userProfile!.height.toString();
      }
      setState(() => getData = false);
      return;
    });
  }

  void fetchUserDietTargetDetailsEditData() {
    setState(() => getData = true);
    getUserDietTargetDetailsEditApi().then((value) {
      userTargetDetails = value;
      if (widget.title == "Diet") {
        if (value.userProfile!.weight != null) {
          weightController.text = value.userProfile!.weight.toString();
        }
        if (value.userProfile!.height != null) {
          heightController.text = value.userProfile!.height.toString();
        }
      }
      setState(() => getData = false);
      return;
    });
  }

  int goalIndex = 0;
  int eatTypeIndex = 0;

  void fetchUserDietTargetDetailsShowData() {
    getUserDietTargetDetailsShowApi().then((value) {
      if (value.userProfile!.weight != null) {
        weightController.text = value.userProfile!.weight.toString();
      }
      if (value.userProfile!.height != null) {
        heightController.text = value.userProfile!.height.toString();
      }
      for (var element in value.goal!) {
        if (element.status == true) {
          goalValue = goalIndex;
          break;
        } else {
          goalIndex++;
        }
      }
      for (var element in value.eatType!) {
        if (element.status == true) {
          newValue = eatTypeIndex;
        } else {
          eatTypeIndex++;
        }
      }
      for (var element in value.foodCategory!) {
        selectFood.add(element.id!);
      }
      for (var element in value.allergy!) {
        selectAllergy.add(element.id!);
      }
      setState(() {});
    });
  }

  void save() {
    setState(() => addData = true);
    if (weightController.text.isNotEmpty &&
        heightController.text.isNotEmpty &&
        newValue >= 0 &&
        goalValue >= 0 &&
        selectFood.isNotEmpty &&
        selectAllergy.isNotEmpty) {
      Map<String, dynamic> req = {
        "height": heightController.text,
        "weight": weightController.text,
        "goal": userTargetDetails.goal![goalValue].id,
        "eat_type": userTargetDetails.eatType![newValue].id,
        "food_category": selectFood,
        "allergy": selectAllergy,
      };
      setUserDietTargetDetailsUpdateApi(req).then((value) async {
        await userStore.setWeight(weightController.text.validate());
        await userStore.setHeight(heightController.text.validate());
        setLogInValue();
        if (widget.title == "Diet") {
          const DashboardScreen(mCurrentIndex: 2).launch(context);
        } else {
          Navigator.pop(context, true);
        }
        setState(() => addData = false);
        return null;
      });
    } else if (weightController.text.isEmpty) {
      setState(() => addData = false);
      toast("Pleas Enter Weight");
    } else if (heightController.text.isEmpty) {
      setState(() => addData = false);
      toast("Pleas Enter Height");
    } else if (goalValue < 0) {
      setState(() => addData = false);
      toast("Pleas Select Your Goal");
    } else if (newValue < 0) {
      setState(() => addData = false);
      toast("Pleas Select Your Eat Type");
    } else if (selectFood.isEmpty) {
      setState(() => addData = false);
      toast("Pleas Select Food Category");
    } else if (selectAllergy.isEmpty) {
      setState(() => addData = false);
      toast("Pleas Select Allergy");
    }
  }

  @override
  void initState() {
    if (widget.title == "Diet") {
      fetchUserTargetDetails();
    } else if (widget.title == "Profile") {
      fetchUserDietTargetDetailsEditData();
      fetchUserDietTargetDetailsShowData();
    }
    super.initState();
  }

  Widget textWithDone({required String title}) {
    return Text.rich(
      TextSpan(
        text: title,
        children: const [
          WidgetSpan(
            child: SizedBox(
              width: 10,
            ),
          ),
          WidgetSpan(
            child: CircleAvatar(
              radius: 9,
              backgroundColor: whiteColor,
              child: Icon(
                Icons.done,
                size: 15,
                color: Colors.green,
              ),
            ),
          ),
        ],
      ),
      style: boldTextStyle(size: 14, color: whiteColor),
    ).paddingSymmetric(horizontal: 13, vertical: 8);
  }

  Widget text({required String title}) {
    return Text(
      title,
      style: boldTextStyle(size: 14, color: whiteColor),
    ).paddingSymmetric(horizontal: 13, vertical: 8);
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Scaffold(
      bottomSheet: AppButton(
        onTap: () {
          save();
        },
        color: appRedColor,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              languages.lblContinue,
              style: boldTextStyle(color: whiteColor),
            ),
            10.width,
            const CircleAvatar(
              radius: 12,
              backgroundColor: whiteColor,
              child: Icon(
                size: 16,
                Icons.arrow_forward,
                color: appRedColor,
              ),
            )
          ],
        ),
      ).paddingSymmetric(vertical: 10, horizontal: 30),
      // bottomNavigationBar: AppButton(
      //   onTap: () {
      //     save();
      //   },
      //   color: appRedColor,
      //   child: Row(
      //     mainAxisAlignment: MainAxisAlignment.center,
      //     children: [
      //       Text(
      //         languages.lblContinue,
      //         style: boldTextStyle(color: whiteColor),
      //       ),
      //       10.width,
      //       const CircleAvatar(
      //         radius: 12,
      //         backgroundColor: whiteColor,
      //         child: Icon(
      //           size: 16,
      //           Icons.arrow_forward,
      //           color: appRedColor,
      //         ),
      //       )
      //     ],
      //   ),
      // ).paddingSymmetric(vertical: 10, horizontal: 30),
      appBar: appBarWidget(
        widget.title == "Diet"
            ? "Fill Details For Daily Diet Plans"
            : "Edit Details For Daily Diet Plans",
        context: context,
        titleSpacing: 16,
      ),
      body: getData == true
          ? const ShimmerEffectScreen()
          : SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Enter Weight And Height",
                    style: boldTextStyle(size: 14),
                  ),
                  (h * 0.02).toInt().height,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: w * 0.4,
                        child: AppTextField(
                          controller: weightController,
                          textFieldType: TextFieldType.NUMBER,
                          decoration: defaultInputDecoration(context,
                              label: "Enter Weight", suffix: const Text("Kg")),
                        ),
                      ),
                      SizedBox(
                        width: w * 0.4,
                        child: AppTextField(
                          controller: heightController,
                          textFieldType: TextFieldType.NUMBER,
                          decoration: defaultInputDecoration(context,
                              label: "Enter Height", suffix: const Text("cm")),
                        ),
                      ),
                    ],
                  ),
                  (h * 0.02).toInt().height,
                  Text(
                    "Select Goal",
                    style: boldTextStyle(size: 14),
                  ),
                  (h * 0.02).toInt().height,
                  AnimationList(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    controller: scrollController,
                    duration: 4000,
                    children:
                        List.generate(userTargetDetails.goal!.length, (index) {
                      return Row(
                        children: [
                          Radio(
                            value: index,
                            groupValue: goalValue,
                            onChanged: (value) {
                              setState(() {
                                goalValue = value!;
                              });
                            },
                          ),
                          Text(
                            userTargetDetails.goal![index].title.toString(),
                          ),
                        ],
                      );
                    }),
                  ),
                  (h * 0.02).toInt().height,
                  Text(
                    "Select Eat Type",
                    style: boldTextStyle(size: 14),
                  ),
                  (h * 0.02).toInt().height,
                  AnimationList(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    controller: scrollController,
                    duration: 4000,
                    children: List.generate(userTargetDetails.eatType!.length,
                        (index) {
                      return Row(
                        children: [
                          Radio(
                            value: index,
                            groupValue: newValue,
                            onChanged: (value) {
                              setState(() {
                                newValue = value!;
                              });
                            },
                          ),
                          Text(
                            userTargetDetails.eatType![index].title.toString(),
                          ),
                        ],
                      );
                    }),
                  ),
                  (h * 0.02).toInt().height,
                  Text(
                    "Select Food Category",
                    style: boldTextStyle(size: 14),
                  ),
                  (h * 0.02).toInt().height,
                  AnimationList(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    controller: scrollController,
                    duration: 4000,
                    children: [
                      Wrap(
                        children: List.generate(
                            userTargetDetails.foodCategory!.length, (index) {
                          bool checkValue = selectFood.contains(
                              userTargetDetails.foodCategory![index].id);
                          return Container(
                            decoration: BoxDecoration(
                              color: checkValue ? Colors.green : black,
                              borderRadius: BorderRadius.circular(30),
                            ),
                            child: checkValue
                                ? textWithDone(
                                    title: userTargetDetails
                                        .foodCategory![index].title!,
                                  )
                                : text(
                                    title: userTargetDetails
                                        .foodCategory![index].title!),
                          ).onTap(() {
                            if (!checkValue) {
                              selectFood.add(
                                  userTargetDetails.foodCategory![index].id);
                              setState(() {});
                            } else {
                              selectFood.remove(
                                  userTargetDetails.foodCategory![index].id);
                              setState(() {});
                            }
                          }).paddingSymmetric(vertical: 5, horizontal: 5);
                        }),
                      )
                    ],
                  ),
                  (h * 0.02).toInt().height,
                  Text(
                    "Select Allergy",
                    style: boldTextStyle(size: 14),
                  ),
                  (h * 0.02).toInt().height,
                  AnimationList(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    controller: scrollController,
                    duration: 4000,
                    children: [
                      Wrap(
                        children: List.generate(
                            userTargetDetails.allergy!.length, (index) {
                          bool checkValue = selectAllergy
                              .contains(userTargetDetails.allergy![index].id);
                          String title =
                              userTargetDetails.allergy![index].title!;
                          int id = userTargetDetails.allergy![index].id!;
                          return Container(
                            decoration: BoxDecoration(
                              color: checkValue ? Colors.green : black,
                              borderRadius: BorderRadius.circular(30),
                            ),
                            child: checkValue
                                ? textWithDone(title: title)
                                : text(title: title),
                          ).onTap(() {
                            if (id == 1) {
                              selectAllergy.clear();
                              selectAllergy.add(id);
                            } else if (!checkValue) {
                              if (id != 1) {
                                selectAllergy.remove(1);
                                selectAllergy.add(id);
                              }
                            } else {
                              selectAllergy.remove(id);
                            }
                            setState(() {});
                          }).paddingSymmetric(vertical: 5, horizontal: 5);
                        }),
                      )
                    ],
                  ),
                  (h * 0.1).toInt().height,
                ],
              ).paddingSymmetric(horizontal: 20),
            ),
    );
  }
}

class ShimmerEffectScreen extends StatelessWidget {
  const ShimmerEffectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Shimmer.fromColors(
              baseColor: Colors.grey.shade300,
              highlightColor: Colors.white54,
              child: Container(
                width: w * 0.5,
                height: h * 0.03,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: Colors.grey.shade300,
                ),
              )),
          (h * 0.02).toInt().height,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Shimmer.fromColors(
                  baseColor: Colors.grey.shade300,
                  highlightColor: Colors.white54,
                  child: Container(
                    width: w * 0.4,
                    height: h * 0.055,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey.shade300,
                    ),
                  )),
              Shimmer.fromColors(
                  baseColor: Colors.grey.shade300,
                  highlightColor: Colors.white54,
                  child: Container(
                    width: w * 0.4,
                    height: h * 0.055,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey.shade300,
                    ),
                  )),
            ],
          ),
          (h * 0.02).toInt().height,
          Shimmer.fromColors(
              baseColor: Colors.grey.shade300,
              highlightColor: Colors.white54,
              child: Container(
                width: w * 0.3,
                height: h * 0.03,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: Colors.grey.shade300,
                ),
              )),
          (h * 0.02).toInt().height,
          Column(
            children: List.generate(3, (index) {
              return Row(
                children: [
                  10.width,
                  Shimmer.fromColors(
                      baseColor: Colors.grey.shade300,
                      highlightColor: Colors.white54,
                      child: Container(
                        width: w * 0.5,
                        height: h * 0.04,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: Colors.grey.shade300,
                        ),
                      )),
                ],
              ).paddingSymmetric(vertical: 5);
            }),
          ),
          (h * 0.02).toInt().height,
          Shimmer.fromColors(
            baseColor: Colors.grey.shade300,
            highlightColor: Colors.white54,
            child: Container(
              width: w * 0.4,
              height: h * 0.03,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: Colors.grey.shade300,
              ),
            ),
          ),
          (h * 0.02).toInt().height,
          Column(
            children: List.generate(3, (index) {
              return Row(
                children: [
                  10.width,
                  Shimmer.fromColors(
                      baseColor: Colors.grey.shade300,
                      highlightColor: Colors.white54,
                      child: Container(
                        width: w * 0.5,
                        height: h * 0.04,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: Colors.grey.shade300,
                        ),
                      )),
                ],
              ).paddingSymmetric(vertical: 5);
            }),
          ),
          (h * 0.02).toInt().height,
          Shimmer.fromColors(
              baseColor: Colors.grey.shade300,
              highlightColor: Colors.white54,
              child: Container(
                width: w * 0.4,
                height: h * 0.03,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: Colors.grey.shade300,
                ),
              )),
          (h * 0.02).toInt().height,
          Wrap(
            children: List.generate(6, (index) {
              return Shimmer.fromColors(
                baseColor: Colors.grey.shade300,
                highlightColor: Colors.white54,
                child: Container(
                  width: w * 0.25,
                  height: h * 0.04,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(30),
                  ),
                ).paddingSymmetric(vertical: 5, horizontal: 5),
              );
            }),
          ),
          (h * 0.02).toInt().height,
          Shimmer.fromColors(
              baseColor: Colors.grey.shade300,
              highlightColor: Colors.white54,
              child: Container(
                width: w * 0.4,
                height: h * 0.03,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: Colors.grey.shade300,
                ),
              )),
          (h * 0.02).toInt().height,
          Wrap(
            children: List.generate(6, (index) {
              return Shimmer.fromColors(
                baseColor: Colors.grey.shade300,
                highlightColor: Colors.white54,
                child: Container(
                  width: w * 0.25,
                  height: h * 0.04,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(30),
                  ),
                ).paddingSymmetric(vertical: 5, horizontal: 5),
              );
            }),
          ),
        ],
      ).paddingSymmetric(horizontal: 20),
    );
  }
}

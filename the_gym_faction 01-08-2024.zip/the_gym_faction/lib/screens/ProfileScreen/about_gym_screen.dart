import 'package:TheGymFaction/extensions/colors.dart';
import 'package:TheGymFaction/extensions/extension_util/context_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:TheGymFaction/models/gym_all_details_model.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:TheGymFaction/utils/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_stars/flutter_rating_stars.dart';

import '../../extensions/constants.dart';
import '../../main.dart';
import '../../utils/app_common.dart';

class AboutGymScreen extends StatefulWidget {
  const AboutGymScreen({super.key});

  @override
  State<AboutGymScreen> createState() => _AboutGymScreenState();
}

class _AboutGymScreenState extends State<AboutGymScreen> {
  PageController controller = PageController(initialPage: 0);
  GymAllDetails gymAllDetails = GymAllDetails(
    coach: [],
    review: [],
  );
  int selectIndex = 0;
  bool select = true;
  bool getData = false;

  void fetchGymAllDetailsData() {
    setState(() => getData = true);
    getGymAllDetailsApi().then((value) {
      gymAllDetails = value;
      setState(() => getData = false);
    });
  }

  @override
  void initState() {
    fetchGymAllDetailsData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      body: getData
          ? Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                (h * 0.022).toInt().height,
                ListTile(
                  leading: IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(
                      Icons.arrow_back_ios_new,
                      color: black,
                    ),
                  ),
                  title: Text(
                    "Gym Details",
                    style: boldTextStyle(color: black),
                  ).paddingSymmetric(horizontal: 70),
                ),
                (h * 0.38).toInt().height,
                const CircularProgressIndicator().center(),
              ],
            )
          : Stack(
              clipBehavior: Clip.none,
              children: [
                Column(
                  children: [
                    Stack(
                      children: [
                        SizedBox(
                          height: h * 0.43,
                          width: w,
                          child: cachedImage(gymAllDetails.gymDetails!.logo!,
                              fit: BoxFit.fill),
                        ),
                        Positioned(
                          top: 30,
                          left: 20,
                          child: IconButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            icon: const CircleAvatar(
                              backgroundColor: Colors.black,
                              child: Icon(
                                Icons.arrow_back_ios_new,
                                color: Colors.white,
                                size: 15,
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                    (h * 0.1).toInt().height,
                    CustomTabBar(
                      select: select,
                      fistOnTap: () {
                        setState(() {
                          select = !select;
                        });
                      },
                      secondOnTap: () {
                        setState(() {
                          select = !select;
                        });
                      },
                    ),
                    Expanded(
                      child: select
                          ? CoachDetails(
                              coachDetails: gymAllDetails.coach!,
                            )
                          : ReviewScreen(
                              reviewDetails: gymAllDetails.review!,
                            ),
                    ),
                  ],
                ),
                Positioned(
                  top: h * 0.38,
                  child: Container(
                    constraints: BoxConstraints(maxHeight: h * 0.15),
                    width: w,
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          offset: const Offset(1, -5),
                          color: Colors.grey.shade200,
                          // spreadRadius: 1,
                          blurRadius: 10,
                        )
                      ],
                      color: Colors.white,
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(40),
                      ),
                    ),
                    child: Column(
                      children: [
                        20.height,
                        Row(
                          children: [
                            20.width,
                            CircleAvatar(
                              backgroundColor: Colors.transparent,
                              radius: 40,
                              child: cachedImage(
                                gymAllDetails.gymDetails!.logo!,
                                fit: BoxFit.fill,
                              ).cornerRadiusWithClipRRect(80),
                            ),
                            10.width,
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  constraints:
                                      BoxConstraints(maxWidth: w * 0.7),
                                  child: Text(
                                    gymAllDetails.gymDetails!.gymName!,
                                    style: boldTextStyle(),
                                  ),
                                ),
                                2.height,
                                Container(
                                  constraints:
                                      BoxConstraints(maxWidth: w * 0.7),
                                  child: Text(
                                    gymAllDetails.gymDetails!.phoneNumber!,
                                    style: boldTextStyle(),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

class CoachDetails extends StatelessWidget {
  const CoachDetails({super.key, required this.coachDetails});
  final List<Coach> coachDetails;

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        children: [
          10.height,
          ListView.builder(
            padding: EdgeInsets.zero,
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: coachDetails.length,
            itemBuilder: (context, index) {
              Coach coach = coachDetails[index];
              return Container(
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade300,
                      spreadRadius: 2,
                      blurRadius: 10,
                    )
                  ],
                  borderRadius: BorderRadius.circular(10),
                  color: whiteColor,
                ),
                child: ListTile(
                  leading: Container(
                    height: h * 0.07,
                    width: w * 0.14,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(80),
                    ),
                    child:
                        cachedImage(coach.image!).cornerRadiusWithClipRRect(80),
                  ),
                  title: Text(
                    coach.name!.toString(),
                    style: boldTextStyle(),
                  ),
                ).paddingSymmetric(vertical: 10),
              ).paddingSymmetric(vertical: 5, horizontal: 10);
            },
          ),
          20.height,
        ],
      ),
    );
  }
}

class ReviewScreen extends StatelessWidget {
  const ReviewScreen({super.key, required this.reviewDetails});
  final List<Review> reviewDetails;

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        children: [
          10.height,
          ListView.builder(
            padding: EdgeInsets.zero,
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: reviewDetails.length,
            itemBuilder: (context, index) {
              Review review = reviewDetails[index];
              return Container(
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade300,
                      spreadRadius: 2,
                      blurRadius: 10,
                    )
                  ],
                  borderRadius: BorderRadius.circular(10),
                  color: whiteColor,
                ),
                child: ListTile(
                  leading: Container(
                    height: h * 0.07,
                    width: w * 0.14,
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(80),
                    ),
                    child: cachedImage(review.image!)
                        .cornerRadiusWithClipRRect(80),
                  ),
                  title: Text(
                    review.name!.toString(),
                    style: boldTextStyle(),
                  ),
                  subtitle: Text(
                    review.review!.toString(),
                    style: boldTextStyle(),
                  ),
                  trailing: RatingStars(
                    value: double.parse(review.rate!),
                    valueLabelVisibility: false,
                  ),
                ).paddingSymmetric(vertical: 10),
              ).paddingSymmetric(vertical: 5, horizontal: 10);
            },
          ),
          20.height,
        ],
      ),
    );
  }
}

class CustomTabBar extends StatelessWidget {
  const CustomTabBar(
      {super.key, required this.select, this.fistOnTap, this.secondOnTap});
  final bool select;
  final void Function()? fistOnTap;
  final void Function()? secondOnTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(top: 22),
      decoration: BoxDecoration(
          border: Border(
              bottom: BorderSide(
                  color:
                      appStore.isDarkMode ? whiteColor : context.dividerColor,
                  width: 0.5))),
      child: Row(children: [
        GestureDetector(
          onTap: fistOnTap,
          child: Container(
              padding: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          width: 1.5,
                          color: select ? primaryColor : Colors.transparent))),
              child: Text(
                "Coach",
                style: boldTextStyle(
                  color: select ? primaryColor : textSecondaryColorGlobal,
                ),
              ).center()),
        ).expand(),
        GestureDetector(
          onTap: secondOnTap,
          child: Container(
            padding: const EdgeInsets.only(bottom: 8),
            decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(
                        width: 1.5,
                        color: select ? Colors.transparent : primaryColor))),
            child: Text("Review",
                    style: boldTextStyle(
                        color:
                            select ? textSecondaryColorGlobal : primaryColor))
                .center(),
          ),
        ).expand(),
      ]).paddingSymmetric(horizontal: 16),
    );
  }
}

// Container(
//   width: w,
//   color: whiteColor,
//   child: Column(
//     children: [
//       (h * 0.022).toInt().height,
//       ListTile(
//         leading: IconButton(
//           onPressed: () {
//             Navigator.pop(context);
//           },
//           icon: const Icon(
//             Icons.arrow_back_ios_new,
//             color: black,
//           ),
//         ),
//         title: Text(
//           "Gym Details",
//           style: boldTextStyle(color: black),
//         ).paddingSymmetric(horizontal: 70),
//       ),
//       (h * 0.015).toInt().height,
//       Container(
//         width: w * 0.3,
//         height: h * 0.14,
//         decoration: BoxDecoration(
//           image: DecorationImage(
//             image:
//                 NetworkImage(gymAllDetails.gymDetails!.logo!),
//             fit: BoxFit.fill,
//           ),
//           borderRadius: BorderRadius.circular(80),
//         ),
//       ),
//       (h * 0.01).toInt().height,
//       Container(
//         width: w * 0.85,
//         decoration: BoxDecoration(
//           color: redColor,
//           borderRadius: BorderRadius.circular(8),
//         ),
//         child: Row(
//           children: [
//             10.width,
//             const ImageIcon(
//               AssetImage(gym),
//               color: whiteColor,
//               size: 17,
//             ),
//             10.width,
//             Text(
//               "Gym Name",
//               style: boldTextStyle(size: 12, color: whiteColor),
//             ).paddingSymmetric(vertical: 13),
//             const Spacer(),
//             Text(
//               gymAllDetails.gymDetails!.gymName!,
//               style: boldTextStyle(size: 12, color: whiteColor),
//             ).paddingSymmetric(vertical: 13),
//             10.width,
//           ],
//         ),
//       ),
//       (h * 0.01).toInt().height,
//       Container(
//         width: w * 0.85,
//         decoration: BoxDecoration(
//           color: redColor,
//           borderRadius: BorderRadius.circular(8),
//         ),
//         child: Row(
//           children: [
//             10.width,
//             const ImageIcon(
//               AssetImage(ic_user),
//               color: whiteColor,
//               size: 17,
//             ),
//             10.width,
//             Text(
//               "Gym Owner Name",
//               style: boldTextStyle(size: 12, color: whiteColor),
//             ).paddingSymmetric(vertical: 13),
//             const Spacer(),
//             Text(
//               gymAllDetails.gymDetails!.ownerName!,
//               style: boldTextStyle(size: 12, color: whiteColor),
//             ).paddingSymmetric(vertical: 13),
//             10.width,
//           ],
//         ),
//       ),
//       (h * 0.01).toInt().height,
//       Container(
//         width: w * 0.85,
//         decoration: BoxDecoration(
//           color: redColor,
//           borderRadius: BorderRadius.circular(8),
//         ),
//         child: Row(
//           children: [
//             10.width,
//             const ImageIcon(
//               AssetImage(telephone1),
//               color: whiteColor,
//               size: 17,
//             ),
//             10.width,
//             Text(
//               "Gym Number",
//               style: boldTextStyle(size: 12, color: whiteColor),
//             ).paddingSymmetric(vertical: 13),
//             const Spacer(),
//             Text(
//               gymAllDetails.gymDetails!.phoneNumber!,
//               style: boldTextStyle(size: 12, color: whiteColor),
//             ).paddingSymmetric(vertical: 13),
//             10.width,
//           ],
//         ),
//       ),
//       (h * 0.01).toInt().height,
//       Container(
//         width: w * 0.85,
//         decoration: BoxDecoration(
//           color: redColor,
//           borderRadius: BorderRadius.circular(8),
//         ),
//         child: Row(
//           children: [
//             10.width,
//             const ImageIcon(
//               AssetImage(location),
//               color: whiteColor,
//               size: 17,
//             ),
//             10.width,
//             Container(
//               constraints: BoxConstraints(maxWidth: w * 0.72),
//               child: Text(
//                 gymAllDetails.gymDetails!.address!,
//                 style:
//                     boldTextStyle(size: 12, color: whiteColor),
//               ).paddingSymmetric(vertical: 13),
//             ),
//             10.width,
//           ],
//         ),
//       ),
//       (h * 0.01).toInt().height,
//     ],
//   ),
// ),

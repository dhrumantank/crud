import 'package:TheGymFaction/screens/ProfileScreen/SettingScreen/notification_setting_screen.dart';
import 'package:TheGymFaction/screens/ProfileScreen/account_delete_screen.dart';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_mobx/flutter_mobx.dart';

import '../../../extensions/constants.dart';
import '../../../extensions/extension_util/context_extensions.dart';
import '../../../extensions/extension_util/int_extensions.dart';
import '../../../extensions/extension_util/string_extensions.dart';
import '../../../extensions/extension_util/widget_extensions.dart';
import '../../../extensions/system_utils.dart';
import '../../extensions/colors.dart';
import '../../extensions/common.dart';
import '../../extensions/confirmation_dialog.dart';
import '../../extensions/decorations.dart';
import '../../extensions/shared_pref.dart';
import '../../extensions/text_styles.dart';
import '../../main.dart';
import '../../network/rest_api.dart';
import '../../service/auth_service.dart';
import '../../utils/app_colors.dart';
import '../../utils/app_common.dart';
import '../../utils/app_constants.dart';
import '../../utils/app_images.dart';
import '../Auth/sign_in_screen.dart';
import '../Diet/fill_diet_details.dart';
import '../Reminder/AddReminder/reminder_screen.dart';
import 'Blog/blog_screen.dart';
import 'History/history_screen.dart';
import 'about_gym_screen.dart';
import 'edit_profile_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  void initState() {
    super.initState();
    init();
  }

  init() async {
    //
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  Future deleteAccount(BuildContext context) async {
    appStore.setLoading(true);
    await deleteUserAccountApi().then((value) async {
      await logout(context).then((value) async {
        appStore.setLoading(false);
        await removeKey(EMAIL);
        await removeKey(PASSWORD);
        await removeKey(IS_REMEMBER);
        AwesomeNotifications().dispose();
        toast('Your account is deleted successfully!');
        const SignInScreen().launch(context, isNewTask: true);
      });
      finish(context);
    }).catchError((error) {
      appStore.setLoading(false);
      toast(error.toString());
    });
  }

  Widget mOtherInfo(String title, String value, String heading) {
    return Container(
      decoration: boxDecorationWithRoundedCorners(
          borderRadius: radius(12), backgroundColor: primaryOpacity),
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          RichText(
            textAlign: TextAlign.center,
            text: TextSpan(
              children: [
                TextSpan(
                    text: value,
                    style: boldTextStyle(size: 18, color: primaryColor)),
                const WidgetSpan(
                    child: Padding(padding: EdgeInsets.only(right: 4))),
                TextSpan(
                    text: heading,
                    style: boldTextStyle(size: 14, color: primaryColor)),
              ],
            ),
          ),
          6.height,
          Text(title, style: secondaryTextStyle(size: 12, color: textColor)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion(
      value: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness:
            appStore.isDarkMode ? Brightness.light : Brightness.light,
        systemNavigationBarIconBrightness:
            appStore.isDarkMode ? Brightness.light : Brightness.light,
      ),
      child: Scaffold(
        backgroundColor: appStore.isDarkMode ? cardDarkColor : cardLightColor,
        body: Observer(
          builder: (context) {
            return Column(
              children: [
                Stack(
                  children: [
                    Container(
                        height: context.height() * 0.4, color: appRedColor),
                    Align(
                      alignment: Alignment.center,
                      child: Text(languages.lblProfile,
                              style: boldTextStyle(size: 20, color: white))
                          .paddingTop(context.statusBarHeight + 16),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: context.height() * 0.2),
                      height: context.height() * 0.6,
                      decoration: boxDecorationWithRoundedCorners(
                        backgroundColor: appStore.isDarkMode
                            ? context.scaffoldBackgroundColor
                            : context.cardColor,
                        borderRadius: radiusOnly(
                            topRight: defaultRadius, topLeft: defaultRadius),
                      ),
                    ),
                    Container(
                      height: context.height() * 0.77,
                      margin: EdgeInsets.only(
                          top: context.height() * 0.1, right: 16, left: 16),
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            16.height,
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  vertical: 20, horizontal: 4),
                              decoration: boxDecorationWithRoundedCorners(
                                backgroundColor: appStore.isDarkMode
                                    ? socialBackground
                                    : context.cardColor,
                                boxShadow: [
                                  BoxShadow(
                                      color: shadowColorGlobal,
                                      offset: const Offset(0, 1),
                                      spreadRadius: 2,
                                      blurRadius: 10,
                                      blurStyle: BlurStyle.outer)
                                ],
                                borderRadius: radius(14),
                              ),
                              child: Column(
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Stack(
                                        alignment: Alignment.bottomRight,
                                        children: [
                                          Container(
                                            decoration:
                                                boxDecorationWithRoundedCorners(
                                                    boxShape: BoxShape.circle,
                                                    border: Border.all(
                                                        width: 2,
                                                        color: primaryColor)),
                                            child: cachedImage(
                                                    userStore.profileImage
                                                        .validate(),
                                                    height: 65,
                                                    width: 65,
                                                    fit: BoxFit.cover)
                                                .cornerRadiusWithClipRRect(100)
                                                .paddingAll(1),
                                          ),
                                          Container(
                                            decoration:
                                                boxDecorationWithRoundedCorners(
                                                    boxShape: BoxShape.circle,
                                                    border: Border.all(
                                                        width: 2, color: white),
                                                    backgroundColor:
                                                        primaryColor),
                                            padding: const EdgeInsets.all(4),
                                            child: Image.asset(ic_edit,
                                                color: white,
                                                height: 14,
                                                width: 14),
                                          )
                                        ],
                                      ),
                                      10.height,
                                      Text(
                                          "${userStore.fName.validate().capitalizeFirstLetter()} ${userStore.lName.capitalizeFirstLetter()}",
                                          style: boldTextStyle(size: 20)),
                                      2.height,
                                      Text(userStore.email.validate(),
                                          style: secondaryTextStyle()),
                                    ],
                                  )
                                      .paddingSymmetric(horizontal: 16)
                                      .onTap(() async {
                                    bool? res = await EditProfileScreen()
                                        .launch(context);
                                    if (res == true) {
                                      setState(() {});
                                    }
                                  }),
                                  20.height,
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      mOtherInfo(
                                          languages.lblWeight,
                                          userStore.weight.isEmptyOrNull
                                              ? "-"
                                              : userStore.weight.validate(),
                                          userStore.weight.isEmptyOrNull
                                              ? ""
                                              : userStore.weightUnit
                                                  .validate()),
                                      12.width,
                                      mOtherInfo(
                                          languages.lblHeight,
                                          userStore.height.isEmptyOrNull
                                              ? "-"
                                              : userStore.height.validate(),
                                          userStore.height.isEmptyOrNull
                                              ? ""
                                              : userStore.heightUnit
                                                  .validate()),
                                      12.width,
                                      mOtherInfo(
                                          languages.lblAge,
                                          userStore.age.isEmptyOrNull
                                              ? "-"
                                              : userStore.age.validate(),
                                          userStore.age.isEmptyOrNull
                                              ? ""
                                              : languages.lblYear),
                                    ],
                                  ).paddingSymmetric(horizontal: 16),
                                ],
                              ),
                            ),
                            8.height,
                            mOption(diet, "Edit Diet", () {
                              const FillDietDetails(
                                title: "Profile",
                              ).launch(context);
                            }),
                            const Divider(height: 0, color: grayColor),
                            mOption(ic_blog, languages.lblBlog, () {
                              const BlogScreen().launch(context);
                            }),
                            const Divider(height: 0, color: grayColor),
                            // mOption(ic_fav_outline,
                            //     languages.lblFavoriteWorkoutAndNutristions, () {
                            //   FavouriteScreen(
                            //     index: 0,
                            //   ).launch(context);
                            // }),
                            const Divider(height: 0, color: grayColor),
                            mOption(ic_reminder, languages.lblDailyReminders,
                                () {
                              const ReminderScreen().launch(context);
                            }),
                            const Divider(height: 0, color: grayColor),
                            mOption(ic_assigned, "History Workout & Diet", () {
                              HistoryScreen().launch(context);
                            }),
                            const Divider(height: 0, color: grayColor),
                            mOption(ic_notification,
                                "${languages.lblNotifications} Setting",
                                () async {
                              const NotificationSettingScreen().launch(context);
                            }),
                            const Divider(height: 0, color: grayColor),
                            mOption(report, languages.lblAboutGym, () {
                              const AboutGymScreen().launch(context,
                                  pageRouteAnimation: PageRouteAnimation.Fade);
                            }),
                            const Divider(height: 0, color: grayColor),
                            mOption(ic_delete, languages.lblDeleteAccount,
                                () async {
                              const AccountDeleteScreen().launch(context);
                              // await showConfirmDialogCustom(
                              //   context,
                              //   title: languages.lblDeleteMsg,
                              //   dialogType: DialogType.DELETE,
                              //   positiveText: languages.lblDelete,
                              //   negativeText: languages.lblCancel,
                              //   image: ic_delete,
                              //   iconColor: primaryColor,
                              //   primaryColor: primaryColor,
                              //   onAccept: (c) async {
                              //     await deleteAccount(context);
                              //   },
                              // );
                            }),
                            const Divider(height: 0, color: grayColor),
                            mOption(ic_logout, languages.lblLogout, () async{
                              showConfirmDialogCustom(context,
                                  dialogType: DialogType.DELETE,
                                  title: languages.lblLogoutMsg,
                                  primaryColor: primaryColor,
                                  positiveText: languages.lblLogout,
                                  image: ic_logout, onAccept: (buildContext) async{
                                await logout(context, onLogout: () {

                                  const SignInScreen()
                                      .launch(context, isNewTask: true);
                                });
                                finish(context);
                              });
                            }),
                            20.height,
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

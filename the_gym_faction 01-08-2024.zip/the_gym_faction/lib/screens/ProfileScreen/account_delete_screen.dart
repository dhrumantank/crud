import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/string_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/utils/app_images.dart';
import 'package:flutter/material.dart';

import '../../extensions/text_styles.dart';
import '../../extensions/widgets.dart';

class AccountDeleteScreen extends StatefulWidget {
  const AccountDeleteScreen({super.key});

  @override
  State<AccountDeleteScreen> createState() => _AccountDeleteScreenState();
}

class _AccountDeleteScreenState extends State<AccountDeleteScreen> {
  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: appBarWidget(
        "Account Delete".validate(),
        context: context,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const Image(
              image: AssetImage(ic_splash_logo),
              width: 300,
              height: 300,
            ).center(),
            Text(
              "Account Termination",
              style: boldTextStyle(size: 30),
            ).center(),
            20.height,
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "1)",
                  style: boldTextStyle(size: 14),
                ),
                5.width,
                Container(
                  constraints: BoxConstraints(maxWidth: w * 0.8),
                  child: Text(
                    """You can submit the request to delete the account at "hdtank77@gmail.com" with subject line "Request to Delete the Account", with submission of this request""",
                    style: boldTextStyle(size: 14),
                  ),
                ),
              ],
            ),
            10.height,
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "2)",
                  style: boldTextStyle(size: 14),
                ),
                5.width,
                Container(
                  constraints: BoxConstraints(maxWidth: w * 0.8),
                  child: Text(
                    """you undersatand that your account will get removed/deleted from asiapixels.com and you will no longer be able to access any kind of services on aisapixels.com.""",
                    style: boldTextStyle(size: 14),
                  ),
                ),
              ],
            ),
            10.height,
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "3)",
                  style: boldTextStyle(size: 14),
                ),
                5.width,
                Container(
                  constraints: BoxConstraints(maxWidth: w * 0.8),
                  child: Text(
                    """If you have any active subscritption it will get void and in order to start using services again you will need to register a new account with thegymfaction.com.""",
                    style: boldTextStyle(size: 14),
                  ),
                ),
              ],
            ),
            10.height,
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "4)",
                  style: boldTextStyle(size: 14),
                ),
                5.width,
                Container(
                  constraints: BoxConstraints(maxWidth: w * 0.8),
                  child: Text(
                    """Please note it may take 24-48 hours to remove your account completely.""",
                    style: boldTextStyle(size: 14),
                  ),
                ),
              ],
            ),
            10.height,
          ],
        ).paddingSymmetric(horizontal: 20),
      ),
    );
  }
}

import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:TheGymFaction/models/notification_setting_model.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:flutter/material.dart';

import '../../../extensions/colors.dart';
import '../../../extensions/widgets.dart';

class NotificationSettingScreen extends StatefulWidget {
  const NotificationSettingScreen({super.key});

  @override
  State<NotificationSettingScreen> createState() =>
      _NotificationSettingScreenState();
}

class _NotificationSettingScreenState extends State<NotificationSettingScreen> {
  List switchIds = [];
  bool getData = false;
  NotificationSettingResponse notificationResponse =
      NotificationSettingResponse(data: []);

  void fetchReminderTypeData() {
    setState(() => getData = true);
    getReminderTypeApi().then((value) {
      notificationResponse = value;
      for (var element in value.data!) {
        if (element.status == "1") {
          switchIds.add(element.id);
        }
      }
      setState(() => getData = false);
      return null;
    });
  }

  void addUpdateDietCategoryReminderData(int reminder, int status) {
    Map<String, dynamic> req = {
      "reminder": reminder,
      "status": status,
    };
    setUpdateDietCategoryReminderApi(req).then((value) {
      return null;
    });
  }

  @override
  void initState() {
    fetchReminderTypeData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // final h = MediaQuery.of(context).size.height;
    // final w = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar:
          appBarWidget("Notification Setting", context: context, center: true),
      body: getData == true
          ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const CircularProgressIndicator().center(),
              ],
            )
          : SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                children: [
                  10.height,
                  ListView.builder(
                    itemCount: notificationResponse.data!.length,
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      NotificationResponseDatum notification =
                          notificationResponse.data![index];
                      return Container(
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.shade300,
                              spreadRadius: 2,
                              blurRadius: 10,
                            )
                          ],
                          borderRadius: BorderRadius.circular(10),
                          color: whiteColor,
                        ),
                        child: ListTile(
                          title: Text(
                            notification.reminderTitle.toString(),
                            style: boldTextStyle(),
                          ),
                          trailing: Switch(
                            activeColor: Colors.green,
                            inactiveThumbColor: black,
                            value: switchIds.contains(notification.id),
                            onChanged: (value) {
                              if (switchIds.contains(notification.id)) {
                                switchIds.remove(notification.id);
                                addUpdateDietCategoryReminderData(
                                    notification.id!, 0);
                              } else {
                                switchIds.add(notification.id);
                                addUpdateDietCategoryReminderData(
                                    notification.id!, 1);
                              }
                              setState(() {});
                            },
                          ),
                        ),
                      ).paddingSymmetric(horizontal: 15, vertical: 5);
                    },
                  ),
                  20.height,
                ],
              ),
            ),
    );
  }
}

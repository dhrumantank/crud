import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/string_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/screens/no_data_screen.dart';
import 'package:TheGymFaction/utils/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shimmer/shimmer.dart';

import '../../../extensions/colors.dart';
import '../../../extensions/loader_widget.dart';
import '../../../extensions/text_styles.dart';
import '../../../extensions/widgets.dart';
import '../../../main.dart';
import '../../../models/exercise_history_model.dart';
import '../../../network/rest_api.dart';
import '../../../utils/app_common.dart';

class ViewWorkoutHistoryScreen extends StatefulWidget {
  const ViewWorkoutHistoryScreen({super.key});

  @override
  State<ViewWorkoutHistoryScreen> createState() =>
      _ViewWorkoutHistoryScreenState();
}

class _ViewWorkoutHistoryScreenState extends State<ViewWorkoutHistoryScreen> {
  DateFormat dateFormat = DateFormat("dd-MM-yyyy");
  List<ExerciseHistoryDatum> exerciseHistoryResponse = [];
  ScrollController workoutScrollController = ScrollController();
  bool getData = false;
  int workoutPage = 1;
  int? workoutNumPage;
  bool workoutMoreData = false;

  void fetchExerciseHistoryData() {
    if (workoutPage == 1) {
      exerciseHistoryResponse.clear();
      setState(() => getData = true);
    }
    getExerciseHistoryApi(workoutPage).then((value) {
      for (var element in value.data!) {
        exerciseHistoryResponse.add(element);
      }
      workoutNumPage = value.pagination!.totalPages!;
      setState(() {
        getData = false;
        workoutMoreData = false;
      });
    });
  }

  @override
  void initState() {
    fetchExerciseHistoryData();
    workoutScrollController.addListener(() {
      if (workoutScrollController.position.extentAfter < 1) {
        if (workoutPage < workoutNumPage!) {
          setState(() => workoutMoreData = true);
          workoutPage++;
          fetchExerciseHistoryData();
        }
      }
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: appBarWidget("Workout History".validate(), context: context),
      body: SingleChildScrollView(
        controller: workoutScrollController,
        physics: const BouncingScrollPhysics(),
        child: getData
            ? const WorkoutShimmerEffectScreen()
            : exerciseHistoryResponse.isNotEmpty
                ? Column(
                    children: [
                      10.height,
                      Column(
                        children: [
                          ListView.builder(
                            itemCount: exerciseHistoryResponse.length,
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemBuilder: (context, index) {
                              ExerciseHistoryDatum exerciseHistory =
                                  exerciseHistoryResponse[index];
                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  10.height,
                                  Text(
                                    dateFormat.format(exerciseHistory.date!),
                                    style: boldTextStyle(size: 14),
                                  ),
                                  ListView.builder(
                                    itemCount: exerciseHistory.workouts!.length,
                                    shrinkWrap: true,
                                    physics:
                                        const NeverScrollableScrollPhysics(),
                                    itemBuilder: (context, index) {
                                      Workout workout =
                                          exerciseHistory.workouts![index];
                                      return Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          10.height,
                                          Text(
                                            workout.bodyPartTitle!.toString(),
                                            style: boldTextStyle(size: 14),
                                          ),
                                          ListView.builder(
                                            itemCount:
                                                workout.exercises!.length,
                                            shrinkWrap: true,
                                            physics:
                                                const NeverScrollableScrollPhysics(),
                                            itemBuilder: (context, index) {
                                              Exercise exercise =
                                                  workout.exercises![index];
                                              return Stack(
                                                children: [
                                                  Container(
                                                    decoration: BoxDecoration(
                                                      border: Border.all(
                                                        color:
                                                            exercise.status ==
                                                                    "complete"
                                                                ? Colors.green
                                                                : appRedColor,
                                                      ),
                                                      boxShadow: [
                                                        BoxShadow(
                                                          color: Colors
                                                              .grey.shade300,
                                                          spreadRadius: 2,
                                                          blurRadius: 10,
                                                        )
                                                      ],
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      color: whiteColor,
                                                    ),
                                                    child: ListTile(
                                                      leading: Container(
                                                        height: h * 0.07,
                                                        width: w * 0.14,
                                                        decoration:
                                                            BoxDecoration(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(80),
                                                        ),
                                                        child: cachedImage(exercise
                                                                .exerciseImage!)
                                                            .cornerRadiusWithClipRRect(
                                                                80),
                                                      ),
                                                      title: Text(exercise.title
                                                          .toString()),
                                                      subtitle:
                                                          exercise.type ==
                                                                  "duration"
                                                              ? Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: List.generate(
                                                                      exercise
                                                                          .duration!
                                                                          .length,
                                                                      (index) {
                                                                    HistoryDuration
                                                                        data =
                                                                        exercise
                                                                            .duration![index];
                                                                    return Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Text(
                                                                            data.duration
                                                                                .validate(),
                                                                            style:
                                                                                boldTextStyle(
                                                                              size: 12,
                                                                              color: const Color(0xFF8D8D8D),
                                                                            )),
                                                                        4.width,
                                                                        Text(
                                                                            languages
                                                                                .lblMinutes,
                                                                            style:
                                                                                primaryTextStyle(
                                                                              size: 12,
                                                                              color: const Color(0xFF8D8D8D),
                                                                            )),
                                                                      ],
                                                                    );
                                                                  }),
                                                                )
                                                              : Column(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: List.generate(
                                                                      exercise
                                                                          .sets!
                                                                          .length,
                                                                      (index) {
                                                                    return Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Text(
                                                                          "${exercise.sets![index].reps} set",
                                                                          style: boldTextStyle(
                                                                              size: 12,
                                                                              color: const Color(0xFF8D8D8D)),
                                                                        ),
                                                                        5.width,
                                                                        Text(
                                                                          "${exercise.sets![index].weight} Kg",
                                                                          style: boldTextStyle(
                                                                              size: 12,
                                                                              color: const Color(0xFF8D8D8D)),
                                                                        ),
                                                                      ],
                                                                    );
                                                                  }),
                                                                ),
                                                    ).paddingSymmetric(
                                                        vertical: 10),
                                                  ).paddingSymmetric(
                                                      vertical: 5),
                                                  Positioned(
                                                    right: 10,
                                                    bottom: 15,
                                                    child: exercise.status ==
                                                            "complete"
                                                        ? Container(
                                                            decoration:
                                                                BoxDecoration(
                                                              color:
                                                                  Colors.green,
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                            ),
                                                            child: Text.rich(
                                                              TextSpan(
                                                                  text:
                                                                      "Complete",
                                                                  children: [
                                                                    WidgetSpan(
                                                                      child: 5
                                                                          .width,
                                                                    ),
                                                                    const WidgetSpan(
                                                                      child:
                                                                          CircleAvatar(
                                                                        radius:
                                                                            6,
                                                                        backgroundColor:
                                                                            whiteColor,
                                                                        child:
                                                                            Icon(
                                                                          size:
                                                                              10,
                                                                          Icons
                                                                              .done,
                                                                          color:
                                                                              Colors.green,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ]),
                                                              style: boldTextStyle(
                                                                  color:
                                                                      whiteColor,
                                                                  size: 12),
                                                            ).paddingSymmetric(
                                                                horizontal: 8,
                                                                vertical: 4),
                                                          )
                                                        : Container(
                                                            decoration:
                                                                BoxDecoration(
                                                              color:
                                                                  appRedColor,
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          5),
                                                            ),
                                                            child: Text.rich(
                                                              TextSpan(
                                                                  text:
                                                                      "Not Complete",
                                                                  children: [
                                                                    WidgetSpan(
                                                                      child: 5
                                                                          .width,
                                                                    ),
                                                                    const WidgetSpan(
                                                                      child:
                                                                          CircleAvatar(
                                                                        radius:
                                                                            6,
                                                                        backgroundColor:
                                                                            whiteColor,
                                                                        child:
                                                                            Icon(
                                                                          size:
                                                                              10,
                                                                          Icons
                                                                              .close,
                                                                          color:
                                                                              appRedColor,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ]),
                                                              style: boldTextStyle(
                                                                  color:
                                                                      whiteColor,
                                                                  size: 12),
                                                            ).paddingSymmetric(
                                                                horizontal: 8,
                                                                vertical: 4),
                                                          ),
                                                  )
                                                ],
                                              );
                                            },
                                          )
                                        ],
                                      );
                                    },
                                  ),
                                ],
                              ).paddingSymmetric(horizontal: 15);
                            },
                          ),
                        ],
                      ),
                      if (workoutMoreData == true) 30.height,
                      if (workoutMoreData == true) const Loader().center(),
                      if (workoutMoreData == true) 30.height,
                    ],
                  )
                : const NoDataScreen(mTitle: "No Workout History"),
      ),
    );
  }
}

class WorkoutShimmerEffectScreen extends StatelessWidget {
  const WorkoutShimmerEffectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Column(
      children: [
        ListView.builder(
          itemCount: 4,
          shrinkWrap: true,
          itemBuilder: (context, index) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Shimmer.fromColors(
                    baseColor: Colors.grey.shade300,
                    highlightColor: Colors.white54,
                    child: Container(
                      width: w * 0.5,
                      height: h * 0.03,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        color: Colors.grey.shade300,
                      ),
                    )),
                ListView.builder(
                  itemCount: 4,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return Shimmer.fromColors(
                      baseColor: Colors.grey.shade300,
                      highlightColor: whiteColor,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.shade300,
                              spreadRadius: 2,
                              blurRadius: 10,
                            )
                          ],
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: ListTile(
                          leading: Container(
                            height: h * 0.07,
                            width: w * 0.14,
                            decoration: BoxDecoration(
                              color: Colors.grey.shade300,
                              borderRadius: BorderRadius.circular(80),
                            ),
                          ),
                        ).paddingSymmetric(vertical: 10),
                      ).paddingSymmetric(vertical: 5),
                    );
                  },
                )
              ],
            )..paddingSymmetric(horizontal: 15);
          },
        )
      ],
    ).paddingSymmetric(horizontal: 20, vertical: 10);
  }
}

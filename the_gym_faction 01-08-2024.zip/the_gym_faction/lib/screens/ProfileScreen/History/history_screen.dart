import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/string_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shimmer/shimmer.dart';

import '../../../../extensions/widgets.dart';
import '../../../extensions/colors.dart';
import '../../../extensions/loader_widget.dart';
import '../../../extensions/text_styles.dart';
import '../../../main.dart';
import '../../../models/diet_history_response.dart';
import '../../../models/exercise_history_model.dart';
import '../../../network/rest_api.dart';
import '../../../utils/app_colors.dart';
import '../../../utils/app_common.dart';
import '../../../utils/app_images.dart';
import '../../no_data_screen.dart';

class HistoryScreen extends StatefulWidget {
  static String tag = '/HistoryScreen';

  const HistoryScreen({super.key});

  @override
  HistoryScreenState createState() => HistoryScreenState();
}

class HistoryScreenState extends State<HistoryScreen>
    with TickerProviderStateMixin {
  late TabController tabController;
  List<ExerciseHistoryDatum> exerciseHistoryResponse = [];
  List<DietHistoryDatum> dietHistoryResponse = [];
  ScrollController workoutScrollController = ScrollController();
  ScrollController dietScrollController = ScrollController();
  bool select = true;
  bool getData = false;
  bool getDietData = false;
  int workoutPage = 1;
  int dietPage = 1;
  int? workoutNumPage;
  int? dietNumPage;
  bool workoutMoreData = false;
  bool dietMoreData = false;

  void fetchExerciseHistoryData() {
    if (workoutPage == 1) {
      exerciseHistoryResponse.clear();
      setState(() => getData = true);
    }
    getExerciseHistoryApi(workoutPage).then((value) {
      for (var element in value.data!) {
        exerciseHistoryResponse.add(element);
      }
      workoutNumPage = value.pagination!.totalPages!;
      setState(() {
        getData = false;
        workoutMoreData = false;
      });
    });
  }

  void fetchDietHistoryData() {
    if (dietPage == 1) {
      dietHistoryResponse.clear();
      setState(() => getDietData = true);
    }
    getDietHistoryApi(dietPage).then((value) {
      for (var element in value.data!) {
        dietHistoryResponse.add(element);
      }
      dietNumPage = value.pagination!.totalPages!;
      setState(() {
        getDietData = false;
        dietMoreData = false;
      });
      return;
    });
  }

  @override
  void initState() {
    tabController = TabController(length: 2, vsync: this);
    fetchExerciseHistoryData();
    fetchDietHistoryData();
    workoutScrollController.addListener(() {
      if (workoutScrollController.position.extentAfter < 1) {
        if (workoutPage < workoutNumPage!) {
          setState(() => workoutMoreData = true);
          workoutPage++;
          fetchExerciseHistoryData();
        }
      }
    });
    dietScrollController.addListener(() {
      if (dietScrollController.position.extentAfter < 1) {
        if (dietPage < dietNumPage!) {
          setState(() => dietMoreData = true);
          dietPage++;
          fetchDietHistoryData();
        }
      }
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBarWidget(
        "History Workout & Diet",
        context: context,
        bottom: TabBar(
          indicatorSize: TabBarIndicatorSize.tab,
          indicatorColor: black,
          dividerColor: Colors.transparent,
          controller: tabController,
          tabs: [
            Text(
              languages.lblWorkouts,
              style: boldTextStyle(color: primaryColor),
            ),
            Text(
              languages.lblDiet,
              style: boldTextStyle(color: primaryColor),
            ),
          ],
        ),
      ),
      body: TabBarView(
        controller: tabController,
        children: [
          WorkoutHistoryScreen(
            workout: getData,
            moreData: workoutMoreData,
            exerciseHistoryResponse: exerciseHistoryResponse,
            workoutScrollController: workoutScrollController,
          ),
          DietHistoryScreen(
            moreData: dietMoreData,
            getDietData: getDietData,
            dietController: dietScrollController,
            dietHistoryResponse: dietHistoryResponse,
          ),
        ],
      ),
    );
  }
}

class WorkoutHistoryScreen extends StatelessWidget {
  const WorkoutHistoryScreen(
      {super.key,
      required this.workout,
      required this.moreData,
      this.exerciseHistoryResponse,
      required this.workoutScrollController});

  final bool workout;
  final bool moreData;
  final List<ExerciseHistoryDatum>? exerciseHistoryResponse;
  final ScrollController workoutScrollController;

  @override
  Widget build(BuildContext context) {
    DateFormat dateFormat = DateFormat("dd-MM-yyyy");
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return workout
        ? const WorkoutShimmerEffectScreen()
        : exerciseHistoryResponse!.isNotEmpty
            ? SingleChildScrollView(
                controller: workoutScrollController,
                physics: const BouncingScrollPhysics(),
                child: Column(
                  children: [
                    ListView.builder(
                      itemCount: exerciseHistoryResponse!.length,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        ExerciseHistoryDatum exerciseHistory =
                            exerciseHistoryResponse![index];
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            10.height,
                            Text(
                              dateFormat.format(exerciseHistory.date!),
                              style: boldTextStyle(size: 14),
                            ),
                            ListView.builder(
                              itemCount: exerciseHistory.workouts!.length,
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemBuilder: (context, index) {
                                Workout workout =
                                    exerciseHistory.workouts![index];
                                return Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    10.height,
                                    Text(
                                      workout.bodyPartTitle!.toString(),
                                      style: boldTextStyle(size: 14),
                                    ),
                                    ListView.builder(
                                      itemCount: workout.exercises!.length,
                                      shrinkWrap: true,
                                      physics:
                                          const NeverScrollableScrollPhysics(),
                                      itemBuilder: (context, index) {
                                        Exercise exercise =
                                            workout.exercises![index];
                                        return Stack(
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
                                                border: Border.all(
                                                  color: exercise.status ==
                                                          "complete"
                                                      ? Colors.green
                                                      : appRedColor,
                                                ),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Colors.grey.shade300,
                                                    spreadRadius: 2,
                                                    blurRadius: 10,
                                                  )
                                                ],
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                color: whiteColor,
                                              ),
                                              child: ListTile(
                                                leading: Container(
                                                  height: h * 0.07,
                                                  width: w * 0.14,
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            80),
                                                  ),
                                                  child: cachedImage(exercise
                                                          .exerciseImage!)
                                                      .cornerRadiusWithClipRRect(
                                                          80),
                                                ),
                                                title: Text(
                                                    exercise.title.toString()),
                                                subtitle: exercise.type ==
                                                        "duration"
                                                    ? Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: List.generate(
                                                            exercise.duration!
                                                                .length,
                                                            (index) {
                                                          HistoryDuration data =
                                                              exercise.duration![
                                                                  index];
                                                          return Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Text(
                                                                  data.duration
                                                                      .validate(),
                                                                  style:
                                                                      boldTextStyle(
                                                                    size: 12,
                                                                    color: const Color(
                                                                        0xFF8D8D8D),
                                                                  )),
                                                              4.width,
                                                              Text(
                                                                  languages
                                                                      .lblMinutes,
                                                                  style:
                                                                      primaryTextStyle(
                                                                    size: 12,
                                                                    color: const Color(
                                                                        0xFF8D8D8D),
                                                                  )),
                                                            ],
                                                          );
                                                        }),
                                                      )
                                                    : Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: List.generate(
                                                            exercise
                                                                .sets!.length,
                                                            (index) {
                                                          return Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Text(
                                                                "${exercise.sets![index].reps} set",
                                                                style: boldTextStyle(
                                                                    size: 12,
                                                                    color: const Color(
                                                                        0xFF8D8D8D)),
                                                              ),
                                                              5.width,
                                                              Text(
                                                                "${exercise.sets![index].weight} Kg",
                                                                style: boldTextStyle(
                                                                    size: 12,
                                                                    color: const Color(
                                                                        0xFF8D8D8D)),
                                                              ),
                                                            ],
                                                          );
                                                        }),
                                                      ),
                                              ).paddingSymmetric(vertical: 10),
                                            ).paddingSymmetric(vertical: 5),
                                            Positioned(
                                              right: 10,
                                              bottom: 15,
                                              child: exercise.status ==
                                                      "complete"
                                                  ? Container(
                                                      decoration: BoxDecoration(
                                                        color: Colors.green,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5),
                                                      ),
                                                      child: Text.rich(
                                                        TextSpan(
                                                            text: "Complete",
                                                            children: [
                                                              WidgetSpan(
                                                                child: 5.width,
                                                              ),
                                                              const WidgetSpan(
                                                                child:
                                                                    CircleAvatar(
                                                                  radius: 6,
                                                                  backgroundColor:
                                                                      whiteColor,
                                                                  child: Icon(
                                                                    size: 10,
                                                                    Icons.done,
                                                                    color: Colors
                                                                        .green,
                                                                  ),
                                                                ),
                                                              ),
                                                            ]),
                                                        style: boldTextStyle(
                                                            color: whiteColor,
                                                            size: 12),
                                                      ).paddingSymmetric(
                                                          horizontal: 8,
                                                          vertical: 4),
                                                    )
                                                  : Container(
                                                      decoration: BoxDecoration(
                                                        color: appRedColor,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(5),
                                                      ),
                                                      child: Text.rich(
                                                        TextSpan(
                                                            text:
                                                                "Not Complete",
                                                            children: [
                                                              WidgetSpan(
                                                                child: 5.width,
                                                              ),
                                                              const WidgetSpan(
                                                                child:
                                                                    CircleAvatar(
                                                                  radius: 6,
                                                                  backgroundColor:
                                                                      whiteColor,
                                                                  child: Icon(
                                                                    size: 10,
                                                                    Icons.close,
                                                                    color:
                                                                        appRedColor,
                                                                  ),
                                                                ),
                                                              ),
                                                            ]),
                                                        style: boldTextStyle(
                                                            color: whiteColor,
                                                            size: 12),
                                                      ).paddingSymmetric(
                                                          horizontal: 8,
                                                          vertical: 4),
                                                    ),
                                            )
                                          ],
                                        );
                                      },
                                    )
                                  ],
                                );
                              },
                            ),
                          ],
                        ).paddingSymmetric(horizontal: 15);
                      },
                    ),
                    if (moreData == true) 30.height,
                    if (moreData == true) const Loader().center(),
                    if (moreData == true) 30.height,
                  ],
                ),
              )
            : const NoDataScreen(mTitle: "No Workout History");
  }
}

class DietHistoryScreen extends StatelessWidget {
  const DietHistoryScreen(
      {super.key,
      this.getDietData,
      this.dietHistoryResponse,
      required this.dietController,
      required this.moreData});
  final List<DietHistoryDatum>? dietHistoryResponse;
  final ScrollController dietController;
  final bool? getDietData;
  final bool moreData;

  @override
  Widget build(BuildContext context) {
    DateFormat dateFormat = DateFormat("dd-MM-yyyy");
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return getDietData!
        ? const DietHistoryShimmerEffectScreen()
        : dietHistoryResponse!.isNotEmpty
            ? SingleChildScrollView(
                controller: dietController,
                physics: const BouncingScrollPhysics(),
                child: Column(
                  children: [
                    ListView.builder(
                      itemCount: dietHistoryResponse!.length,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        DietHistoryDatum dietHistory =
                            dietHistoryResponse![index];
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            10.height,
                            Text(
                              dateFormat.format(dietHistory.date!),
                              style: boldTextStyle(size: 14),
                            ),
                            ListView.builder(
                              itemCount: dietHistory.diets!.length,
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              itemBuilder: (context, index) {
                                Diet diet = dietHistory.diets![index];
                                return Container(
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: diet.consumed == 1
                                          ? Colors.green
                                          : appRedColor,
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.shade300,
                                        spreadRadius: 2,
                                        blurRadius: 10,
                                      )
                                    ],
                                    borderRadius: BorderRadius.circular(10),
                                    color: whiteColor,
                                  ),
                                  child: ListTile(
                                    leading: Container(
                                      height: h * 0.07,
                                      width: w * 0.14,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(80),
                                      ),
                                      child: cachedImage(diet.image!)
                                          .cornerRadiusWithClipRRect(80),
                                    ),
                                    title: Text(diet.title.toString()),
                                    subtitle: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        const ImageIcon(
                                          AssetImage(ic_calories),
                                          color: Colors.grey,
                                          size: 18,
                                        ),
                                        5.width,
                                        Text(
                                          "${diet.calories} (Calories)",
                                          style: boldTextStyle(
                                              color: Colors.grey, size: 14),
                                        ),
                                        const Spacer(),
                                        if (diet.consumed == 1)
                                          Container(
                                            decoration: BoxDecoration(
                                              color: Colors.green,
                                              borderRadius:
                                                  BorderRadius.circular(5),
                                            ),
                                            child: Text.rich(
                                              TextSpan(
                                                  text: "Consumed",
                                                  children: [
                                                    WidgetSpan(
                                                      child: 5.width,
                                                    ),
                                                    const WidgetSpan(
                                                      child: CircleAvatar(
                                                        radius: 6,
                                                        backgroundColor:
                                                            whiteColor,
                                                        child: Icon(
                                                          size: 10,
                                                          Icons.done,
                                                          color: Colors.green,
                                                        ),
                                                      ),
                                                    ),
                                                  ]),
                                              style: boldTextStyle(
                                                  color: whiteColor, size: 12),
                                            ).paddingSymmetric(
                                                horizontal: 8, vertical: 4),
                                          )
                                        else
                                          Container(
                                            decoration: BoxDecoration(
                                              color: appRedColor,
                                              borderRadius:
                                                  BorderRadius.circular(5),
                                            ),
                                            child: Text.rich(
                                              TextSpan(
                                                  text: "Not Done",
                                                  children: [
                                                    WidgetSpan(
                                                      child: 5.width,
                                                    ),
                                                    const WidgetSpan(
                                                      child: CircleAvatar(
                                                        radius: 6,
                                                        backgroundColor:
                                                            whiteColor,
                                                        child: Icon(
                                                          size: 10,
                                                          Icons.close,
                                                          color: appRedColor,
                                                        ),
                                                      ),
                                                    ),
                                                  ]),
                                              style: boldTextStyle(
                                                  color: whiteColor, size: 12),
                                            ).paddingSymmetric(
                                                horizontal: 8, vertical: 4),
                                          ),
                                      ],
                                    ),
                                  ),
                                ).paddingSymmetric(vertical: 5);
                              },
                            ),
                          ],
                        ).paddingSymmetric(horizontal: 15);
                      },
                    ),
                    if (moreData == true) 30.height,
                    if (moreData == true) const Loader().center(),
                    if (moreData == true) 30.height,
                  ],
                ),
              )
            : const NoDataScreen(mTitle: "No Diet History");
  }
}

class WorkoutShimmerEffectScreen extends StatelessWidget {
  const WorkoutShimmerEffectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return SingleChildScrollView(
      child: Column(
        children: [
          ListView.builder(
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 4,
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Shimmer.fromColors(
                      baseColor: Colors.grey.shade300,
                      highlightColor: Colors.white54,
                      child: Container(
                        width: w * 0.5,
                        height: h * 0.03,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: Colors.grey.shade300,
                        ),
                      )),
                  ListView.builder(
                    itemCount: 4,
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return Shimmer.fromColors(
                        baseColor: Colors.grey.shade300,
                        highlightColor: whiteColor,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.shade300,
                                spreadRadius: 2,
                                blurRadius: 10,
                              )
                            ],
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: ListTile(
                            leading: Container(
                              height: h * 0.07,
                              width: w * 0.14,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(80),
                              ),
                            ),
                          ).paddingSymmetric(vertical: 10),
                        ).paddingSymmetric(vertical: 5),
                      );
                    },
                  )
                ],
              )..paddingSymmetric(horizontal: 15);
            },
          )
        ],
      ).paddingSymmetric(horizontal: 20, vertical: 10),
    );
  }
}

class DietHistoryShimmerEffectScreen extends StatelessWidget {
  const DietHistoryShimmerEffectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return SingleChildScrollView(
      child: Column(
        children: [
          ListView.builder(
            itemCount: 4,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Shimmer.fromColors(
                      baseColor: Colors.grey.shade300,
                      highlightColor: Colors.white54,
                      child: Container(
                        width: w * 0.5,
                        height: h * 0.03,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: Colors.grey.shade300,
                        ),
                      )),
                  ListView.builder(
                    itemCount: 4,
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return Shimmer.fromColors(
                        baseColor: Colors.grey.shade300,
                        highlightColor: whiteColor,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.shade300,
                                spreadRadius: 2,
                                blurRadius: 10,
                              )
                            ],
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: ListTile(
                            leading: Container(
                              height: h * 0.07,
                              width: w * 0.14,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade300,
                                borderRadius: BorderRadius.circular(80),
                              ),
                            ),
                          ).paddingSymmetric(vertical: 10),
                        ).paddingSymmetric(vertical: 5),
                      );
                    },
                  )
                ],
              )..paddingSymmetric(horizontal: 15);
            },
          )
        ],
      ).paddingSymmetric(horizontal: 20, vertical: 10),
    );
  }
}

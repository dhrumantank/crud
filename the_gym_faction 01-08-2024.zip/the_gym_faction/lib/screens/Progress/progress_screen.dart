import 'package:TheGymFaction/screens/Progress/progress_detail_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';

import '../../../extensions/extension_util/int_extensions.dart';
import '../../../extensions/extension_util/widget_extensions.dart';
import '../../components/HomeComponent/daily_workout_component.dart';
import '../../components/ProgressComponents/ideal_weight_component.dart';
import '../../components/ProgressComponents/step_count_component.dart';
import '../../components/ProgressComponents/weight_graph_components.dart';
import '../../components/horizontal_bar_chart.dart';
import '../../extensions/LiveStream.dart';
import '../../extensions/colors.dart';
import '../../extensions/extension_util/list_extensions.dart';
import '../../extensions/shared_pref.dart';
import '../../extensions/text_styles.dart';
import '../../extensions/widgets.dart';
import '../../main.dart';
import '../../network/rest_api.dart';
import '../../utils/app_colors.dart';
import '../../utils/app_constants.dart';

class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});
  static String tag = '/ProgressScreen';

  @override
  ProgressScreenState createState() => ProgressScreenState();
}

class ProgressScreenState extends State<ProgressScreen> {
  bool? isWeight, isHeartRate, isPush;

  @override
  void initState() {
    super.initState();

    init();
    LiveStream().emit(IdealWeight);
    getDoubleAsync(IdealWeight);

    LiveStream().on(PROGRESS_SETTING, (p0) {
      userStore.mProgressList.forEachIndexed((element, index) {
        if (element.id == 1) {
          isWeight = element.isEnable;
        }
        if (element.id == 2) {
          isHeartRate = element.isEnable;
        }
        if (element.id == 3) {
          isPush = element.isEnable;
        }
        setState(() {});
      });
    });
  }

  init() async {
    //
    userStore.mProgressList.forEachIndexed((element, index) {
      if (element.id == 1) {
        isWeight = element.isEnable;
        if (element.isEnable == true) {
          getProgressApi(METRICS_WEIGHT);
        }
      }
      if (element.id == 2) {
        isHeartRate = element.isEnable;
        if (element.isEnable == true) {
          getProgressApi(METRICS_HEART_RATE);
        }
      }
      if (element.id == 3) {
        isPush = element.isEnable;
        if (element.isEnable == true) {
          getProgressApi(PUSH_UP_MIN_UNIT);
        }
      }
    });
    setState(() {});
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  Widget mHeading(String? value, {bool showIcon = true}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(value!, style: boldTextStyle()).paddingSymmetric(vertical: 5),
        8.width,
        if (showIcon)
          const Icon(Icons.keyboard_arrow_right, color: appRedColor),
      ],
    ).paddingSymmetric(horizontal: 16, vertical: 8);
  }

  @override
  Widget build(BuildContext context) {
    return Observer(builder: (context) {
      return Scaffold(
        appBar: appBarWidget(languages.lblReport,
            showBack: false,
            color: appStore.isDarkMode ? scaffoldColorDark : Colors.white,
            context: context,
            titleSpacing: 16),
        body: Observer(builder: (context) {
          return SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    StepCountComponent().expand(),
                    16.width,
                    IdealWeightComponent().expand(),
                  ],
                ).paddingSymmetric(horizontal: 16),
                16.height,
                FutureBuilder(
                  future: getWeightGraphResponse(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      return Card(
                        elevation: 1.0,
                        color: whiteColor,
                        shape: RoundedRectangleBorder(
                          side: BorderSide(
                              color: Colors.grey.shade200, width: 0.0),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        margin: EdgeInsets.zero,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            mHeading(languages.lblWeight),
                            WeightGraphComponents(
                              seriesList: snapshot.data!.data,
                            ),
                          ],
                        ).onTap(() async {
                          bool? res = await ProgressDetailScreen(
                                  mType: METRICS_WEIGHT,
                                  mUnit: METRICS_WEIGHT_UNIT,
                                  mTitle: languages.lblWeight)
                              .launch(context);
                          if (res == true) {
                            setState(() {});
                          }
                        }),
                      ).paddingSymmetric(horizontal: 15);
                    } else {
                      return const ChartShimmerEffect();
                    }
                  },
                ),
                16.height,
                FutureBuilder(
                  future: getWaterGraphResponse(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      return Card(
                        elevation: 1.0,
                        color: whiteColor,
                        shape: RoundedRectangleBorder(
                          side: BorderSide(
                              color: Colors.grey.shade200, width: 0.0),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        margin: EdgeInsets.zero,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            mHeading("Water"),
                            HorizontalBarChart(
                              XAxisLineColor: Colors.transparent,
                              YAxisLineColor: Colors.transparent,
                              waterSeriesList: snapshot.data!.data!,
                              type: "water",
                              color: Colors.black,
                              borderColor: Colors.transparent,
                              axisLineBorderColor: Colors.transparent,
                              MarkerBorderColor: appRedColor,
                              name: "Water Intake",
                            ),
                          ],
                        ).onTap(() async {
                          bool? res = await ProgressDetailScreen(
                            mType: METRICS_WATER,
                            mUnit: METRICS_WATER_UNIT,
                            mTitle: "Water",
                          ).launch(context);
                          if (res == true) {
                            setState(() {});
                          }
                        }),
                      ).paddingSymmetric(horizontal: 15);
                    } else {
                      return const ChartShimmerEffect();
                    }
                  },
                ),
                16.height,
                FutureBuilder(
                  future: getProgressApi(PUSH_UP_MIN),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      return Card(
                        elevation: 1.0,
                        color: whiteColor,
                        shape: RoundedRectangleBorder(
                          side: BorderSide(
                              color: Colors.grey.shade200, width: 0.0),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        margin: EdgeInsets.zero,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            mHeading(languages.lblPushUp),
                            HorizontalBarChart(
                              XAxisLineColor: Colors.transparent,
                              YAxisLineColor: Colors.transparent,
                              seriesList: snapshot.data!.data,
                              color: Colors.black,
                              borderColor: Colors.transparent,
                              axisLineBorderColor: Colors.transparent,
                              MarkerBorderColor: appRedColor,
                              name: "PushUp",
                            ),
                          ],
                        ).onTap(() async {
                          bool? res = await ProgressDetailScreen(
                                  mType: PUSH_UP_MIN,
                                  mUnit: PUSH_UP_MIN_UNIT,
                                  mTitle: languages.lblPushUp)
                              .launch(context);
                          if (res == true) {
                            setState(() {});
                          }
                        }),
                      ).paddingSymmetric(horizontal: 15);
                    } else {
                      return const ChartShimmerEffect();
                    }
                  },
                ),
                16.height,
                FutureBuilder(
                  future: getDailyWorkoutChartsResponse(),
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      return Card(
                        elevation: 1.0,
                        color: whiteColor,
                        shape: RoundedRectangleBorder(
                          side: BorderSide(
                              color: Colors.grey.shade200, width: 0.0),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        margin: EdgeInsets.zero,
                        child: Column(
                          children: [
                            mHeading("Daily Workout", showIcon: false),
                            DailyWorkout(
                              checkGetData: false,
                              chartList: snapshot.data!.data!,
                              cardView: false,
                            ),
                          ],
                        ),
                      ).paddingSymmetric(horizontal: 15);
                    } else {
                      return const ChartShimmerEffect();
                    }
                  },
                ),
                16.height,
              ],
            ),
          );
        }),
      );
    });
  }
}

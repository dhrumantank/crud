import 'dart:async';
import 'dart:io';
import 'dart:ui';

import 'package:TheGymFaction/components/blocked_account_dialog.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/screens/Diet/fill_diet_details.dart';
import 'package:animated_notch_bottom_bar/animated_notch_bottom_bar/animated_notch_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../extensions/extension_util/context_extensions.dart';
import '../components/double_back_to_close_app.dart';
import '../components/version_check_dialog.dart';
import '../extensions/LiveStream.dart';
import '../extensions/colors.dart';
import '../extensions/constants.dart';
import '../extensions/shared_pref.dart';
import '../extensions/text_styles.dart';
import '../main.dart';
import '../network/rest_api.dart';
import '../utils/app_colors.dart';
import '../utils/app_constants.dart';
import '../utils/app_images.dart';
import 'Diet/diet_screen.dart';
import 'Home/home_screen.dart';
import 'ProfileScreen/profile_screen.dart';
import 'Progress/progress_screen.dart';
import 'Reminder/reminder.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key, this.mCurrentIndex});
  final int? mCurrentIndex;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  NotchBottomBarController notchBottomBarController =
      NotchBottomBarController();
  bool getData = false;
  List<String> selectItem = [
    home,
    reminder,
    diet,
    ic_report_outline,
    ic_user,
  ];
  List<String> item = [
    homeFill,
    reminderFill,
    dietFill,
    ic_report_fill,
    ic_user_fill_icon,
  ];
  List screen = [
    const HomeScreen(),
    const Reminder(), // ProductScreen(),
    const DietScreen(),
    const ProgressScreen(),
    const ProfileScreen(),
  ];
  int mCurrentIndex = 0;
  int mCounter = 0;
  Timer? timer;

  @override
  void initState() {
    fetchUserAccountBlockedData();
    fetchUserAppVersionCheckData();
    super.initState();
    init();
    LiveStream().on("LANGUAGE", (s) {
      setState(() {});
    });
    if (widget.mCurrentIndex != null) {
      mCurrentIndex = widget.mCurrentIndex!;
      notchBottomBarController.jumpTo(widget.mCurrentIndex!);
    }
  }

  Future<void> fetchUserAccountBlockedData() async {
    userAccountBlockedCheckApi().then((value) {
      if (value.success == false) {
        showDialog(
          barrierDismissible: false,
          context: context,
          builder: (context) => BlockAccountDialog(
            title: value.data!.first.reason!,
            number: value.data!.first.contect!,
          ),
        );
      }
    });
  }

  Future<void> fetchUserAppVersionCheckData() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    String version = packageInfo.version;
    setState(() => getData = true);
    getUserAppVersionCheckApi().then((value) {
      if (Platform.isAndroid) {
        if (version != value.data!.androidVersion) {
          showDialog(
            barrierDismissible: false,
            context: context,
            builder: (context) {
              return VersionCheckDialog(
                appUrl: value.data!.androidLink!,
              );
            },
          );
        }
      } else if (Platform.isIOS) {
        if (version != value.data!.iosVersion) {
          showDialog(
            barrierDismissible: false,
            context: context,
            builder: (context) {
              return VersionCheckDialog(
                appUrl: value.data!.iosLink!,
              );
            },
          );
        }
      }
      setState(() => getData = false);
    });
  }

  // void checkVersion() async {
  //   PackageInfo packageInfo = await PackageInfo.fromPlatform();
  //   String version = packageInfo.version;
  //   if (version != "1.0.0") {
  //     showDialog(
  //       barrierDismissible: false,
  //       context: context,
  //       builder: (context) {
  //         return const VersionCheckDialog();
  //       },
  //     );
  //   }
  // }

  init() async {
    PlatformDispatcher.instance.onPlatformBrightnessChanged = () {
      if (getIntAsync(THEME_MODE_INDEX) == ThemeModeSystem) {
        appStore.setDarkMode(
            MediaQuery.of(context).platformBrightness == Brightness.light);
      }
    };
  }

  void callData() {
    appStore.setLoading(true);
    getUserTargetDetailsApi().then((value) {
      if (value.success == true) {
        const FillDietDetails(title: "Diet").launch(context).then(
          (value) {
            if (value == true) {
              setState(() => appStore.setCallFunction(true));
            } else {
              setState(() {
                mCurrentIndex = 0;
                notchBottomBarController.jumpTo(0);
              });
            }
          },
        );
        timer = Timer(const Duration(seconds: 2), () {
          appStore.setLoading(false);
          if (timer!.isActive) {
            timer!.cancel();
            setState(() {});
          }
        });
      } else {
        appStore.setLoading(false);
      }
      setState(() {});
      return;
    });
  }

  @override
  void didChangeDependencies() {
    if (getIntAsync(THEME_MODE_INDEX) == ThemeModeSystem) {
      appStore.setDarkMode(
          MediaQuery.of(context).platformBrightness == Brightness.dark);
    }
    setState(() {});
    super.didChangeDependencies();
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: DoubleBackToCloseApp(
        snackBar: SnackBar(
          elevation: 4,
          backgroundColor: appStore.isDarkMode ? cardDarkColor : primaryOpacity,
          content:
              Text(languages.lblTapBackAgainToLeave, style: primaryTextStyle()),
        ),
        child: AnimatedContainer(
          color: context.cardColor,
          duration: const Duration(seconds: 1),
          child: screen[mCurrentIndex],
        ),
      ),
      bottomNavigationBar: AnimatedNotchBottomBar(
        color: appRedColor,
        notchColor: black,
        durationInMilliSeconds: 300,
        notchBottomBarController: notchBottomBarController,
        bottomBarItems: List.generate(
          selectItem.length,
          (index) => BottomBarItem(
            inActiveItem:
                Image.asset(selectItem[index], color: whiteColor, height: 24),
            activeItem: Image.asset(item[index], color: whiteColor, height: 24),
            // itemLabel: languages.lblHome,
          ),
        ),
        onTap: (index) {
          fetchUserAccountBlockedData();
          mCurrentIndex = index;
          if (index == 2) {
            callData();
          }
          setState(() {});
        },
        kIconSize: 20,
        kBottomRadius: 20,
      ),
    );
  }
}

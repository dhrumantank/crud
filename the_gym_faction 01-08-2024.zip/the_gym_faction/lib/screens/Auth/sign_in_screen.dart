import 'package:TheGymFaction/extensions/app_loading_button.dart';
import 'package:TheGymFaction/extensions/colors.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:TheGymFaction/screens/Auth/gym_details_screen.dart';
import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/material.dart';

import '../../../extensions/extension_util/context_extensions.dart';
import '../../../extensions/extension_util/int_extensions.dart';
import '../../../extensions/extension_util/widget_extensions.dart';
import '../../../main.dart';
import '../../../utils/app_images.dart';
import '../../extensions/app_text_field.dart';
import '../../extensions/constants.dart';
import '../../extensions/decorations.dart';
import '../../extensions/shared_pref.dart';
import '../../extensions/text_styles.dart';
import '../../notification_service.dart';
import '../../utils/app_colors.dart';
import '../../utils/app_common.dart';
import '../../utils/app_config.dart';
import '../../utils/app_constants.dart';

class SignInScreen extends StatefulWidget {
  final bool? isDeletedUser;
  final String? deleteMessage;
  const SignInScreen({super.key, this.isDeletedUser, this.deleteMessage});

  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  GlobalKey<FormState> mFormKey = GlobalKey<FormState>();
  TextEditingController mPassCont = TextEditingController();
  TextEditingController phoneNumberController = TextEditingController();
  FocusNode mPassFocus = FocusNode();
  FocusNode phoneNumberFocus = FocusNode();
  bool addData = false;

  void loginData() async {
    String? token = await NotificationService().getFCMToken();
    if (phoneNumberController.text.isNotEmpty && mPassCont.text.isNotEmpty) {
      Map<String, dynamic> req = {
        'phone_number': phoneNumberController.text.trim(),
        'password': mPassCont.text.trim(),
        'device_token': token.toString(),
        // 'gymOwner_id': gymId,
      };
      setState(() => addData = true);
      try {
        loginWithPhoneNumber(req).then((value) {
          if (value.success == true) {
            toast(value.message);
            // DashboardScreen().launch(context, isNewTask: true);
            const GymDetailsScreen().launch(context);
          }
          setState(() => addData = false);
        });
      } catch (e) {
        setState(() => addData = false);
      }
    } else if (phoneNumberController.text.isEmpty && mPassCont.text.isEmpty) {
      toast("Fill All Details");
    } else if (phoneNumberController.text.isEmpty) {
      toast("Enter PhoneNumber");
    } else if (mPassCont.text.isEmpty) {
      toast("Enter Password");
    }
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Container(
      decoration: const BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
            appRedColor,
            whiteColor,
            whiteColor,
            whiteColor,
            whiteColor,
            whiteColor,
            whiteColor,
            appRedColor,
          ])),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SingleChildScrollView(
          padding: EdgeInsets.only(top: context.statusBarHeight + 16),
          child: Form(
            key: mFormKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                (h * 0.13).toInt().height,
                Image(
                  image: const AssetImage(ic_logo),
                  height: h * 0.18,
                  width: w * 0.36,
                ).center(),
                Text(
                  "Login With The Gym Faction",
                  style: boldTextStyle(size: 16),
                ).center(),
                (h * 0.05).toInt().height,
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(languages.lblPhoneNumber, style: secondaryTextStyle()),
                    6.height,
                    AppTextField(
                      controller: phoneNumberController,
                      textFieldType: TextFieldType.PHONE,
                      isValidationRequired: true,
                      suffix: mSuffixTextFieldIconWidget(ic_call),
                      decoration: defaultInputDecoration(context,
                          label: languages.lblEnterPhoneNumber,
                          mPrefix: IntrinsicHeight(
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                CountryCodePicker(
                                  initialSelection: getStringAsync(COUNTRY_CODE,
                                      defaultValue: countryCode!),
                                  showCountryOnly: false,
                                  showFlag: false,
                                  boxDecoration: BoxDecoration(
                                      borderRadius: radius(defaultRadius),
                                      color: context.scaffoldBackgroundColor),
                                  showFlagDialog: true,
                                  showOnlyCountryWhenClosed: false,
                                  alignLeft: false,
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 4),
                                  textStyle: primaryTextStyle(),
                                  onInit: (c) {
                                    countryCode = c!.dialCode;
                                    setValue(COUNTRY_CODE, c.code);
                                  },
                                  onChanged: (c) {
                                    countryCode = c.dialCode;
                                    setValue(COUNTRY_CODE, c.code);
                                  },
                                ),
                                VerticalDivider(
                                    color: Colors.grey.withOpacity(0.5)),
                                16.width,
                              ],
                            ),
                          )),
                    ),
                    16.height,
                    Text(languages.lblPassword,
                        style:
                            secondaryTextStyle(color: textPrimaryColorGlobal)),
                    4.height,
                    AppTextField(
                      controller: mPassCont,
                      focus: mPassFocus,
                      textFieldType: TextFieldType.PASSWORD,
                      keyboardType: TextInputType.visiblePassword,
                      decoration: defaultInputDecoration(context,
                          label: languages.lblEnterPassword),
                      onFieldSubmitted: (c) {
                        loginData();
                      },
                    ),
                    60.height,
                    AppLoadingButton(
                      isLoading: addData,
                      text: languages.lblLogin,
                      width: context.width(),
                      color: primaryColor,
                      onTap: () {
                        if (mFormKey.currentState!.validate()) {
                          loginData();
                        }
                      },
                    ).center(),
                    24.height,
                  ],
                ).paddingSymmetric(horizontal: 16, vertical: 4),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

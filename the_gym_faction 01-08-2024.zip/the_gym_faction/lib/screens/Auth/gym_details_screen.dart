import 'package:TheGymFaction/extensions/extension_util/context_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:TheGymFaction/main.dart';
import 'package:TheGymFaction/models/user_gym_details.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:flutter/material.dart';

import '../../extensions/app_button.dart';
import '../../extensions/loader_widget.dart';
import '../../utils/app_colors.dart';
import '../dashboard_screen.dart';

class GymDetailsScreen extends StatefulWidget {
  const GymDetailsScreen({super.key});

  @override
  State<GymDetailsScreen> createState() => _GymDetailsScreenState();
}

class _GymDetailsScreenState extends State<GymDetailsScreen> {
  UserGymDetails userGymDetails = UserGymDetails();

  void fetchUserGymDetails() {
    setState(() {
      appStore.setLoading(true);
    });
    getUserGymDetailsApi().then((value) {
      userGymDetails = value;
      setState(() {
        appStore.setLoading(false);
      });
      return;
    });
  }

  @override
  void initState() {
    fetchUserGymDetails();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Scaffold(
      body: appStore.isLoading
          ? const Loader().center().visible(appStore.isLoading)
          : Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Image(
                  image: NetworkImage(userGymDetails.data!.logo!),
                ).center(),
                (h * 0.024).toInt().height,
                Text(
                  "${userGymDetails.data!.ownerName}",
                  style: boldTextStyle(size: 30),
                ),
                (h * 0.024).toInt().height,
                Text(
                  "Welcome To",
                  style: secondaryTextStyle(size: 25),
                ),
                5.height,
                Text(
                  "${userGymDetails.data!.gymName}",
                  style: boldTextStyle(size: 30),
                ),
                10.height,
                Text(
                  "${userGymDetails.data!.address}",
                  style: secondaryTextStyle(),
                  textAlign: TextAlign.center,
                ),
                (h * 0.03).toInt().height,
                AppButton(
                  color: primaryColor,
                  margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  width: context.width(),
                  onTap: () {
                    const DashboardScreen().launch(context, isNewTask: true);
                  },
                  text: "Start Your Journey Now",
                )
              ],
            ).paddingSymmetric(horizontal: 20),
    );
  }
}

import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:TheGymFaction/utils/app_common.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shimmer/shimmer.dart';

import '../../../extensions/app_button.dart';
import '../../../extensions/extension_util/context_extensions.dart';
import '../../../extensions/extension_util/widget_extensions.dart';
import '../../../utils/app_images.dart';
import '../../extensions/colors.dart';
import '../../extensions/common.dart';
import '../../extensions/shared_pref.dart';
import '../../extensions/text_styles.dart';
import '../../main.dart';
import '../../models/walk_through_model.dart';
import '../../utils/app_colors.dart';
import '../../utils/app_config.dart';
import '../../utils/app_constants.dart';
import 'sign_in_screen.dart';

class WalkThroughScreen extends StatefulWidget {
  const WalkThroughScreen({super.key});

  @override
  State<WalkThroughScreen> createState() => _WalkThroughScreenState();
}

class _WalkThroughScreenState extends State<WalkThroughScreen> {
  PageController mPageController = PageController();
  List<WalkThroughModel> mWalkList = [];
  int mCurrentIndex = 0;
  bool getData = false;
  bool skip = false;

  void fetchSplashScreenData() {
    setState(() => getData = true);
    try {
      getSplashScreenApi().then((value) {
        for (var element in value.data!) {
          mWalkList.add(WalkThroughModel(
              image: element.image, title: element.description));
        }
        setState(() => getData = false);
      });
    } catch (e) {
      setState(() {
        getData = false;
        skip = true;
      });
      toast("$e");
    }
  }

  @override
  void initState() {
    super.initState();
    fetchSplashScreenData();
  }

  init() async {
    //
    mWalkList.add(WalkThroughModel(image: ic_walk1, title: WALK1_TITLE));
    mWalkList.add(WalkThroughModel(image: ic_walk2, title: WALK2_TITLE));
    mWalkList.add(WalkThroughModel(image: ic_walk3, title: WALK3_TITLE));
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  void dispose() {
    mPageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion(
      value: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness:
            appStore.isDarkMode ? Brightness.light : Brightness.dark,
        systemNavigationBarIconBrightness:
            appStore.isDarkMode ? Brightness.light : Brightness.dark,
      ),
      child: Scaffold(
        body: getData
            ? ShimmerEffectScreen(skip: skip)
            : Stack(
                children: [
                  PageView(
                    controller: mPageController,
                    children: mWalkList.map((e) {
                      return Column(
                        children: [
                          cachedImage(mWalkList[mCurrentIndex].image!,
                              height: context.height() * 0.55,
                              fit: BoxFit.fill),
                          // Image.network(
                          //   mWalkList[mCurrentIndex].image!,
                          //   height: context.height() * 0.55,
                          // ).paddingSymmetric(horizontal: 10),
                        ],
                      ).paddingTop(context.statusBarHeight + 30);
                    }).toList(),
                    onPageChanged: (i) {
                      mCurrentIndex = i;
                      setState(() {});
                    },
                  ),
                  Positioned(
                    top: context.statusBarHeight,
                    right: 4,
                    child: TextButton(
                        style: ButtonStyle(
                            overlayColor:
                                MaterialStateProperty.all(Colors.transparent)),
                        onPressed: () {
                          setValue(IS_FIRST_TIME, true);
                          const SignInScreen().launch(context);
                        },
                        child: Text(languages.lblSkip,
                            style: boldTextStyle(color: primaryColor))),
                  ).visible(mCurrentIndex != 2),
                  Positioned(
                    right: 24,
                    left: 24,
                    bottom: 50,
                    child: Column(
                      children: [
                        Text(mWalkList[mCurrentIndex].title.toString(),
                            style: boldTextStyle(size: 22),
                            textAlign: TextAlign.center),
                        16.height,
                        dotIndicator(mWalkList, mCurrentIndex),
                        30.height,
                        AppButton(
                          text: mCurrentIndex == 2
                              ? languages.lblGetStarted
                              : languages.lblNext,
                          width: context.width(),
                          color: primaryColor,
                          onTap: () {
                            if (mCurrentIndex.toInt() >= 2) {
                              setValue(IS_FIRST_TIME, true);
                              const SignInScreen().launch(context);
                            } else {
                              mPageController.nextPage(
                                duration: const Duration(seconds: 1),
                                curve: Curves.linearToEaseOut,
                              );
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

class ShimmerEffectScreen extends StatelessWidget {
  const ShimmerEffectScreen({super.key, required this.skip});
  final bool skip;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Column(
      children: [
        Stack(
          children: [
            Shimmer.fromColors(
                baseColor: Colors.grey.shade300,
                highlightColor: whiteColor,
                child: Container(
                  height: h * 0.65,
                  color: Colors.grey.shade200,
                )),
            Positioned(
              top: 50,
              right: 10,
              child: Shimmer.fromColors(
                  baseColor: Colors.grey.shade400,
                  highlightColor: whiteColor,
                  child: Container(
                    height: h * 0.03,
                    width: w * 0.2,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade400,
                      borderRadius: BorderRadius.circular(20),
                    ),
                  )),
            ),
          ],
        ),
        20.height,
        Shimmer.fromColors(
            baseColor: Colors.grey.shade300,
            highlightColor: whiteColor,
            child: Container(
              height: h * 0.025,
              width: w * 0.7,
              decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(5),
              ),
            )),
        10.height,
        Shimmer.fromColors(
            baseColor: Colors.grey.shade300,
            highlightColor: whiteColor,
            child: Container(
              height: h * 0.025,
              width: w * 0.35,
              decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(5),
              ),
            )),
        20.height,
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Shimmer.fromColors(
                baseColor: Colors.grey.shade300,
                highlightColor: whiteColor,
                child: Container(
                  height: h * 0.013,
                  width: w * 0.12,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(5),
                  ),
                )),
            10.width,
            Shimmer.fromColors(
                baseColor: Colors.grey.shade300,
                highlightColor: whiteColor,
                child: Container(
                  height: h * 0.013,
                  width: w * 0.12,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(5),
                  ),
                )),
            10.width,
            Shimmer.fromColors(
                baseColor: Colors.grey.shade300,
                highlightColor: whiteColor,
                child: Container(
                  height: h * 0.013,
                  width: w * 0.12,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(5),
                  ),
                )),
            10.width,
          ],
        ),
        40.height,
        skip
            ? AppButton(
                text: languages.lblGetStarted,
                width: context.width(),
                color: primaryColor,
                onTap: () {
                  setValue(IS_FIRST_TIME, true);
                  const SignInScreen().launch(context);
                },
              )
            : Shimmer.fromColors(
                baseColor: Colors.grey.shade300,
                highlightColor: whiteColor,
                child: Container(
                  height: h * 0.06,
                  width: w * 0.7,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
      ],
    );
  }
}

import 'dart:convert';
import 'dart:io';

import 'package:TheGymFaction/extensions/app_button.dart';
import 'package:TheGymFaction/extensions/app_text_field.dart';
import 'package:TheGymFaction/extensions/decorations.dart';
import 'package:TheGymFaction/extensions/extension_util/context_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/models/book_reading_response.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:image_picker/image_picker.dart';

import '../../components/fast_and_meditation_shimmer_effect.dart';
import '../../extensions/colors.dart';
import '../../extensions/constants.dart';
import '../../extensions/text_styles.dart';
import '../../main.dart';
import '../../network/network_utils.dart';
import '../../utils/app_colors.dart';
import '../../utils/app_common.dart';
import '../../utils/app_config.dart';
import '../../utils/app_images.dart';

class BooksReadingScreen extends StatefulWidget {
  const BooksReadingScreen({super.key});

  @override
  State<BooksReadingScreen> createState() => _BooksReadingScreenState();
}

class _BooksReadingScreenState extends State<BooksReadingScreen> {
  TextEditingController bookNameController = TextEditingController();
  TextEditingController authorController = TextEditingController();
  BookReadingResponse bookReadingResponse = BookReadingResponse(data: []);
  BookHistoryResponse bookHistoryResponse = BookHistoryResponse(data: []);
  final formKey = GlobalKey<FormState>();
  bool select = true;
  bool getData = false;
  bool getHistoryData = false;

  void fetchBookReadingData() {
    setState(() => getData = true);
    getBookReadingApi().then((value) {
      bookReadingResponse = value;
      setState(() => getData = false);
    });
  }

  void fetchCreateBookData() {
    Map<String, dynamic> req = {
      "book_name": bookNameController.text,
      "author": authorController.text,
    };
    getCreateBookApi(req).then((value) {
      if (value["success"] == true) {
        fetchBookReadingData();
      }
      toast(value["message"]);
    });
  }

  void fetchCreateBookSummaryData(Map<String, dynamic> req) async {
    MultipartRequest multiPartRequest = await getMultiPartRequest(
        "create-book-summary",
        baseUrl: "${mBaseUrl}create-book-summary");
    multiPartRequest.fields['book_id'] = "${req["book_id"]}";
    multiPartRequest.fields['learn'] = req['learn'];
    multiPartRequest.fields['pages'] = req['pages'];
    if (req["image"] != null) {
      multiPartRequest.files
          .add(await MultipartFile.fromPath('image', req["image"]));
    }
    multiPartRequest.headers.addAll(buildHeaderTokens());
    sendMultiPartRequest(
      multiPartRequest,
      onSuccess: (data) {
        var res = jsonDecode(data);
        if (res["success"] == true) {
          fetchBookHistoryApiData();
        }
        toast(res["message"]);
      },
      onError: (p0) {
        print("================== Error ==================");
        print(p0);
        print("================== Error ==================");
      },
    );
  }

  void fetchBookHistoryApiData() {
    setState(() => getHistoryData = true);
    getBookHistoryApi().then((value) {
      bookHistoryResponse = value;
      setState(() => getHistoryData = false);
    });
  }

  @override
  void initState() {
    fetchBookReadingData();
    fetchBookHistoryApiData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    return Scaffold(
      floatingActionButton: select
          ? Transform.scale(
              scale: 1.1,
              child: FloatingActionButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) => AddBook(
                      formKey: formKey,
                      onTap: () {
                        if (formKey.currentState!.validate()) {
                          fetchCreateBookData();
                          Navigator.pop(context);
                        }
                      },
                      bookNameController: bookNameController,
                      authorController: authorController,
                    ),
                  );
                },
                child: Text(
                  "Add\nBook",
                  style: boldTextStyle(color: whiteColor, size: 12),
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : const SizedBox(),
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(h * 0.14),
        child: Column(
          children: [
            (h * 0.03).toInt().height,
            ListTile(
              leading: IconButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: const Icon(
                  Icons.arrow_back_ios_new_outlined,
                  color: black,
                ),
              ),
              titleAlignment: ListTileTitleAlignment.center,
              title: Text(
                "Books Reading",
                style: boldTextStyle(),
              ),
            ),
            CustomTabBar(
              select: select,
              fistOnTap: () {
                setState(() {
                  select = !select;
                });
              },
              secondOnTap: () {
                setState(() {
                  select = !select;
                });
              },
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: select
            ? getData
                ? const FastAndMeditationHistoryShimmer()
                : BooksReadingList(
                    onTap: (id) {
                      showDialog(
                        context: context,
                        builder: (context) => AddReadBookPage(
                          onTap: (value) async {
                            Map<String, dynamic> req = {
                              "book_id": id,
                              "image": value["image"],
                              "learn": value["learn"],
                              "pages": value["page"],
                            };
                            fetchCreateBookSummaryData(req);
                            Navigator.pop(context);
                          },
                        ),
                      );
                    },
                    bookReadingResponse: bookReadingResponse,
                  )
            : getHistoryData
                ? const FastAndMeditationHistoryShimmer()
                : BookHistory(
                    bookHistoryResponse: bookHistoryResponse,
                  ),
      ),
    );
  }
}

class BooksReadingList extends StatelessWidget {
  const BooksReadingList(
      {super.key, required this.bookReadingResponse, required this.onTap});
  final BookReadingResponse bookReadingResponse;
  final void Function(int) onTap;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Column(
      children: [
        10.height,
        ListView.builder(
          itemCount: bookReadingResponse.data!.length,
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemBuilder: (context, index) {
            BookReadingDatum bookReading = bookReadingResponse.data![index];
            return Container(
              decoration: BoxDecoration(
                color: whiteColor,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.shade200,
                    spreadRadius: 2,
                    blurRadius: 10,
                  )
                ],
                borderRadius: BorderRadius.circular(12),
              ),
              child: ListTile(
                onTap: () {
                  onTap(bookReading.id!);
                },
                leading: Container(
                  alignment: Alignment.center,
                  width: w * 0.11,
                  height: h * 0.05,
                  child: const ImageIcon(
                    AssetImage(books),
                    size: 30,
                  ),
                ),
                title: Text(
                  bookReading.bookName.toString(),
                  style: boldTextStyle(size: 14),
                ),
                subtitle: Text(
                  bookReading.author.toString(),
                  style: boldTextStyle(size: 12),
                ),
                trailing: Container(
                  decoration: BoxDecoration(
                    color: black,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Text(
                    "Add Read Page",
                    style: boldTextStyle(
                      size: 12,
                      color: whiteColor,
                    ),
                  ).paddingSymmetric(vertical: 4, horizontal: 8),
                ),
              ),
            ).paddingSymmetric(horizontal: 20, vertical: 5);
          },
        )
      ],
    );
  }
}

class AddBook extends StatelessWidget {
  const AddBook(
      {super.key,
      required this.bookNameController,
      required this.authorController,
      required this.onTap,
      required this.formKey});
  final TextEditingController bookNameController;
  final TextEditingController authorController;
  final void Function() onTap;
  final GlobalKey<FormState> formKey;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        height: h * 0.47,
        width: w,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: whiteColor,
        ),
        child: Form(
          key: formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              (h * 0.05).toInt().height,
              Text(
                "Add Book",
                style: boldTextStyle(size: 20),
              ).center(),
              (h * 0.02).toInt().height,
              Text(
                "Add BooK Name",
                style: boldTextStyle(size: 14),
              ),
              (h * 0.01).toInt().height,
              AppTextField(
                validator: (value) {
                  bool valid = RegExp('[a-zA-Z]').hasMatch(value!);
                  if (valid) {
                    return null;
                  } else {
                    return "Please Enter Book Name";
                  }
                },
                controller: bookNameController,
                textFieldType: TextFieldType.NAME,
                decoration: defaultInputDecoration(context, label: "Book Name"),
              ),
              (h * 0.02).toInt().height,
              Text(
                "Author",
                style: boldTextStyle(size: 14),
              ),
              (h * 0.01).toInt().height,
              AppTextField(
                validator: (value) {
                  bool valid = RegExp('[a-zA-Z]').hasMatch(value!);
                  if (valid) {
                    return null;
                  } else {
                    return "Please Enter Author";
                  }
                },
                controller: authorController,
                textFieldType: TextFieldType.NAME,
                decoration: defaultInputDecoration(context, label: "Author"),
              ),
              (h * 0.05).toInt().height,
              AppButton(
                width: w * 0.4,
                text: "Add Book",
                onTap: onTap,
              ).center(),
            ],
          ).paddingSymmetric(horizontal: 20),
        ),
      ),
    );
  }
}

class AddReadBookPage extends StatefulWidget {
  const AddReadBookPage({super.key, required this.onTap});
  final void Function(dynamic) onTap;

  @override
  State<AddReadBookPage> createState() => _AddReadBookPageState();
}

class _AddReadBookPageState extends State<AddReadBookPage> {
  TextEditingController learnController = TextEditingController();
  ImagePicker imagePicker = ImagePicker();
  final formKey1 = GlobalKey<FormState>();
  String? noOfPages;
  File? fileImage;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Dialog(
      insetPadding: EdgeInsets.zero,
      backgroundColor: Colors.transparent,
      child: Container(
        height: h * 0.7,
        width: w * 0.9,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: whiteColor,
        ),
        child: Form(
          key: formKey1,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              (h * 0.05).toInt().height,
              Text(
                "Add Read Page",
                style: boldTextStyle(size: 20),
              ).center(),
              (h * 0.02).toInt().height,
              Container(
                width: w * 0.33,
                height: h * 0.14,
                child: Stack(
                  children: [
                    GestureDetector(
                      onTap: () async {
                        XFile? xFile = await imagePicker.pickImage(
                          source: ImageSource.camera,
                        );
                        fileImage = File(xFile!.path);
                        setState(() {});
                      },
                      child: fileImage != null
                          ? Container(
                              height: h * 0.11,
                              width: w * 0.25,
                              decoration: BoxDecoration(
                                color: Colors.grey.shade200,
                                borderRadius: BorderRadius.circular(100),
                                image: DecorationImage(
                                  image: FileImage(fileImage!),
                                ),
                              ),
                            ).center()
                          : CircleAvatar(
                              backgroundColor: Colors.grey.shade200,
                              radius: 50,
                              child: const Image(
                                image: AssetImage(bookPage),
                              ),
                            ).center(),
                    ),
                    Align(
                      alignment: Alignment.bottomRight,
                      child: CircleAvatar(
                        backgroundColor: Colors.grey.shade300,
                        radius: 15,
                        child: const Icon(
                          Icons.camera_alt_outlined,
                          size: 15,
                          color: black,
                        ),
                      ).paddingSymmetric(horizontal: 13, vertical: 15),
                    ),
                  ],
                ),
              ).center(),
              (h * 0.01).toInt().height,
              Text(
                "Read Page Image",
                style: boldTextStyle(size: 14),
              ).center(),
              (h * 0.02).toInt().height,
              Text(
                "Read Page",
                style: boldTextStyle(size: 14),
              ),
              (h * 0.01).toInt().height,
              DropdownButtonFormField(
                items: [for (var i = 1; i <= 50; i += 1) i]
                    .map((value) => DropdownMenuItem<String>(
                          child:
                              Text(value.toString(), style: primaryTextStyle()),
                          value: value.toString(),
                        ))
                    .toList(),
                isExpanded: false,
                isDense: true,
                menuMaxHeight: 300,
                borderRadius: radius(),
                decoration: defaultInputDecoration(context),
                value: '1',
                onChanged: (String? value) {
                  setState(() {
                    noOfPages = value;
                  });
                },
              ),
              (h * 0.02).toInt().height,
              Text(
                "Enter What Are You Learn",
                style: boldTextStyle(size: 14),
              ),
              (h * 0.01).toInt().height,
              AppTextField(
                validator: (value) {
                  bool valid = RegExp('[a-zA-Z]').hasMatch(value!);
                  if (valid) {
                    return null;
                  } else {
                    return "Please Enter What Are Learn";
                  }
                },
                controller: learnController,
                textFieldType: TextFieldType.NAME,
                decoration: defaultInputDecoration(context,
                    label: "What Are You Learn"),
              ),
              (h * 0.05).toInt().height,
              AppButton(
                width: w * 0.5,
                text: "Add Read Page",
                onTap: () {
                  if (formKey1.currentState!.validate()) {
                    Map<String, dynamic> value = {
                      "learn": learnController.text,
                      "page": noOfPages,
                      "image":
                          fileImage != null ? fileImage!.path.toString() : null
                    };
                    widget.onTap(value);
                  }
                },
              ).center(),
            ],
          ).paddingSymmetric(horizontal: 20),
        ),
      ),
    );
  }
}

class BookHistory extends StatelessWidget {
  const BookHistory({super.key, required this.bookHistoryResponse});
  final BookHistoryResponse bookHistoryResponse;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Column(
      children: [
        10.height,
        ListView.builder(
          itemCount: bookHistoryResponse.data!.length,
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemBuilder: (context, index) {
            BookHistoryDatum bookHistory = bookHistoryResponse.data![index];
            return Container(
              decoration: BoxDecoration(
                color: whiteColor,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.shade200,
                    spreadRadius: 2,
                    blurRadius: 10,
                  )
                ],
                borderRadius: BorderRadius.circular(12),
              ),
              child: ListTile(
                onTap: () {},
                leading: Container(
                  alignment: Alignment.center,
                  width: w * 0.11,
                  height: h * 0.05,
                  child: Image(
                    image: NetworkImage(bookHistory.image!),
                  ),
                ),
                title: Text(
                  bookHistory.title.toString(),
                  style: boldTextStyle(size: 14),
                ),
                subtitle: Text(
                  bookHistory.learn.toString(),
                  style: boldTextStyle(size: 12),
                ),
              ),
            ).paddingSymmetric(horizontal: 20, vertical: 5);
          },
        )
      ],
    );
  }
}

class CustomTabBar extends StatelessWidget {
  const CustomTabBar(
      {super.key, required this.select, this.fistOnTap, this.secondOnTap});
  final bool select;
  final void Function()? fistOnTap;
  final void Function()? secondOnTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(top: 22),
      decoration: BoxDecoration(
          border: Border(
              bottom: BorderSide(
                  color:
                      appStore.isDarkMode ? whiteColor : context.dividerColor,
                  width: 0.5))),
      child: Row(children: [
        GestureDetector(
          onTap: fistOnTap,
          child: Container(
              padding: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          width: 1.5,
                          color: select ? primaryColor : Colors.transparent))),
              child: Text("Add Reads Books",
                      style: boldTextStyle(
                          color:
                              select ? primaryColor : textSecondaryColorGlobal))
                  .center()),
        ).expand(),
        GestureDetector(
          onTap: secondOnTap,
          child: Container(
            padding: const EdgeInsets.only(bottom: 8),
            decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(
                        width: 1.5,
                        color: select ? Colors.transparent : primaryColor))),
            child: Text("Books Reading History",
                    style: boldTextStyle(
                        color:
                            select ? textSecondaryColorGlobal : primaryColor))
                .center(),
          ),
        ).expand(),
      ]).paddingSymmetric(horizontal: 16),
    );
  }
}

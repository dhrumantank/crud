import 'package:TheGymFaction/components/HomeComponent/daily_workout_component.dart';
import 'package:TheGymFaction/components/HomeComponent/start_exercise_dialog.dart';
import 'package:TheGymFaction/components/HomeComponent/today_workout_component.dart';
import 'package:TheGymFaction/components/HomeComponent/workout_days_component.dart';
import 'package:TheGymFaction/extensions/extension_util/date_time_extensions.dart';
import 'package:TheGymFaction/extensions/shared_pref.dart';
import 'package:TheGymFaction/extensions/system_utils.dart';
import 'package:TheGymFaction/screens/Auth/sign_in_screen.dart';
import 'package:TheGymFaction/screens/Home/TodayExercises/today_workout.dart';
import 'package:TheGymFaction/screens/Home/TodayExercises/week_workout_days.dart';
import 'package:TheGymFaction/service/auth_service.dart';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:flutter_vector_icons/flutter_vector_icons.dart';

import '../../../extensions/decorations.dart';
import '../../../extensions/extension_util/context_extensions.dart';
import '../../../extensions/extension_util/int_extensions.dart';
import '../../../extensions/extension_util/string_extensions.dart';
import '../../../extensions/extension_util/widget_extensions.dart';
import '../../../main.dart';
import '../../components/HomeComponent/body_part_component.dart';
import '../../components/HomeComponent/card_dialog_box_component.dart';
import '../../components/HomeComponent/fasting_books_reading_meditation_component.dart';
import '../../components/HomeComponent/page_view_list.dart';
import '../../components/HomeComponent/show_one_time_dialog.dart';
import '../../components/HomeComponent/water_intake_component.dart';
import '../../components/HomeComponent/weight_report_component.dart';
import '../../components/homes_shimmer_effect_screen.dart';
import '../../components/progress_component.dart';
import '../../extensions/animatedList/animated_wrap.dart';
import '../../extensions/colors.dart';
import '../../extensions/horizontal_list.dart';
import '../../extensions/text_styles.dart';
import '../../models/daily_workout_charts_model.dart';
import '../../models/dashboard_response.dart';
import '../../models/weight_graph_model.dart';
import '../../network/rest_api.dart';
import '../../utils/app_colors.dart';
import '../../utils/app_common.dart';
import '../../utils/app_constants.dart';
import '../ProfileScreen/edit_profile_screen.dart';
import 'BodyPart/view_body_part_screen.dart';
import 'Equipment/view_equipment_screen.dart';
import 'Exercise/exercise_list_screen.dart';
import 'TodayExercises/edit_workout_days.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  ScrollController mScrollController = ScrollController();
  TextEditingController mSearchCont = TextEditingController();
  WeightGraphResponse weightGraphResponse = WeightGraphResponse(data: []);
  WeightGraphResponse userDeletedResponse = WeightGraphResponse(data: []);
  WeightGraphResponse waterGraphResponse = WeightGraphResponse(data: []);
  DailyWorkoutCharts dailyWorkoutCharts = DailyWorkoutCharts(data: []);
  bool addWater = false;
  bool addWeightGraph = false;
  bool addDailyWorkoutGraph = false;

  void fetchWeightGraphResponse() {
    setState(() => addWeightGraph = true);
    getWeightGraphResponse().then((value) {
      weightGraphResponse = value;
      setState(() => addWeightGraph = false);
    });
  }

  void fetchUserDeleteResponse() {
    getUserDeleteResponse().then((value) async {
      userDeletedResponse = value;
      if (userDeletedResponse.success == false) {
        await logout(context).then((value) async {
          appStore.setLoading(false);
          await removeKey(EMAIL);
          await removeKey(PASSWORD);
          await removeKey(IS_REMEMBER);
          AwesomeNotifications().dispose();
          SignInScreen(
                  isDeletedUser: true,
                  deleteMessage: userDeletedResponse.message)
              .launch(context);
        });
        finish(context);
      }

      return null;
    });
  }

  void fetchWaterGraphResponse() {
    setState(() => addWater = true);
    getWaterGraphResponse().then((value) {
      waterGraphResponse = value;
      setState(() => addWater = false);
      return null;
    });
  }

  void fetchDailyWorkoutChartsResponse() {
    setState(() => addDailyWorkoutGraph = true);
    getDailyWorkoutChartsResponse().then((value) {
      dailyWorkoutCharts = value;
      setState(() => addDailyWorkoutGraph = false);
      return null;
    });
  }

  String? mSearchValue = "";
  bool showClearButton = false;

  @override
  void initState() {
    fetchUserDeleteResponse();
    fetchWeightGraphResponse();
    fetchWaterGraphResponse();
    fetchDailyWorkoutChartsResponse();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (appStore.isShowDialog) {
        showCardContainer();
      }
    });

    super.initState();
  }

  Widget mHeading(String? title, {bool? isSeeAll = false, Function? onCall}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title!, style: boldTextStyle(size: 18))
            .paddingSymmetric(horizontal: 16),
        IconButton(
            splashColor: Colors.transparent,
            highlightColor: Colors.transparent,
            icon: const Icon(Feather.chevron_right, color: primaryColor),
            onPressed: () {
              onCall!.call();
            }).paddingRight(2),
      ],
    );
  }

  void showCardContainer() {
    getRemainingExerciseApi().then((value) {
      if (value.success == true) {
        if (value.data!.isNotEmpty) {
          showDialog(
            useSafeArea: false,
            context: context,
            builder: (context) {
              if (value.data!.length > 1) {
                return const CardDialogBox(checkLength: true);
              } else {
                return const CardDialogBox(checkLength: false);
              }
            },
          );
        } else {
          if (appStore.isShowOneTimeDialog) {
            showDialog(
                context: context,
                builder: (context) => const ShowOneTimeDialog());
          }
        }
      } else {
        if (appStore.isShowOneTimeDialog) {
          showDialog(
                  context: context,
                  builder: (context) =>
                      const ShowOneTimeDialog(showStartExercise: true))
              .then((value) {
            if (appStore.isTodayWeightDataGet == true) {
              fetchWeightGraphResponse();
              appStore.setTodayWeightDataGet(false);
              setState(() {});
            }
          });
        } else {
          showDialog(
              context: context,
              builder: (context) => const StartExerciseDialog());
        }
      }
      return null;
    });
    appStore.setShowDialog(false);
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(h * 0.09),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Observer(builder: (context) {
                  return Container(
                          decoration: boxDecorationWithRoundedCorners(
                              boxShape: BoxShape.circle,
                              border:
                                  Border.all(color: primaryColor, width: 1)),
                          child: cachedImage(userStore.profileImage.validate(),
                                  width: 42, height: 42, fit: BoxFit.cover)
                              .cornerRadiusWithClipRRect(100)
                              .paddingAll(1))
                      .onTap(() {
                    const EditProfileScreen().launch(context);
                  });
                }),
                10.width,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                        "${languages.lblHey}${userStore.fName.validate().capitalizeFirstLetter()} ${userStore.lName.capitalizeFirstLetter()}👋",
                        style: boldTextStyle(size: 18),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 2),
                    appStore.selectedLanguageCode == 'ar '
                        ? 0.height
                        : 2.height,
                    Text(languages.lblHomeWelMsg, style: secondaryTextStyle()),
                  ],
                ).expand(),
              ],
            ).expand(),
          ],
        ).paddingOnly(
            top: context.statusBarHeight + 16, left: 16, right: 16, bottom: 8),
      ),
      body: RefreshIndicator(
        backgroundColor: context.scaffoldBackgroundColor,
        onRefresh: () {
          return Future.delayed(
            const Duration(seconds: 1),
            () {
              setState(() {
                fetchUserDeleteResponse();
                // removeKey(TodayDateTime);
                fetchDailyWorkoutChartsResponse();
              });
            },
          );
        },
        child: FutureBuilder(
          future: getDashboardApi(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              DashboardResponse? mDashboardResponse = snapshot.data;
              return SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        mHeading(languages.workoutDays, onCall: () {
                          const EditWorkoutDays().launch(context);
                        }),
                        HorizontalList(
                          physics: const BouncingScrollPhysics(),
                          controller: mScrollController,
                          itemCount: mDashboardResponse!.workoutDays!.length,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 8),
                          spacing: 14,
                          itemBuilder: (context, index) {
                            return WorkoutDaysComponent(
                              onTap: () {
                                mDashboardResponse
                                        .workoutDays![index].status.isUpcoming
                                    ? ExerciseListScreen(
                                        mTitle: mDashboardResponse
                                            .workoutDays![index].title
                                            .toString(),
                                        isBodyPart: true,
                                        id: mDashboardResponse
                                            .workoutDays![index].id!,
                                      ).launch(context)
                                    : WeekWorkoutDays(
                                        isTodayExercises: mDashboardResponse
                                            .workoutDays![index]
                                            .todayDate!
                                            .isToday,
                                        id: index + 1,
                                        workoutId: mDashboardResponse
                                            .workoutDays![index].id!,
                                        todayDate: mDashboardResponse
                                            .workoutDays![index].todayDate!,
                                      ).launch(context).then((value) {
                                        fetchDailyWorkoutChartsResponse();
                                        return;
                                      });
                              },
                              todayDate: mDashboardResponse
                                  .workoutDays![index].todayDate,
                              indexId: index + 1,
                              title: mDashboardResponse
                                  .workoutDays![index].title
                                  .toString(),
                              workoutStates: mDashboardResponse
                                  .workoutDays![index].status
                                  .toString(),
                              dayName:
                                  mDashboardResponse.workoutDays![index].day!,
                              id: mDashboardResponse.workoutDays![index].id!,
                            );
                          },
                        ),
                      ],
                    ).visible(mDashboardResponse.workoutDays!.isNotEmpty),
                    16.height,
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(languages.todayWorkout,
                            style: boldTextStyle(size: 18)),
                        10.height,
                        TodayWorkoutComponent(
                          name:
                              mDashboardResponse.dailyWorkout![0].bodyPartName!,
                          image: mDashboardResponse
                              .dailyWorkout![0].workoutBackground!,
                          complete: mDashboardResponse
                              .dailyWorkout![0].completeExerciseCount!,
                          total: mDashboardResponse
                              .dailyWorkout![0].exerciseCount!,
                        ).onTap(() {
                          TodayWorkout(
                            bodyPartName: mDashboardResponse
                                .dailyWorkout![0].bodyPartName!,
                          ).launch(context).then(
                              (value) => fetchDailyWorkoutChartsResponse());
                        }),
                      ],
                    ).paddingSymmetric(horizontal: 12),
                    16.height,
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        mHeading(languages.lblBodyPartExercise, onCall: () {
                          const ViewBodyPartScreen().launch(context);
                        }),
                        SingleChildScrollView(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          child: AnimatedWrap(
                            runSpacing: 18,
                            spacing: 16,
                            children: List.generate(
                                mDashboardResponse.bodypart!.length, (index) {
                              return BodyPartComponent(
                                  bodyPartModel:
                                      mDashboardResponse.bodypart![index],
                                  isGrid: false);
                            }),
                          ),
                        ),
                      ],
                    ).visible(mDashboardResponse.bodypart!.isNotEmpty),
                    16.height,
                    DailyWorkout(
                      chartList: dailyWorkoutCharts.data!,
                      checkGetData: addDailyWorkoutGraph,
                    ),
                    20.height,
                    WeightReport(
                      check: addWeightGraph,
                      onTap: () async {
                        await showModalBottomSheet(
                            isScrollControlled: true,
                            context: context,
                            backgroundColor: appStore.isDarkMode
                                ? cardDarkColor
                                : cardLightColor,
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    radiusOnly(topRight: 18, topLeft: 18)),
                            builder: (context) {
                              return ProgressComponent(
                                mType: METRICS_WEIGHT,
                                mUnit: METRICS_WEIGHT_UNIT,
                                onCall: () {
                                  // init();
                                  setState(() {
                                    fetchWeightGraphResponse();
                                  });
                                },
                              );
                            });
                      },
                      chartData: weightGraphResponse.data!,
                    ),
                    16.height,
                    WaterIntake(
                      onTap: () async {
                        await showModalBottomSheet(
                            isScrollControlled: true,
                            context: context,
                            backgroundColor: appStore.isDarkMode
                                ? cardDarkColor
                                : cardLightColor,
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    radiusOnly(topRight: 18, topLeft: 18)),
                            builder: (context) {
                              return ProgressComponent(
                                mType: METRICS_WATER,
                                mUnit: METRICS_WATER_UNIT,
                                onCall: () {
                                  setState(() {
                                    fetchWaterGraphResponse();
                                  });
                                },
                              );
                            });
                      },
                      seriesList: waterGraphResponse.data!,
                      check: addWater,
                    ),
                    16.height,
                    const FastingBooksReadingMeditation(),
                    16.height,
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        10.height,
                        mHeading(languages.lblEquipmentsExercise, onCall: () {
                          const ViewEquipmentScreen().launch(context);
                        }),
                        PageViewList(
                          equipmentModel: mDashboardResponse.equipment!,
                        ),
                      ],
                    ).visible(mDashboardResponse.equipment!.isNotEmpty),
                  ],
                ),
              );
            } else {
              return const HomeShimmerEffectScreen();
            }
          },
        ),
      ),
    );
  }
}

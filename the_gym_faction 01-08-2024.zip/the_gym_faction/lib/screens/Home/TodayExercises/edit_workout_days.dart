import 'package:TheGymFaction/extensions/extension_util/context_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/string_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:TheGymFaction/utils/app_common.dart';
import 'package:animation_list/animation_list.dart';
import 'package:flutter/material.dart';

import '../../../extensions/app_button.dart';
import '../../../extensions/colors.dart';
import '../../../extensions/constants.dart';
import '../../../extensions/loader_widget.dart';
import '../../../extensions/widgets.dart';
import '../../../main.dart';
import '../../../models/user_exercise_list_model.dart';
import '../../no_data_screen.dart';

class EditWorkoutDays extends StatefulWidget {
  const EditWorkoutDays({super.key});

  @override
  State<EditWorkoutDays> createState() => _EditWorkoutDaysState();
}

class _EditWorkoutDaysState extends State<EditWorkoutDays> {
  String itemValue = "";

  Map editData = {};
  List newEditData = [];
  List<Part> hintList = [];
  List<Part> showList = [];
  bool sendData = false;

  UserExerciseList userExerciseList = UserExerciseList();

  @override
  void initState() {
    getEditData();
    super.initState();
  }

  void getEditData() {
    appStore.setLoading(true);
    getUserExerciseListApi().then((value) {
      userExerciseList = value;
      showList = value.bodyparts!;
      hintList = value.allBodyParts!;
      newEditData = value.userSelectedDay!;
      setState(() {
        appStore.setLoading(false);
      });
      return;
    });
  }

  void setEditData() {
    setState(() => sendData = true);
    Map<String, dynamic> req = {"exercisedays": newEditData.toString()};
    getUpdateUserExerciseApi(req).then((value) {
      toast(value["message"].toString());
      Navigator.pop(context);
      setState(() => sendData = false);
      return;
    });
  }

  @override
  Widget build(BuildContext context) {
    // final h = MediaQuery.of(context).size.height;
    // final w = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: appBarWidget(
        "Edit Workout Days".validate().capitalizeFirstLetter(),
        context: context,
      ),
      bottomNavigationBar: newEditData.isEmpty
          ? const SizedBox()
          : sendData == true
              ? MaterialButton(
                  height: 50,
                  shape: defaultAppButtonShapeBorder,
                  color: appButtonBackgroundColorGlobal,
                  minWidth: context.width(),
                  onPressed: () {},
                  child: const CircularProgressIndicator(
                    color: white,
                  ),
                ).paddingSymmetric(vertical: 18, horizontal: 20)
              : AppButton(
                  color: black,
                  margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  width: context.width(),
                  onTap: () {
                    setEditData();
                    // print(
                    //     "========================= EditData =======================");
                    // print(newEditData);
                    // print(
                    //     "========================= EditData =======================");
                  },
                  text: languages.lblContinue,
                ),
      body: appStore.isLoading
          ? const Loader().center().visible(appStore.isLoading)
          : showList.isNotEmpty
              ? SingleChildScrollView(
                  child: Column(
                    children: [
                      AnimationList(
                        physics: const NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        duration: 4000,
                        children: List.generate(showList.length, (index) {
                          return EditFiled(
                            image: showList[index].image!,
                            title: showList[index].title!,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CircleAvatar(
                                  radius: 16,
                                  backgroundColor: black,
                                  child: PopupMenuButton(
                                    icon: const Icon(
                                      Icons.edit,
                                      size: 16,
                                    ),
                                    iconColor: whiteColor,
                                    itemBuilder: (context) {
                                      return List.generate(hintList.length,
                                          (index1) {
                                        return PopupMenuItem(
                                          onTap: () {
                                            showList[index] = hintList[index1];
                                            setState(() {
                                              newEditData[index] =
                                                  hintList[index1].id;
                                            });
                                          },
                                          value: hintList[index1].title,
                                          child: Text(
                                            hintList[index1].title!,
                                            style: boldTextStyle(
                                              color: const Color(0xFF8D8D8D),
                                            ),
                                          ),
                                        );
                                      });
                                    },
                                  ),
                                ),
                                8.height,
                                Container(
                                  decoration: BoxDecoration(
                                    color: black,
                                    // gradient: LinearGradient(
                                    //   begin: Alignment.topLeft,
                                    //   end: Alignment.bottomRight,
                                    //   // stops: [0.1, 0.5, 0.7, 0.9],
                                    //   colors: Colors[index],
                                    // ),
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                  child: Text(
                                    (index + 1).toWeekDay(),
                                    style: const TextStyle(
                                      fontSize: 13,
                                      color: whiteColor,
                                    ),
                                  ).paddingSymmetric(
                                      horizontal: 8, vertical: 3),
                                ),
                              ],
                            ),
                          );
                        }),
                      )
                    ],
                  ).paddingSymmetric(horizontal: 6),
                )
              : NoDataScreen(mTitle: languages.lblExerciseNoFound)
                  .visible(!appStore.isLoading),
    );
  }
}

class EditFiled extends StatelessWidget {
  const EditFiled({
    super.key,
    required this.image,
    required this.title,
    required this.child,
  });
  final String image;
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Container(
        height: h * 0.12,
        width: w * 0.9,
        decoration: BoxDecoration(
          border: Border.all(
            color: grey.withOpacity(0.2),
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            10.width,
            Container(
              alignment: Alignment.center,
              height: h * 0.07,
              width: w * 0.15,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(100),
                image: DecorationImage(
                  image: NetworkImage(image),
                ),
              ),
            ),
            15.width,
            Text(
              title,
              style: boldTextStyle(
                size: 16,
                color: black,
              ),
            ),
            const Spacer(),
            child,
            20.width
          ],
        ),
      ),
    ).paddingOnly(left: 10, bottom: 10);
  }
}

// class EditWorkoutShimmerEffect extends StatelessWidget {
//   const EditWorkoutShimmerEffect({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     final h = MediaQuery.of(context).size.height;
//     final w = MediaQuery.of(context).size.width;
//     return SingleChildScrollView(
//       child: Column(
//         children: [
//           ListView.builder(
//             shrinkWrap: true,
//             itemCount: 10,
//             physics: const NeverScrollableScrollPhysics(),
//             itemBuilder: (context, index) {
//               return SizedBox(
//                 height: h * 0.12,
//                 width: w * 0.9,
//                 child: Stack(
//                   children: [
//                     Shimmer.fromColors(
//                         baseColor: Colors.grey.shade200,
//                         highlightColor: Colors.white54,
//                         child: Container(
//                           height: h * 0.12,
//                           width: w * 0.9,
//                           decoration: BoxDecoration(
//                             boxShadow: [
//                               BoxShadow(
//                                 blurRadius: 10,
//                                 color: Colors.grey.shade200,
//                                 spreadRadius: 2,
//                               )
//                             ],
//                             color: Colors.grey.shade200,
//                             borderRadius: BorderRadius.circular(10),
//                           ),
//                         ).paddingSymmetric(horizontal: 20, vertical: 10)),
//                     Positioned(
//                       child: Column(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: [
//                           10.height,
//                           Row(
//                             crossAxisAlignment: CrossAxisAlignment.center,
//                             children: [
//                               40.width,
//                               Shimmer.fromColors(
//                                 baseColor: Colors.grey.shade300,
//                                 highlightColor: Colors.white54,
//                                 child: CircleAvatar(
//                                     radius: 30,
//                                     backgroundColor: Colors.grey.shade300),
//                               ),
//                               20.width,
//                               Column(
//                                 mainAxisAlignment: MainAxisAlignment.center,
//                                 crossAxisAlignment: CrossAxisAlignment.start,
//                                 children: [
//                                   Shimmer.fromColors(
//                                     baseColor: Colors.grey.shade300,
//                                     highlightColor: Colors.white54,
//                                     child: Container(
//                                       width: w * 0.4,
//                                       height: h * 0.02,
//                                       decoration: BoxDecoration(
//                                         borderRadius: BorderRadius.circular(5),
//                                         color: Colors.grey.shade300,
//                                       ),
//                                     ),
//                                   ),
//                                   5.height,
//                                   Shimmer.fromColors(
//                                     baseColor: Colors.grey.shade300,
//                                     highlightColor: Colors.white54,
//                                     child: Container(
//                                       width: w * 0.3,
//                                       height: h * 0.02,
//                                       decoration: BoxDecoration(
//                                         borderRadius: BorderRadius.circular(5),
//                                         color: Colors.grey.shade300,
//                                       ),
//                                     ),
//                                   ),
//                                 ],
//                               )
//                             ],
//                           ),
//                           Row(
//                             mainAxisAlignment: MainAxisAlignment.end,
//                             children: [
//                               Shimmer.fromColors(
//                                 baseColor: Colors.grey.shade300,
//                                 highlightColor: Colors.white54,
//                                 child: Container(
//                                   width: w * 0.2,
//                                   height: h * 0.02,
//                                   decoration: BoxDecoration(
//                                     borderRadius: BorderRadius.circular(5),
//                                     color: Colors.grey.shade300,
//                                   ),
//                                 ),
//                               ),
//                               30.width,
//                             ],
//                           ),
//                           10.height,
//                         ],
//                       ),
//                     )
//                   ],
//                 ),
//               );
//             },
//           ),
//         ],
//       ),
//     );
//   }
// }

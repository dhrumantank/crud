import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/string_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/models/workout_days_history_model.dart';
import 'package:animation_list/animation_list.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shimmer/shimmer.dart';
import 'package:timeline_tile/timeline_tile.dart';

import '../../../extensions/colors.dart';
import '../../../extensions/text_styles.dart';
import '../../../main.dart';
import '../../../network/rest_api.dart';
import '../../../utils/app_colors.dart';
import '../../../utils/app_common.dart';
import '../../no_data_screen.dart';
import '../Exercise/exercise_detail_screen.dart';

class WeekWorkoutDays extends StatefulWidget {
  const WeekWorkoutDays({
    super.key,
    this.todayDate,
    required this.id,
    required this.workoutId,
    required this.isTodayExercises,
  });
  final int id;
  final int workoutId;
  final DateTime? todayDate;
  final bool isTodayExercises;

  @override
  State<WeekWorkoutDays> createState() => _WeekWorkoutDaysState();
}

class _WeekWorkoutDaysState extends State<WeekWorkoutDays> {
  // ScrollController scrollController = ScrollController();
  WorkoutDaysHistory workoutDaysHistory = WorkoutDaysHistory(data: []);
  String workoutStatus = "workout";
  // int page = 1;
  // int? numPage;
  int activeStep = 0;
  String states = "1";
  bool upcoming = false;
  DateFormat format = DateFormat("dd-MM-yyyy");
  bool hasData = true;

  @override
  void initState() {
    super.initState();
    init();
  }

  void init() async {
    data();
  }

  void data() {
    appStore.setLoading(true);
    Map<String, dynamic> req = {
      "day_count": widget.id,
      "body_part_id": widget.workoutId,
    };
    getWorkoutDaysHistoryApi(req).then((value) {
      workoutStatus = value.status!.toString();
      workoutDaysHistory = value;
      if (workoutDaysHistory.data!.isEmpty) {
        hasData = false;
      }
      setState(() {
        appStore.setLoading(false);
      });
      return null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(65),
        child: Column(
          children: [
            20.height,
            ListTile(
              leading: IconButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: const Icon(
                  Icons.arrow_back_ios_new_outlined,
                  color: primaryColor,
                ),
              ),
              title: Text(
                "Workout Days",
                style: boldTextStyle(color: black),
              ),
              subtitle: Text(
                format.format(widget.todayDate!),
                style: const TextStyle(color: black),
              ),
            ),
          ],
        ),
      ),
      body: appStore.isLoading
          ? const SingleChildScrollView(child: ShimmerEffectScreen())
          : workoutDaysHistory.data!.isNotEmpty
              ? workoutStatus == "rest"
                  ? RestScreen(
                      workoutDaysHistory: workoutDaysHistory,
                    )
                  : SingleChildScrollView(
                      child: Column(
                        children: [
                          AnimationList(
                            physics: const NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            duration: 4000,
                            children: List.generate(
                                workoutDaysHistory.data!.length, (index) {
                              return CustomTimelineTile(
                                type:
                                    workoutDaysHistory.data![index].type ?? "",
                                duration:
                                    workoutDaysHistory.data![index].duration!,
                                isTodayExercises: widget.isTodayExercises,
                                onTap: () {
                                  if (widget.isTodayExercises) {
                                    ExerciseDetailScreen(
                                            check: workoutDaysHistory
                                                .data![index]
                                                .workoutStatus
                                                .isComplete,
                                            mExerciseName: workoutDaysHistory
                                                .data![index].title!
                                                .validate(),
                                            mExerciseId: workoutDaysHistory
                                                .data![index].id!
                                                .validate())
                                        .launch(context)
                                        .then((value) {
                                      data();
                                      return null;
                                    });
                                  }
                                },
                                exerciseTitle:
                                    workoutDaysHistory.data![index].title!,
                                image: workoutDaysHistory
                                    .data![index].exerciseImage!,
                                isFirst: index == 0,
                                isLast: index ==
                                    workoutDaysHistory.data!.length - 1,
                                workoutStatus: workoutDaysHistory
                                    .data![index].workoutStatus!,
                                sets: workoutDaysHistory.data![index].sets!,
                              );
                            }),
                          )
                        ],
                      ).paddingSymmetric(horizontal: 6),
                    )
              : NoDataScreen(mTitle: languages.lblExerciseNoFound)
                  .visible(!appStore.isLoading),
    );
  }
}

class CustomTimelineTile extends StatelessWidget {
  final bool isFirst;
  final bool isLast;
  final bool isTodayExercises;
  final String workoutStatus;
  final String image;
  final String exerciseTitle;
  final String? type;
  final List<WorkoutDayDuration>? duration;
  final List<Set> sets;
  final void Function() onTap;

  const CustomTimelineTile({
    super.key,
    required this.isFirst,
    required this.isLast,
    required this.workoutStatus,
    required this.image,
    required this.exerciseTitle,
    required this.sets,
    required this.onTap,
    required this.isTodayExercises,
    this.type,
    this.duration,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0),
      child: TimelineTile(
        isFirst: isFirst,
        isLast: isLast,
        indicatorStyle: IndicatorStyle(
          width: 25,
          height: 25,
          color: workoutStatus.isComplete
              ? greenColor
              : isTodayExercises
                  ? Colors.grey
                  : appRedColor,
          indicator: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: workoutStatus.isComplete
                  ? greenColor
                  : isTodayExercises
                      ? Colors.grey
                      : appRedColor,
            ),
            child: workoutStatus.isComplete
                ? const Center(
                    child: Icon(
                      Icons.check,
                      color: white,
                      size: 15,
                    ),
                  )
                : isTodayExercises
                    ? const SizedBox()
                    : const Center(
                        child: Icon(
                          Icons.close,
                          color: white,
                          size: 15,
                        ),
                      ),
          ),
        ),
        beforeLineStyle: LineStyle(
          thickness: 1.5,
          color: workoutStatus.isComplete
              ? greenColor
              : isTodayExercises
                  ? Colors.grey
                  : appRedColor,
        ),
        afterLineStyle: LineStyle(
          thickness: 1.5,
          color: workoutStatus.isComplete
              ? greenColor
              : isTodayExercises
                  ? Colors.grey
                  : appRedColor,
        ),
        endChild: ExerciseCard(
          type: type,
          duration: duration,
          isTodayExercises: isTodayExercises,
          workoutStatus: workoutStatus,
          onTap: onTap,
          exerciseTitle: exerciseTitle,
          exercise: workoutStatus,
          image: image,
          sets: sets,
        ),
      ),
    );
  }
}

class ExerciseCard extends StatelessWidget {
  final bool isTodayExercises;
  final String exercise;
  final String image;
  final String exerciseTitle;
  final String workoutStatus;
  final List<Set> sets;
  final void Function() onTap;
  final String? type;
  final List<WorkoutDayDuration>? duration;
  const ExerciseCard({
    super.key,
    required this.exercise,
    required this.image,
    required this.exerciseTitle,
    required this.sets,
    required this.onTap,
    required this.workoutStatus,
    required this.isTodayExercises,
    this.type,
    this.duration,
  });

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onTap,
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        child: Stack(
          children: [
            Container(
              height: h * 0.14,
              width: w,
              decoration: BoxDecoration(
                color: white,
                border: Border.all(
                    color: workoutStatus.isComplete
                        ? Colors.green.shade200
                        : isTodayExercises
                            ? Colors.blue.shade200
                            : appRedColor.withOpacity(0.3)),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  15.width,
                  Container(
                    height: h * 0.1,
                    width: w * 0.21,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade300),
                      image: DecorationImage(
                          image: NetworkImage(image), fit: BoxFit.fill),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  10.width,
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        constraints: BoxConstraints(maxWidth: w * 0.47),
                        child: Text(
                          exerciseTitle,
                          style: boldTextStyle(
                              size: 16, color: const Color(0xFF8D8D8D)),
                        ),
                      ),
                      type == "duration"
                          ? Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children:
                                  List.generate(duration!.length, (index) {
                                WorkoutDayDuration data = duration![index];
                                return Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(data.duration.validate(),
                                        style: boldTextStyle(
                                          size: 12,
                                          color: const Color(0xFF8D8D8D),
                                        )),
                                    4.width,
                                    Text(languages.lblMinutes,
                                        style: primaryTextStyle(
                                          size: 12,
                                          color: const Color(0xFF8D8D8D),
                                        )),
                                  ],
                                );
                              }),
                            )
                          : Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: List.generate(sets.length, (index) {
                                return Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      "${sets[index].reps} set",
                                      style: boldTextStyle(
                                        size: 12,
                                        color: const Color(0xFF8D8D8D),
                                      ),
                                    ),
                                    5.width,
                                    Text(
                                      "${sets[index].weight} Kg",
                                      style: boldTextStyle(
                                        size: 12,
                                        color: const Color(0xFF8D8D8D),
                                      ),
                                    ),
                                  ],
                                );
                              }),
                            ),
                    ],
                  ),
                ],
              ),
            ),
            Align(
              alignment: Alignment.bottomRight,
              child: Container(
                decoration: BoxDecoration(
                    color: workoutStatus.isComplete
                        ? greenColor
                        : isTodayExercises
                            ? Colors.blue
                            : appRedColor,
                    borderRadius: BorderRadius.circular(5)),
                child: Text(
                  workoutStatus.isComplete
                      ? "Completed"
                      : isTodayExercises
                          ? "Start Now"
                          : "Not Done",
                  style: const TextStyle(color: Colors.white, fontSize: 13),
                ).paddingSymmetric(horizontal: 8, vertical: 3),
              ).paddingSymmetric(horizontal: 10, vertical: 10),
            )
          ],
        ),
      ).paddingOnly(left: 10, bottom: 10),
    );
  }
}

class RestScreen extends StatelessWidget {
  const RestScreen({
    super.key,
    required this.workoutDaysHistory,
  });
  final WorkoutDaysHistory workoutDaysHistory;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          "Today Is Rest Day",
          style: boldTextStyle(),
        ),
        30.height,
        cachedImage(workoutDaysHistory.data!.first.exerciseImage)
      ],
    );
  }
}

class ShimmerEffectScreen extends StatelessWidget {
  const ShimmerEffectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Column(
      children: [
        10.height,
        ListView.builder(
          itemCount: 10,
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemBuilder: (context, index) {
            return Shimmer.fromColors(
              baseColor: Colors.grey.shade300,
              highlightColor: Colors.white54,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: TimelineTile(
                  isFirst: true,
                  isLast: true,
                  indicatorStyle: IndicatorStyle(
                    width: 25,
                    height: 25,
                    color: Colors.grey.shade300,
                    indicator: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.grey.shade300,
                      ),
                    ),
                  ),
                  beforeLineStyle: const LineStyle(
                    thickness: 1.5,
                    color: Colors.grey,
                  ),
                  afterLineStyle: const LineStyle(
                    thickness: 1.5,
                    color: Colors.grey,
                  ),
                  endChild: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Container(
                      height: h * 0.14,
                      width: w,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ).paddingOnly(left: 10, bottom: 10),
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

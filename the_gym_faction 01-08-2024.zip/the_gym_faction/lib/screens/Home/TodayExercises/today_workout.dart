import 'package:TheGymFaction/extensions/colors.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/string_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:TheGymFaction/main.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:TheGymFaction/utils/app_common.dart';
import 'package:animation_list/animation_list.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shimmer/shimmer.dart';
import 'package:timeline_tile/timeline_tile.dart';

import '../../../models/today_exercises_model.dart';
import '../../no_data_screen.dart';
import '../Exercise/exercise_detail_screen.dart';

class TodayWorkout extends StatefulWidget {
  const TodayWorkout({super.key, this.bodyPartName});
  final String? bodyPartName;

  @override
  State<TodayWorkout> createState() => _TodayWorkoutState();
}

class _TodayWorkoutState extends State<TodayWorkout> {
  int activeStep = 0;
  int total = 0;
  double pr = 0.00;
  String states = "1";
  String workoutStatus = "workout";
  DateFormat today = DateFormat("EEEE");
  List<TodayExercisesDatum> todayExercises = [];

  @override
  void initState() {
    super.initState();
    getTodayData();
  }

  void getTodayData() {
    total = 0;
    activeStep = 0;
    appStore.setLoading(true);
    Map<String, dynamic> req = {
      "day": today.format(DateTime.now()).todayNumber()
    };
    getTodayExercisesApi(req).then((value) {
      workoutStatus = value.status!;
      todayExercises = value.data!;
      List states = [];
      for (var element in value.data!) {
        total++;
        if (element.workoutStatus == "complete") {
          states.add(element.workoutStatus);
        }
      }
      activeStep = states.length;
      setState(() {
        pr = (activeStep / total) * 100;
        appStore.setLoading(false);
      });
      return;
    });
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(68),
        child: Column(
          children: [
            20.height,
            ListTile(
              leading: IconButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: const Icon(
                  Icons.arrow_back_ios_new_outlined,
                  color: black,
                ),
              ),
              title: Text(
                "Today ${widget.bodyPartName.capitalizeFirstLetter()} Workout",
                style: boldTextStyle(color: black),
              ),
              subtitle: Text(
                "${DateTime.now().day} / ${DateTime.now().month} / ${DateTime.now().year}",
                style: const TextStyle(color: black),
              ),
            ),
          ],
        ),
      ),
      body: appStore.isLoading
          ? const SingleChildScrollView(child: ShimmerEffectScreen())
          : todayExercises.isNotEmpty
              ? workoutStatus == "rest"
                  ? RestScreen(todayExercises: todayExercises)
                  : Stack(
                      children: [
                        SingleChildScrollView(
                          child: Column(
                            children: [
                              AnimationList(
                                physics: const NeverScrollableScrollPhysics(),
                                shrinkWrap: true,
                                duration: 4000,
                                children: List.generate(todayExercises.length,
                                    (index) {
                                  return CustomTimelineTile(
                                    type: todayExercises[index].type ?? "",
                                    duration: todayExercises[index].duration,
                                    onTap: () {
                                      ExerciseDetailScreen(
                                              check: todayExercises[index]
                                                  .workoutStatus
                                                  .isComplete,
                                              mExerciseName:
                                                  todayExercises[index]
                                                      .title!
                                                      .validate(),
                                              mExerciseId: todayExercises[index]
                                                  .id!
                                                  .validate())
                                          .launch(context)
                                          .then((value) {
                                        getTodayData();
                                        return null;
                                      });
                                    },
                                    exerciseTitle: todayExercises[index].title!,
                                    image: todayExercises[index].exerciseImage!,
                                    isFirst: index == 0,
                                    isLast: index == todayExercises.length - 1,
                                    workoutStatus:
                                        todayExercises[index].workoutStatus!,
                                    sets: todayExercises[index].sets!,
                                  );
                                }),
                              )
                            ],
                          ).paddingOnly(left: 6, right: 6, bottom: 80),
                        ),
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Container(
                            alignment: Alignment.center,
                            height: 80,
                            width: w,
                            decoration: BoxDecoration(
                              color: Colors.blue,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "You Have Completed Exercise $activeStep/$total",
                                  style: boldTextStyle(
                                      color: whiteColor, size: 14),
                                ),
                                10.height,
                                pr.isNaN
                                    ? Text(
                                        "You Have Completed 0.00% of The Exercise",
                                        style: boldTextStyle(
                                            color: whiteColor, size: 14),
                                      )
                                    : Text(
                                        "You Have Completed ${pr.toStringAsFixed(2)}% of The Exercise",
                                        style: boldTextStyle(
                                            color: whiteColor, size: 14),
                                      ),
                              ],
                            ),
                          ).paddingSymmetric(horizontal: 20, vertical: 10),
                        )
                      ],
                    )
              : NoDataScreen(mTitle: languages.lblExerciseNoFound)
                  .visible(!appStore.isLoading),
    );
  }
}

class CustomTimelineTile extends StatelessWidget {
  final bool isFirst;
  final bool isLast;
  final String workoutStatus;
  final String image;
  final String exerciseTitle;
  final List<TodayExercisesSet> sets;
  final void Function() onTap;
  final String? type;
  final List<TodayExercisesDuration>? duration;
  const CustomTimelineTile({
    super.key,
    required this.isFirst,
    required this.isLast,
    required this.workoutStatus,
    required this.image,
    required this.exerciseTitle,
    required this.sets,
    required this.onTap,
    this.type,
    this.duration,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0),
      child: TimelineTile(
        isFirst: isFirst,
        isLast: isLast,
        indicatorStyle: IndicatorStyle(
            width: 25,
            height: 25,
            color: workoutStatus.isComplete ? greenColor : Colors.grey,
            indicator: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: workoutStatus.isComplete ? greenColor : Colors.grey,
                ),
                child: workoutStatus.isComplete
                    ? const Center(
                        child: Icon(
                          Icons.check,
                          color: Colors.white,
                        ),
                      )
                    : const SizedBox())),
        afterLineStyle: LineStyle(
          thickness: 1.5,
          color: workoutStatus.isComplete ? greenColor : Colors.grey,
        ),
        beforeLineStyle: LineStyle(
          thickness: 1.5,
          color: workoutStatus.isComplete ? greenColor : Colors.grey,
        ),
        endChild: ExerciseCard(
          duration: duration,
          type: type,
          workoutStatus: workoutStatus,
          onTap: onTap,
          exerciseTitle: exerciseTitle,
          exercise: workoutStatus,
          image: image,
          sets: sets,
        ),
      ),
    );
  }
}

class ExerciseCard extends StatelessWidget {
  final String exercise;
  final String image;
  final String exerciseTitle;
  final String workoutStatus;
  final List<TodayExercisesSet> sets;
  final void Function() onTap;
  final String? type;
  final List<TodayExercisesDuration>? duration;
  const ExerciseCard({
    super.key,
    required this.exercise,
    required this.image,
    required this.exerciseTitle,
    required this.sets,
    required this.onTap,
    required this.workoutStatus,
    this.type,
    this.duration,
  });

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return GestureDetector(
      onTap: onTap,
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        child: Stack(
          children: [
            Container(
              height: h * 0.14,
              width: w,
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(
                  color: workoutStatus.isComplete
                      ? Colors.green.shade200
                      : Colors.blue.shade200,
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  15.width,
                  Container(
                    height: h * 0.1,
                    width: w * 0.21,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade300),
                      image: DecorationImage(
                          image: NetworkImage(image), fit: BoxFit.fill),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  10.width,
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        constraints: BoxConstraints(maxWidth: w * 0.47),
                        child: Text(
                          exerciseTitle,
                          style: boldTextStyle(
                              size: 16, color: const Color(0xFF8D8D8D)),
                        ),
                      ),
                      type == "duration"
                          ? Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children:
                                  List.generate(duration!.length, (index) {
                                TodayExercisesDuration data = duration![index];
                                return Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(data.duration.validate(),
                                        style: boldTextStyle(
                                          size: 12,
                                          color: const Color(0xFF8D8D8D),
                                        )),
                                    4.width,
                                    Text(languages.lblMinutes,
                                        style: primaryTextStyle(
                                          size: 12,
                                          color: const Color(0xFF8D8D8D),
                                        )),
                                  ],
                                );
                              }),
                            )
                          : Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: List.generate(sets.length, (index) {
                                return Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      "${sets[index].reps} set",
                                      style: boldTextStyle(
                                          size: 12,
                                          color: const Color(0xFF8D8D8D)),
                                    ),
                                    5.width,
                                    Text(
                                      "${sets[index].weight} Kg",
                                      style: boldTextStyle(
                                          size: 12,
                                          color: const Color(0xFF8D8D8D)),
                                    ),
                                  ],
                                );
                              }),
                            ),
                    ],
                  ),
                ],
              ),
            ),
            Align(
              alignment: Alignment.bottomRight,
              child: Container(
                decoration: BoxDecoration(
                    color: workoutStatus.isComplete ? greenColor : Colors.blue,
                    borderRadius: BorderRadius.circular(5)),
                child: Text(
                  workoutStatus.isComplete ? "Completed" : "Start Now",
                  style: const TextStyle(color: Colors.white, fontSize: 13),
                ).paddingSymmetric(horizontal: 8, vertical: 3),
              ).paddingSymmetric(horizontal: 10, vertical: 10),
            )
          ],
        ),
      ).paddingOnly(left: 10, bottom: 10),
    );
  }
}

class RestScreen extends StatelessWidget {
  const RestScreen({super.key, required this.todayExercises});
  final List<TodayExercisesDatum> todayExercises;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          "Today Is Rest Day",
          style: boldTextStyle(),
        ),
        30.height,
        cachedImage(todayExercises.first.exerciseImage)
      ],
    );
  }
}

class ShimmerEffectScreen extends StatelessWidget {
  const ShimmerEffectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Column(
      children: [
        10.height,
        ListView.builder(
          itemCount: 10,
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemBuilder: (context, index) {
            return Shimmer.fromColors(
              baseColor: Colors.grey.shade300,
              highlightColor: Colors.white54,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: TimelineTile(
                  isFirst: true,
                  isLast: true,
                  indicatorStyle: IndicatorStyle(
                    width: 25,
                    height: 25,
                    color: Colors.grey.shade300,
                    indicator: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.grey.shade300,
                      ),
                    ),
                  ),
                  beforeLineStyle: const LineStyle(
                    thickness: 1.5,
                    color: Colors.grey,
                  ),
                  afterLineStyle: const LineStyle(
                    thickness: 1.5,
                    color: Colors.grey,
                  ),
                  endChild: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Container(
                      height: h * 0.14,
                      width: w,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ).paddingOnly(left: 10, bottom: 10),
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}

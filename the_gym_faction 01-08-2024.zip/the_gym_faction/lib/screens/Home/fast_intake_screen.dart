import 'package:TheGymFaction/extensions/extension_util/context_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:TheGymFaction/screens/no_data_screen.dart';
import 'package:circular_countdown_timer/circular_countdown_timer.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../components/fast_and_meditation_shimmer_effect.dart';
import '../../extensions/app_button.dart';
import '../../extensions/colors.dart';
import '../../extensions/constants.dart';
import '../../extensions/text_styles.dart';
import '../../main.dart';
import '../../models/diet_list_model.dart';
import '../../models/fast_intake_response.dart';
import '../../utils/app_colors.dart';
import '../../utils/app_common.dart';

class FastIntakeScreen extends StatefulWidget {
  const FastIntakeScreen({super.key});

  @override
  State<FastIntakeScreen> createState() => _FastIntakeScreenState();
}

class _FastIntakeScreenState extends State<FastIntakeScreen> {
  bool select = true;
  FlutterTts flutterTts = FlutterTts();
  CountDownController countDownController = CountDownController();
  FastIntakeResponse fastIntakeResponse = FastIntakeResponse();
  FastIntakeHistory fastIntakeHistory = FastIntakeHistory(
    data: [],
    completeCount: 0,
    inProgressCount: 0,
    pendingCount: 0,
    totalFastIntakes: 0,
  );
  FastIntakeDatum fastIntakeDatum = FastIntakeDatum();
  List<DoughnutChart> chartData = [];
  bool getData = false;
  bool getHistoryData = false;
  bool currentFast = false;
  int totalTime = 0;
  int startTime = 0;
  bool second1 = true;
  bool second2 = true;
  bool second3 = true;

  void fetchFastIntakeData({bool speak = false}) {
    int index = 0;
    setState(() => getData = true);
    getFastIntakeApi().then((value) {
      fastIntakeResponse = value;
      for (var element in value.data!) {
        if (element.status == "in_progress") {
          fastIntakeDatum = value.data![index];
          currentFast = true;
          totalTime = int.parse("${element.totalTime! * 60}");
          // startTime =
          //     int.parse("${(element.totalTime! - element.pendingTime!) * 60}");
          startTime = totalTime - element.pendingTimeSeconds!;
          index++;
          setState(() {});
          if (totalTime == element.pendingTimeSeconds!) {
            startTime = 0;
          }
        } else {
          index++;
          setState(() {});
        }
      }
      setState(() => getData = false);
      if (speak == true) {
        flutterTts.speak("Your Fasting Start");
      }
    });
  }

  void addStartFastApi(int id) {
    Map<String, dynamic> req = {"fast_id": id};
    setStartFastApi(req).then((value) {
      if (value["success"] == true) {
        fetchFastIntakeData(speak: true);
      }
      toast(value["message"]);
      return;
    });
  }

  void addFastHistoryData() {
    setState(() => getHistoryData = true);
    getFastHistoryApi().then((value) {
      fastIntakeHistory = value;
      // if (value.totalFastIntakes == value.completeCount) {
      //   chartData.add(DoughnutChart(
      //     "Completed Fasting",
      //     value.completeCount!.toDouble(),
      //     "${value.completeCount!}",
      //     Colors.green,
      //   ));
      // } else if (value.inProgressCount == 0) {
      //   chartData.add(DoughnutChart(
      //     "Not Completed",
      //     value.pendingCount!.toDouble(),
      //     "${value.pendingCount!}",
      //     black,
      //   ));
      //   chartData.add(DoughnutChart(
      //     "Completed Fasting",
      //     value.completeCount!.toDouble(),
      //     "${value.completeCount!}",
      //     Colors.green,
      //   ));
      // } else if (value.completeCount == 0) {
      //   chartData.add(DoughnutChart(
      //     "Not Completed",
      //     value.pendingCount!.toDouble(),
      //     "${value.pendingCount!}",
      //     black,
      //   ));
      //   chartData.add(DoughnutChart(
      //     "In Progress",
      //     value.inProgressCount!.toDouble(),
      //     "${value.inProgressCount!}",
      //     Colors.yellow,
      //   ));
      // } else {
      //   chartData.add(DoughnutChart(
      //     "Not Completed",
      //     value.pendingCount!.toDouble(),
      //     "${value.pendingCount!}",
      //     black,
      //   ));
      //   chartData.add(DoughnutChart(
      //     "Completed Fasting",
      //     value.completeCount!.toDouble(),
      //     "${value.completeCount!}",
      //     Colors.green,
      //   ));
      //   chartData.add(DoughnutChart(
      //     "In Progress",
      //     value.inProgressCount!.toDouble(),
      //     "${value.inProgressCount!}",
      //     Colors.yellow,
      //   ));
      // }
      setState(() => getHistoryData = false);
      return null;
    });
  }

  @override
  void initState() {
    fetchFastIntakeData();
    addFastHistoryData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(h * 0.14),
        child: Column(
          children: [
            (h * 0.03).toInt().height,
            ListTile(
              leading: IconButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: const Icon(
                  Icons.arrow_back_ios_new_outlined,
                  color: black,
                ),
              ),
              titleAlignment: ListTileTitleAlignment.center,
              title: Text(
                "Fasting",
                style: boldTextStyle(),
              ),
            ),
            CustomTabBar(
              select: select,
              fistOnTap: () {
                setState(() {
                  select = !select;
                });
              },
              secondOnTap: () {
                setState(() {
                  select = !select;
                });
              },
            ),
          ],
        ),
      ),
      body: select
          ? getData
              ? const FastAndMeditationShimmerEffect()
              : FastingData(
                  flutterTts: flutterTts,
                  call: (duration) {
                    if (duration.inSeconds == 3) {
                      if (second3) {
                        flutterTts.speak(languages.lblThree.toString());
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          setState(() => second3 = false);
                        });
                      }
                    }
                    if (duration.inSeconds == 2) {
                      if (second2) {
                        flutterTts.speak(languages.lblTwo.toString());
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          setState(() => second2 = false);
                        });
                      }
                    }
                    if (duration.inSeconds == 1) {
                      if (second1) {
                        flutterTts.speak(languages.lblOne.toString());
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          setState(() => second1 = false);
                        });
                      }
                    }
                  },
                  onTab: (index) {
                    addStartFastApi(fastIntakeResponse.data![index].id!);
                    Navigator.pop(context);
                  },
                  countDownController: countDownController,
                  currentFast: currentFast,
                  fastIntakeDatum: fastIntakeDatum,
                  fastIntakeResponse: fastIntakeResponse,
                  getData: getData,
                  startTime: startTime,
                  totalTime: totalTime,
                )
          : getHistoryData
              ? const FastAndMeditationHistoryShimmer()
              : fastIntakeHistory.data!.isNotEmpty
                  ? FastingHistory(
                      completedData: fastIntakeHistory.completeCount!,
                      getHistoryData: getHistoryData,
                      chartData: chartData,
                      fastIntakeHistory: fastIntakeHistory,
                    )
                  : const NoDataScreen(mTitle: "No Fasting History"),
    );
  }
}

class FastingData extends StatelessWidget {
  const FastingData(
      {super.key,
      required this.getData,
      required this.currentFast,
      required this.totalTime,
      required this.startTime,
      required this.countDownController,
      required this.fastIntakeDatum,
      required this.fastIntakeResponse,
      required this.onTab,
      required this.call,
      required this.flutterTts});
  final bool getData;
  final bool currentFast;
  final int totalTime;
  final int startTime;
  final FlutterTts flutterTts;
  final CountDownController countDownController;
  final FastIntakeDatum fastIntakeDatum;
  final FastIntakeResponse fastIntakeResponse;
  final void Function(dynamic) onTab;
  final void Function(Duration) call;

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SingleChildScrollView(
      child: Column(children: [
        currentFast
            ? Container(
                width: w,
                // height: h * 0.4,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade200,
                      spreadRadius: 3,
                      blurRadius: 10,
                    )
                  ],
                  color: whiteColor,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    10.height,
                    Text(
                      "Current Fast Intake",
                      style: boldTextStyle(),
                    ),
                    20.height,
                    CircularCountDownTimer(
                      duration: totalTime,
                      initialDuration: startTime,
                      controller: countDownController,
                      width: w * 0.4,
                      height: h * 0.2,
                      ringColor: Colors.grey[300]!,
                      fillColor: appRedColor,
                      backgroundColor: black,
                      strokeWidth: 20.0,
                      strokeCap: StrokeCap.round,
                      textStyle: boldTextStyle(color: Colors.white, size: 25),
                      textFormat: CountdownTextFormat.HH_MM_SS,
                      isReverse: true,
                      isReverseAnimation: true,
                      timeFormatterFunction:
                          (defaultFormatterFunction, duration) {
                        // return Function.apply(defaultFormatterFunction, [duration]);
                        if (duration.inSeconds == 0) {
                          flutterTts.speak("Fasting Complete");
                          return "Complete";
                        } else {
                          call(duration);
                          return Function.apply(
                              defaultFormatterFunction, [duration]);
                        }
                      },
                    ).center(),
                    20.height,
                    Row(
                      children: [
                        Container(
                          width: 60,
                          decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.shade200,
                                spreadRadius: 3,
                                blurRadius: 10,
                              )
                            ],
                            borderRadius: BorderRadius.circular(80),
                          ),
                          child: cachedImage(
                            fastIntakeDatum.image.toString(),
                            fit: BoxFit.fill,
                          ).cornerRadiusWithClipRRect(80),
                        ),
                        10.width,
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                                constraints: BoxConstraints(maxWidth: w * 0.6),
                                child: Text(
                                    fastIntakeDatum.description.toString())),
                            1.height,
                            Text.rich(
                                TextSpan(text: "Start Time :- ", children: [
                              TextSpan(
                                  text: fastIntakeDatum.startTime.toString())
                            ])),
                            1.height,
                            Text.rich(TextSpan(text: "End Time :- ", children: [
                              TextSpan(text: fastIntakeDatum.endTime.toString())
                            ])),
                          ],
                        ),
                      ],
                    ),
                    20.height,
                  ],
                ).paddingSymmetric(horizontal: 20),
              ).paddingSymmetric(vertical: 20, horizontal: 20)
            : Container(
                width: w,
                // height: h * 0.4,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade200,
                      spreadRadius: 3,
                      blurRadius: 10,
                    )
                  ],
                  color: whiteColor,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    10.height,
                    Text(
                      "Current Fast Intake",
                      style: boldTextStyle(),
                    ),
                    20.height,
                    Text(
                      "Current Fast Intake Is Not Found",
                      style: boldTextStyle(),
                    ).paddingSymmetric(vertical: 10, horizontal: 20),
                    20.height,
                  ],
                ).paddingSymmetric(horizontal: 20),
              ).paddingSymmetric(vertical: 20, horizontal: 20),
        fastIntakeResponse.data!.isNotEmpty
            ? ListView.builder(
                itemCount: fastIntakeResponse.data!.length,
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  FastIntakeDatum fastingData = fastIntakeResponse.data![index];
                  return Container(
                    width: w,
                    padding: const EdgeInsets.all(10),
                    // height: h * 0.2,
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.shade200,
                          spreadRadius: 3,
                          blurRadius: 10,
                        )
                      ],
                      color: whiteColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            10.width,
                            Container(
                              width: 60,
                              decoration: BoxDecoration(
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.shade200,
                                    spreadRadius: 3,
                                    blurRadius: 10,
                                  )
                                ],
                                borderRadius: BorderRadius.circular(80),
                              ),
                              child: cachedImage(
                                fastingData.image.toString(),
                                fit: BoxFit.fill,
                              ).cornerRadiusWithClipRRect(80),
                            ),
                            10.width,
                            Expanded(
                              child: Text(fastingData.description.toString()),
                            ),
                            10.width,
                          ],
                        ),
                        Align(
                          alignment: Alignment.bottomRight,
                          child: IntrinsicWidth(
                              child: Container(
                                  decoration: BoxDecoration(
                                    color: Colors.green,
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                  child: Row(
                                    children: [
                                      Text(
                                        "Start Fasting",
                                        style: boldTextStyle(
                                            color: whiteColor, size: 12),
                                      ).paddingSymmetric(
                                          horizontal: 8, vertical: 4),
                                      const Icon(Icons.chevron_right,
                                          color: Colors.white)
                                    ],
                                  ))),
                        )
                      ],
                    ),
                  ).onTap(() {
                    showDialog(
                      context: context,
                      builder: (context) {
                        return FastingStartDialog(
                          onTab: () {
                            onTab(index);
                          },
                          startDate: fastingData.description,
                        );
                      },
                    );
                  }).paddingSymmetric(vertical: 5, horizontal: 20);
                },
              )
            : Container(
                width: w,
                // height: h * 0.2,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade200,
                      spreadRadius: 3,
                      blurRadius: 10,
                    )
                  ],
                  color: whiteColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Text("No Data")
                    .paddingSymmetric(horizontal: 10, vertical: 20),
              ).paddingSymmetric(horizontal: 20),
      ]),
    );
  }
}

class FastingHistory extends StatelessWidget {
  const FastingHistory(
      {super.key,
      required this.chartData,
      required this.fastIntakeHistory,
      required this.getHistoryData,
      required this.completedData});
  final List<DoughnutChart> chartData;
  final FastIntakeHistory fastIntakeHistory;
  final int completedData;
  final bool getHistoryData;

  @override
  Widget build(BuildContext context) {
    // final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    DateFormat dateFormat2 = DateFormat("dd-MM-yyyy HH:mm");
    return SingleChildScrollView(
      child: Column(
        children: [
          // ChartData(
          //   chartData: chartData,
          //   fasting: completedData,
          // ),
          ListView.builder(
            itemCount: fastIntakeHistory.data!.length,
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemBuilder: (context, index) {
              FastIntakeHistoryDataDatum fastingData =
                  fastIntakeHistory.data![index];
              return Container(
                width: w,
                // height: h * 0.2,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade200,
                      spreadRadius: 3,
                      blurRadius: 10,
                    )
                  ],
                  color: whiteColor,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Stack(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        20.width,
                        Container(
                          width: 60,
                          decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.shade200,
                                spreadRadius: 3,
                                blurRadius: 10,
                              )
                            ],
                            borderRadius: BorderRadius.circular(80),
                          ),
                          child: cachedImage(
                            fastingData.image.toString(),
                            fit: BoxFit.fill,
                          ).cornerRadiusWithClipRRect(80),
                        ),
                        10.width,
                        Expanded(
                            child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            30.height,
                            Text(fastingData.description.toString()),
                            Text.rich(
                              TextSpan(text: "Start Time :- ", children: [
                                TextSpan(
                                  text: dateFormat2
                                      .format(fastingData.startTime!),
                                )
                              ]),
                            ),
                            1.height,
                            Text.rich(
                              TextSpan(text: "End Time :- ", children: [
                                TextSpan(
                                  text:
                                      dateFormat2.format(fastingData.endTime!),
                                )
                              ]),
                            ),
                            20.height,
                          ],
                        )),
                        20.width,
                      ],
                    ),
                    Positioned(
                      top: 0,
                      right: 10,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.green,
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Text(
                          "Completed",
                          style: boldTextStyle(color: whiteColor, size: 12),
                        ).paddingSymmetric(horizontal: 8, vertical: 4),
                      ).paddingSymmetric(vertical: 8, horizontal: 10),
                    ),
                  ],
                ),
              ).paddingSymmetric(vertical: 5, horizontal: 20);
            },
          ),
        ],
      ),
    );
  }
}

class CustomTabBar extends StatelessWidget {
  const CustomTabBar(
      {super.key, required this.select, this.fistOnTap, this.secondOnTap});
  final bool select;
  final void Function()? fistOnTap;
  final void Function()? secondOnTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(top: 22),
      decoration: BoxDecoration(
          border: Border(
              bottom: BorderSide(
                  color:
                      appStore.isDarkMode ? whiteColor : context.dividerColor,
                  width: 0.5))),
      child: Row(children: [
        GestureDetector(
          onTap: fistOnTap,
          child: Container(
              padding: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          width: 1.5,
                          color: select ? primaryColor : Colors.transparent))),
              child: Text("Add Fast",
                      style: boldTextStyle(
                          color:
                              select ? primaryColor : textSecondaryColorGlobal))
                  .center()),
        ).expand(),
        GestureDetector(
          onTap: secondOnTap,
          child: Container(
            padding: const EdgeInsets.only(bottom: 8),
            decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(
                        width: 1.5,
                        color: select ? Colors.transparent : primaryColor))),
            child: Text("Fasting History",
                    style: boldTextStyle(
                        color:
                            select ? textSecondaryColorGlobal : primaryColor))
                .center(),
          ),
        ).expand(),
      ]).paddingSymmetric(horizontal: 16),
    );
  }
}

class FastingStartDialog extends StatelessWidget {
  const FastingStartDialog({super.key, this.startDate, required this.onTab});
  final String? startDate;
  final void Function() onTab;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        width: w,
        height: h * 0.3,
        decoration: BoxDecoration(
          color: whiteColor,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            10.height,
            Text(
              "Start Fasting For $startDate",
              style: boldTextStyle(),
            ),
            10.height,
            Text(
              "Are You Sure Start Fasting",
              style: boldTextStyle(),
            ),
            50.height,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                AppButton(
                  color: appRedColor,
                  onTap: () {
                    Navigator.pop(context);
                  },
                  text: "No",
                ),
                AppButton(
                  color: Colors.green,
                  onTap: onTab,
                  text: "Yes",
                ),
              ],
            ),
          ],
        ).paddingSymmetric(horizontal: 20),
      ),
    );
  }
}

class ChartData extends StatelessWidget {
  const ChartData({
    super.key,
    required this.chartData,
    required this.fasting,
  });
  final List<DoughnutChart> chartData;
  final int fasting;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return SizedBox(
      width: w * 0.6,
      height: h * 0.3,
      child: Stack(
        children: [
          SfCircularChart(
            tooltipBehavior: TooltipBehavior(enable: true),
            series: <CircularSeries<DoughnutChart, String>>[
              DoughnutSeries<DoughnutChart, String>(
                dataSource: chartData,
                xValueMapper: (DoughnutChart data, _) => data.x,
                yValueMapper: (DoughnutChart data, _) => data.y,
                pointColorMapper: (DoughnutChart data, _) => data.color,
                dataLabelMapper: (DoughnutChart data, _) => data.text,
                radius: '100%',
                innerRadius: '60%',
                dataLabelSettings: const DataLabelSettings(
                    isVisible: true, textStyle: TextStyle(color: whiteColor)
                    // labelPosition: ChartDataLabelPosition.inside,
                    ),
              ),
            ],
          ),
          Align(
            alignment: Alignment.center,
            child: Text(
              "$fasting Fasting\nCompleted",
              style: boldTextStyle(),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}

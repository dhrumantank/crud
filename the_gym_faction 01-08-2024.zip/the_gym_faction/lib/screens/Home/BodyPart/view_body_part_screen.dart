import 'dart:developer';

import 'package:flutter/material.dart';

import '../../../../extensions/extension_util/widget_extensions.dart';
import '../../../../extensions/loader_widget.dart';
import '../../../../extensions/widgets.dart';
import '../../../components/HomeComponent/body_part_component.dart';
import '../../../extensions/animatedList/animated_wrap.dart';
import '../../../main.dart';
import '../../../models/body_part_response.dart';
import '../../../network/rest_api.dart';

class ViewBodyPartScreen extends StatefulWidget {
  const ViewBodyPartScreen({super.key});

  @override
  State<ViewBodyPartScreen> createState() => _ViewBodyPartScreenState();
}

class _ViewBodyPartScreenState extends State<ViewBodyPartScreen> {
  ScrollController scrollController = ScrollController();

  List<BodyPartModel> bodyPartList = [];

  int page = 1;
  int? numPage;

  bool isLastPage = false;

  @override
  void initState() {
    super.initState();
    init();
    scrollController.addListener(() {
      if (scrollController.position.pixels ==
              scrollController.position.maxScrollExtent &&
          !appStore.isLoading) {
        if (page < numPage!) {
          page++;
          init();
        }
      }
    });
  }

  void init() async {
    getBodyPartData();
  }

  Future<void> getBodyPartData() async {
    appStore.setLoading(true);
    await getBodyPartApi(page).then((value) {
      appStore.setLoading(false);
      numPage = value.data!.total;
      isLastPage = false;
      if (page == 1) {
        bodyPartList.clear();
      }
      for (var element in value.data!.data!) {
        if (element.id == 21) {
          continue;
        } else {
          bodyPartList.add(element);
        }
      }
      // Iterable it = value.data!.data!;
      // it.map((e) => bodyPartList.add(e)).toList();
      setState(() {});
    }).catchError((e) {
      isLastPage = true;
      appStore.setLoading(false);
      setState(() {
        log(e);
      });
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBarWidget(languages.lblBodyPartExercise,
          elevation: 0, context: context),
      body: Stack(
        children: [
          SingleChildScrollView(
            controller: scrollController,
            child: AnimatedWrap(
              itemCount: bodyPartList.length,
              runSpacing: 18,
              spacing: 16,
              itemBuilder: (context, index) {
                return BodyPartComponent(
                  bodyPartModel: bodyPartList[index],
                  isGrid: true,
                );
              },
              // children: List.generate(bodyPartList.length, (index) {
              //   return ;
              // }),
            ).center(),
          ),
          const Loader().center().visible(appStore.isLoading)
        ],
      ),
    );
  }
}

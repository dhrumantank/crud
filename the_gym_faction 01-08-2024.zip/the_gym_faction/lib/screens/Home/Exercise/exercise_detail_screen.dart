import 'package:TheGymFaction/components/HomeComponent/complete_exercise_dialog.dart';
import 'package:flutter/material.dart';

import '../../../../extensions/extension_util/context_extensions.dart';
import '../../../../extensions/extension_util/int_extensions.dart';
import '../../../../extensions/extension_util/string_extensions.dart';
import '../../../../extensions/extension_util/widget_extensions.dart';
import '../../../components/HomeComponent/edit_exercises_duration_component.dart';
import '../../../components/HomeComponent/view_sets_exercise_componet.dart';
import '../../../components/HtmlWidget.dart';
import '../../../extensions/app_button.dart';
import '../../../extensions/colors.dart';
import '../../../extensions/decorations.dart';
import '../../../extensions/horizontal_list.dart';
import '../../../extensions/text_styles.dart';
import '../../../extensions/widgets.dart';
import '../../../main.dart';
import '../../../models/exercise_detail_response.dart';
import '../../../network/rest_api.dart';
import '../../../utils/app_colors.dart';
import '../../../utils/app_common.dart';
import 'exercise_duration_screen.dart';
import 'exercise_duration_screen1.dart';

class ExerciseDetailScreen extends StatefulWidget {
  const ExerciseDetailScreen(
      {super.key, this.mExerciseId, this.mExerciseName, this.check = false});
  final int? mExerciseId;
  final String? mExerciseName;
  final bool check;

  @override
  State<ExerciseDetailScreen> createState() => _ExerciseDetailScreenState();
}

class _ExerciseDetailScreenState extends State<ExerciseDetailScreen> {
  ScrollController mScrollController = ScrollController();
  ExerciseDetailResponse? mExerciseModel;
  bool select = false;
  bool showButton = true;

  void setEditExercisesDurationData(
      List<ExerciseDuration> durationList, int index) {
    List addData = [];
    durationList.removeAt(index);
    setState(() {});
    for (var element in durationList) {
      addData.add(element.toJson());
    }
    Map<String, dynamic> req = {
      "exercise_id": widget.mExerciseId,
      "duration": addData,
    };
    try {
      setEditExercisesDurationResponse(req).then((value) {
        toast(value["message"]);
      });
    } catch (e) {
      toast("Try Again");
    }
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: appBarWidget(
        widget.mExerciseName.validate(),
        context: context,
      ),
      bottomSheet:
          // appStore.isLoading == false ?
          widget.check
              ? const SizedBox()
              : Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    AppButton(
                      color: primaryColor,
                      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                      width: w * 0.4,
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (context) {
                            return CompleteExerciseDialog(
                              id: mExerciseModel!.data!.id!,
                            );
                          },
                        ).then((value) {
                          if (value == true) {
                            Navigator.pop(context);
                          }
                          return;
                        });
                      },
                      text: "Complete",
                    ),
                    AppButton(
                      color: primaryColor,
                      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                      width: w * 0.4,
                      onTap: () {
                        if (mExerciseModel!.data!.type == "duration") {
                          ExerciseDurationScreen(mExerciseModel)
                              .launch(context);
                        } else {
                          ExerciseDurationScreen1(mExerciseModel)
                              .launch(context)
                              .then((value) {
                            if (value == true) {
                              Navigator.pop(context, true);
                            }
                            return;
                          });
                        }
                      },
                      text: languages.lblStartExercise,
                    ),
                  ],
                ),
      // : const SizedBox(),
      body: FutureBuilder(
        future: geExerciseDetailApi(widget.mExerciseId),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            mExerciseModel = snapshot.data;
            return SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: h * 0.3,
                    child: cachedImage(
                      mExerciseModel!.data!.exerciseImage.validate(),
                      fit: BoxFit.contain,
                      height: context.height(),
                    ).center(),
                  ),
                  16.height,
                  mExerciseModel!.data!.type == "duration"
                      ? Column(
                          children: List.generate(
                              mExerciseModel!.data!.duration!.length, (index) {
                            ExerciseDuration data =
                                mExerciseModel!.data!.duration![index];
                            return Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Container(
                                  width: w * 0.6,
                                  decoration: boxDecorationWithRoundedCorners(
                                      borderRadius: radius(),
                                      backgroundColor: appStore.isDarkMode
                                          ? cardDarkColor
                                          : GreyLightColor.withOpacity(0.3)),
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 14),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(data.duration.validate(),
                                          style: boldTextStyle()),
                                      5.width,
                                      Text(languages.lblMinutes,
                                          style: primaryTextStyle()),
                                    ],
                                  ),
                                ),
                                if (index == 0)
                                  GestureDetector(
                                    onTap: () {
                                      showDialog(
                                        context: context,
                                        builder: (context) {
                                          return EditExercisesDuration(
                                              durationData: mExerciseModel!
                                                  .data!.duration!,
                                              exerciseId: widget.mExerciseId!);
                                        },
                                      ).then((value) {
                                        if (value == true) {
                                          setState(() {});
                                        }
                                      });
                                    },
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Colors.blue,
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Row(
                                        children: [
                                          const Icon(
                                            Icons.edit,
                                            size: 20,
                                            color: whiteColor,
                                          ),
                                          8.width,
                                          Text(
                                            languages.edit,
                                            style: boldTextStyle(
                                                color: whiteColor),
                                          ),
                                        ],
                                      ).paddingSymmetric(
                                          vertical: 10, horizontal: 10),
                                    ),
                                  )
                                else
                                  GestureDetector(
                                    onTap: () {
                                      setEditExercisesDurationData(
                                          mExerciseModel!.data!.duration!,
                                          index);
                                    },
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: appRedColor,
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: const Icon(
                                        Icons.delete,
                                        size: 20,
                                        color: whiteColor,
                                      ).paddingSymmetric(
                                          vertical: 10, horizontal: 10),
                                    ),
                                  )
                              ],
                            ).paddingSymmetric(vertical: 5);
                          }),
                        )
                      : ViewSetsExercise(
                          setsList: mExerciseModel!.data!.sets!,
                          exerciseId: mExerciseModel!.data!.id!,
                        ),
                  12.height,
                  16.height,
                  const Divider(endIndent: 16, indent: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      if (mExerciseModel!.data!.bodypartName != null)
                        Column(
                          children: [
                            8.height,
                            Text(languages.lblBodyParts,
                                    style: secondaryTextStyle())
                                .paddingSymmetric(horizontal: 16),
                            8.height,
                            HorizontalList(
                              physics: const BouncingScrollPhysics(),
                              controller: mScrollController,
                              itemCount:
                                  mExerciseModel!.data!.bodypartName!.length,
                              padding: EdgeInsets.zero,
                              spacing: 16,
                              itemBuilder: (context, index) {
                                return SizedBox(
                                  width: context.width() * 0.25,
                                  child: Column(
                                    children: [
                                      cachedImage(
                                        mExerciseModel!.data!
                                            .bodypartName![index].bodypartImage
                                            .validate(),
                                        fit: BoxFit.fill,
                                        height: 65,
                                        width: context.width() * 0.17,
                                      ).cornerRadiusWithClipRRect(150),
                                      6.height,
                                      Text(
                                          mExerciseModel!
                                              .data!.bodypartName![index].title
                                              .validate(),
                                          style: primaryTextStyle(size: 14),
                                          textAlign: TextAlign.center,
                                          maxLines: 3),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ],
                        ).visible(
                            mExerciseModel!.data!.bodypartName!.isNotEmpty),
                      Column(
                        children: [
                          8.height,
                          Text(languages.lblEquipments,
                                  style: secondaryTextStyle())
                              .paddingSymmetric(horizontal: 16),
                          8.height,
                          SizedBox(
                            width: context.width() * 0.25,
                            child: Column(
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    border:
                                        Border.all(color: Colors.grey.shade200),
                                    borderRadius: BorderRadius.circular(100),
                                  ),
                                  child: cachedImage(
                                    mExerciseModel!.data!.equipmentImg
                                        .validate(),
                                    fit: BoxFit.fill,
                                    height: 65,
                                    width: context.width() * 0.17,
                                  ).cornerRadiusWithClipRRect(150),
                                ),
                                6.height,
                                Text(
                                    mExerciseModel!.data!.equipmentTitle
                                        .validate(),
                                    style: primaryTextStyle(size: 14),
                                    textAlign: TextAlign.center,
                                    maxLines: 3),
                              ],
                            ),
                          ),
                        ],
                      ).visible(
                          !mExerciseModel!.data!.equipmentTitle.isEmptyOrNull),
                    ],
                  ),
                  const Divider(endIndent: 16, indent: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        // padding: EdgeInsets.all(16),
                        margin: const EdgeInsets.all(16),
                        decoration: boxDecorationWithRoundedCorners(
                          backgroundColor: appStore.isDarkMode
                              ? context.cardColor
                              : appRedColor.withOpacity(0.2),
                        ),
                        child: Column(
                          children: [
                            16.height,
                            Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  50.height.visible(select),
                                  const Icon(Icons.info_outline,
                                      color: primaryColor, size: 25),
                                  10.width,
                                  Text(
                                    languages.lblTips,
                                    style: primaryTextStyle(
                                        size: 18,
                                        color: appStore.isDarkMode
                                            ? white
                                            : textPrimaryColor),
                                  ).expand(),
                                  Icon(
                                      select
                                          ? Icons.keyboard_arrow_down_sharp
                                          : Icons.keyboard_arrow_up,
                                      color: primaryColor,
                                      size: 30),
                                ]).paddingSymmetric(horizontal: 16),
                            8.height.visible(!select),
                            HtmlWidget(
                                    postContent:
                                        mExerciseModel!.data!.tips.validate())
                                .visible(!select)
                                .paddingSymmetric(horizontal: 16),
                          ],
                        ),
                      ).onTap(() {
                        setState(() {
                          select = !select;
                        });
                      }),
                      HtmlWidget(
                              postContent:
                                  mExerciseModel!.data!.instruction.validate())
                          .paddingSymmetric(horizontal: 8),
                      5.height,
                      Text(languages.lblInstruction, style: boldTextStyle())
                          .paddingSymmetric(horizontal: 16)
                          .visible(
                              mExerciseModel!.data!.instruction.isEmptyOrNull),
                      80.height,
                      // 16.height,
                      // HtmlWidget(
                      //         postContent:
                      //             mExerciseModel!.data!.instruction.validate())
                      //     .paddingSymmetric(horizontal: 8),
                    ],
                  ),
                ],
              ),
            );
          } else {
            // return UpdateButton(snapshot: snapshot);
            return snapWidgetHelper(snapshot);
          }
        },
      ),
    );
  }
}

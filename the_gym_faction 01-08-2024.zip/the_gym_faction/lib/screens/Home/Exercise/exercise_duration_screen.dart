import 'package:circular_countdown_timer/circular_countdown_timer.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

import '../../../../extensions/extension_util/string_extensions.dart';
import '../../../../extensions/extension_util/widget_extensions.dart';
import '../../../../models/exercise_detail_response.dart';
import '../../../components/HomeComponent/congratulations_dialog.dart';
import '../../../extensions/app_button.dart';
import '../../../extensions/colors.dart';
import '../../../extensions/extension_util/context_extensions.dart';
import '../../../extensions/extension_util/int_extensions.dart';
import '../../../extensions/system_utils.dart';
import '../../../extensions/text_styles.dart';
import '../../../extensions/widgets.dart';
import '../../../main.dart';
import '../../../network/rest_api.dart';
import '../../../utils/app_colors.dart';
import '../../../utils/app_common.dart';

class ExerciseDurationScreen extends StatefulWidget {
  const ExerciseDurationScreen(this.mExerciseModel, {super.key});
  static String tag = '/ExerciseDurationScreen';
  final ExerciseDetailResponse? mExerciseModel;

  @override
  ExerciseDurationScreenState createState() => ExerciseDurationScreenState();
}

class ExerciseDurationScreenState extends State<ExerciseDurationScreen> {
  CountDownController countDownController = CountDownController();
  Duration? duration1;
  FlutterTts flutterTts = FlutterTts();
  bool visibleOption = true;
  List allTimer = [];
  int timer = 3;
  int nextIndex = 0;
  bool second1 = true;
  bool second2 = true;
  bool second3 = true;
  bool second10 = true;
  bool exerciseDone = true;

  @override
  void initState() {
    allTimer.add(3);
    for (var element in widget.mExerciseModel!.data!.duration!) {
      allTimer.add((int.parse(element.duration!) * 60));
      setState(() {});
    }
    // timer = int.parse(widget.mExerciseModel!.data!.duration!) * 60;
    super.initState();
  }

  void getCompleteWorkout() {
    Map<String, dynamic> req = {
      "exercise_id": widget.mExerciseModel!.data!.id!,
      "status": "complete",
    };
    getCompleteWorkoutApi(req).then((value) {
      showDialog(
        context: context,
        builder: (context) {
          return CongratulationsDialog(
            onTap: () {
              Navigator.pop(context, true);
            },
          );
        },
      ).then((value) {
        Navigator.pop(context, true);
        return;
      });
      return;
    });
  }

  bool finishExercise = false;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: appBarWidget(widget.mExerciseModel!.data!.title.validate(),
          context: context),
      bottomNavigationBar: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          !countDownController.isPaused
              ? AppButton(
                  color: primaryColor,
                  margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  width: w * 0.4,
                  onTap: () {
                    countDownController.pause();
                    setState(() {});
                  },
                  text: "Pause",
                )
              : AppButton(
                  color: primaryColor,
                  margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  width: w * 0.4,
                  onTap: () {
                    countDownController.resume();
                    setState(() {});
                  },
                  text: "Start",
                ),
          countDownController.isStarted
              ? AppButton(
                  color: primaryColor,
                  margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  width: w * 0.4,
                  onTap: () {
                    getCompleteWorkout();
                  },
                  text: "Complete",
                )
              : AppButton(
                  color: primaryColor,
                  margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  width: w * 0.4,
                  onTap: () {
                    finish(context);
                  },
                  text: "Stop",
                ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            AspectRatio(
              aspectRatio: 12 / 7,
              child: cachedImage(
                      widget.mExerciseModel!.data!.exerciseImage.validate(),
                      fit: BoxFit.fill,
                      height: context.height())
                  .cornerRadiusWithClipRRect(0),
            ).center(),
            34.height,
            Container(
              width: w * 0.8,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text(
                    languages.lblExercise,
                    style: boldTextStyle(),
                  ).paddingSymmetric(vertical: 15, horizontal: 10),
                  Text(
                    languages.lblMinutes,
                    style: boldTextStyle(),
                  ).paddingSymmetric(vertical: 15, horizontal: 10),
                ],
              ),
            ),
            5.height,
            nextIndex == 0
                ? const SizedBox()
                : Container(
                    width: w * 0.8,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade300),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Text(
                          "$nextIndex",
                          style: boldTextStyle(),
                        ).paddingSymmetric(vertical: 15, horizontal: 10),
                        Text(
                          widget.mExerciseModel!.data!.duration![nextIndex]
                              .duration!
                              .toString(),
                          style: boldTextStyle(),
                        ).paddingSymmetric(vertical: 15, horizontal: 10),
                      ],
                    ),
                  ),
            34.height,
            CircularCountDownTimer(
              duration: timer,
              initialDuration: 0,
              controller: countDownController,
              width: MediaQuery.of(context).size.width / 2.5,
              height: MediaQuery.of(context).size.height / 3.5,
              ringColor: Colors.grey[300]!,
              ringGradient: null,
              fillColor: appRedColor,
              fillGradient: null,
              backgroundColor: black,
              backgroundGradient: null,
              strokeWidth: 20.0,
              strokeCap: StrokeCap.round,
              textStyle: const TextStyle(
                fontSize: 33.0,
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
              textFormat: CountdownTextFormat.MM_SS,
              isReverse: true,
              isReverseAnimation: true,
              onComplete: () {
                if (nextIndex < allTimer.length) {
                  nextIndex++;
                  print(allTimer);
                  print(nextIndex);
                  timer = allTimer[nextIndex];
                  countDownController.restart(duration: timer);
                }
              },
              timeFormatterFunction: (defaultFormatterFunction, duration) {
                if (duration.inSeconds == 0) {
                  if (nextIndex < allTimer.length) {
                    flutterTts.speak(
                        "${widget.mExerciseModel!.data!.duration![nextIndex].duration!} Minutes");
                    WidgetsBinding.instance.addPostFrameCallback((_) {
                      setState(() => exerciseDone = false);
                    });
                    return "Start";
                  } else {
                    if (exerciseDone) {
                      flutterTts.speak(languages.lblExerciseDone.toString());
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        setState(() => exerciseDone = false);
                      });
                    }
                    return "Done";
                  }
                } else {
                  if (duration.inSeconds == 10) {
                    if (second10) {
                      flutterTts
                          .speak(languages.lblTenSecondRemaining.toString());
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        setState(() => second10 = false);
                      });
                    }
                  }
                  if (duration.inSeconds == 3) {
                    if (second3) {
                      flutterTts.speak(languages.lblThree.toString());
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        setState(() => second3 = false);
                      });
                    }
                  }
                  if (duration.inSeconds == 2) {
                    if (second2) {
                      flutterTts.speak(languages.lblTwo.toString());
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        setState(() => second2 = false);
                      });
                    }
                  }
                  if (duration.inSeconds == 1) {
                    if (second1) {
                      flutterTts.speak(languages.lblOne.toString());
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        setState(() => second1 = false);
                      });
                    }
                  }
                  return Function.apply(defaultFormatterFunction, [duration]);
                }
              },
            ),
          ],
        ).center(),
      ),
    );
  }
}

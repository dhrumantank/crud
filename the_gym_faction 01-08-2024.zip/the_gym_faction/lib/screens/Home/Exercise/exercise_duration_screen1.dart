import 'dart:io';

import 'package:TheGymFaction/extensions/extension_util/context_extensions.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:chewie/chewie.dart';
import 'package:circular_countdown_timer/circular_countdown_timer.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:simple_pip_mode/simple_pip.dart';
import 'package:video_player/video_player.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import '../../../../extensions/extension_util/string_extensions.dart';
import '../../../../extensions/extension_util/widget_extensions.dart';
import '../../../../models/exercise_detail_response.dart';
import '../../../components/HomeComponent/congratulations_dialog.dart';
import '../../../extensions/app_button.dart';
import '../../../extensions/colors.dart';
import '../../../extensions/constants.dart';
import '../../../extensions/extension_util/int_extensions.dart';
import '../../../extensions/extension_util/list_extensions.dart';
import '../../../extensions/system_utils.dart';
import '../../../extensions/text_styles.dart';
import '../../../extensions/widgets.dart';
import '../../../main.dart';
import '../../../models/models.dart';
import '../../../utils/app_colors.dart';
import '../../../utils/app_common.dart';

class ExerciseDurationScreen1 extends StatefulWidget {
  static String tag = '/ExerciseDurationScreen';
  final ExerciseDetailResponse? mExerciseModel;

  const ExerciseDurationScreen1(this.mExerciseModel, {super.key});

  @override
  ExerciseDurationScreen1State createState() => ExerciseDurationScreen1State();
}

class ExerciseDurationScreen1State extends State<ExerciseDurationScreen1> {
  Duration? duration;
  FlutterTts flutterTts = FlutterTts();
  int i = 0;
  int? mLength;
  Workout? _workout;
  Tabata? _tabata;

  List<String>? mExTime = [];
  List<String>? mRestTime = [];
  late VideoPlayerController _videoPlayerController1;
  ChewieController? _chewieController;
  int? bufferDelay;
  YoutubePlayerController? youtubePlayerController;
  late TextEditingController _idController;
  late TextEditingController _seekToController;
  late PlayerState? _playerState;
  late YoutubeMetaData videoMetaData;
  bool _isPlayerReady = false;
  String? videoId = '';

  bool visibleOption = true;
  bool? isChanged = false;
  int b = 0;

  @override
  initState() {
    super.initState();
    allDataList();
    getAllTimerList();
    if (widget.mExerciseModel!.data!.sets != null) {
      widget.mExerciseModel!.data!.sets!.forEachIndexed((element, index) {
        if ((widget.mExerciseModel!.data!.sets!.length - 1) == b) {
          mExTime!.add(element.time.toString());
          b++;
        } else {
          mExTime!.add(element.time.toString());
          mRestTime!.add(element.rest.toString());
          b++;
        }
        setState(() {});
      });
      _tabata = Tabata(
          sets: 1,
          reps: widget.mExerciseModel!.data!.sets!.length,
          startDelay: const Duration(seconds: 3),
          exerciseTime: mExTime,
          restTime: mRestTime,
          breakTime: const Duration(seconds: 60),
          status:
              widget.mExerciseModel!.data!.based == "reps" ? "reps" : "second");
    }

    initializePlayer();

    init();

    if (videoId != null) {
      videoId = YoutubePlayer.convertUrlToId(
          widget.mExerciseModel!.data!.videoUrl.validate());
    }
    flutterTts.awaitSpeakCompletion(true);
    if (videoId != null) {
      youtubePlayerController = YoutubePlayerController(
        initialVideoId: videoId!,
        flags: const YoutubePlayerFlags(
          mute: false,
          autoPlay: true,
          disableDragSeek: false,
          loop: false,
          isLive: false,
          forceHD: false,
          enableCaption: true,
          showLiveFullscreenButton: false,
        ),
      )..addListener(listener);
    }
    _idController = TextEditingController();
    _seekToController = TextEditingController();
    if (youtubePlayerController != null) {
      youtubePlayerController!.addListener(() {
        if (_playerState == PlayerState.playing) {
          if (isChanged == true) {
            _workout!.resetTimer();
            isChanged = false;
          }
        }
        if (_playerState == PlayerState.paused) {
          _workout!.pause();
          flutterTts.pause();
          isChanged = true;
        }
      });
    }
    videoMetaData = const YoutubeMetaData();
    _playerState = PlayerState.unknown;
  }

  init() async {
    //
    if (widget.mExerciseModel!.data!.sets != null) {
      mLength = widget.mExerciseModel!.data!.sets!.length - 2;
    }
    _workout = Workout(_tabata!, _onWorkoutChanged);
    _start();
  }

  @override
  dispose() {
    _workout!.dispose();
    _videoPlayerController1.dispose();
    if (youtubePlayerController != null) youtubePlayerController!.dispose();
    _idController.dispose();
    _seekToController.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  void exitScreen() {
    if (MediaQuery.of(context).orientation == Orientation.landscape) {
      SystemChrome.setPreferredOrientations(
          [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
    }
    finish(context);
  }

  void listener() {
    if (_isPlayerReady &&
        mounted &&
        !youtubePlayerController!.value.isFullScreen) {
      setState(() {
        _playerState = youtubePlayerController!.value.playerState;
        videoMetaData = youtubePlayerController!.metadata;
      });
    }
  }

  @override
  void deactivate() {
    // Pauses video while navigating to next page.
    if (youtubePlayerController != null) youtubePlayerController!.pause();
    super.deactivate();
  }

  Future<void> initializePlayer() async {
    _videoPlayerController1 = VideoPlayerController.networkUrl(
        Uri.parse(widget.mExerciseModel!.data!.videoUrl.validate()));
    await Future.wait([_videoPlayerController1.initialize()]);
    _createChewieController();
    _videoPlayerController1.addListener(() {
      // Do something based on controller state
      if (_videoPlayerController1.value.isPlaying) {
        print('Video is playing');
        if (isChanged == true) {
          _workout!.resetTimer();
          isChanged = false;
        }
      } else if (_videoPlayerController1.value.isBuffering) {
        print('Video is buffering');
      } else if (_videoPlayerController1.value.isInitialized) {
        _workout!.pause();
        flutterTts.pause();
        isChanged = true;
      } else {
        print('Video controller is in an unknown state');
      }
    });

    setState(() {});
  }

  void _createChewieController() {
    _chewieController = ChewieController(
      videoPlayerController: _videoPlayerController1,
      autoPlay: true,
      looping: true,
      deviceOrientationsAfterFullScreen: [
        DeviceOrientation.portraitDown,
        DeviceOrientation.portraitUp,
      ],
      progressIndicatorDelay:
          bufferDelay != null ? Duration(milliseconds: bufferDelay!) : null,
      hideControlsTimer: const Duration(seconds: 1),
      showOptions: false,
      materialProgressColors: ChewieProgressColors(
        playedColor: primaryColor,
        handleColor: primaryColor,
        backgroundColor: textSecondaryColorGlobal,
        bufferedColor: textSecondaryColorGlobal,
      ),
      // autoInitialize: true,
    );
  }

  int currPlayIndex = 0;

  Future<void> toggleVideo() async {
    await _videoPlayerController1.pause();
    currPlayIndex += 1;
    await initializePlayer();
  }

  _onWorkoutChanged() {
    if (_workout!.step == WorkoutState.finished) {
      // finish(context);
    }

    setState(() {});
  }

  _start() {
    _workout!.start();
  }

  Widget dividerHorizontalLine({bool? isSmall = false}) {
    return Container(
      height: isSmall == true ? 40 : 65,
      width: 4,
      color: whiteColor,
    );
  }

  Widget mSetText(String value, {String? value2}) {
    return Text(value, style: boldTextStyle(size: 18)).center();
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  Duration parseDuration(String durationString) {
    List<String> components = durationString.split(':');

    int hours = int.parse(components[0]);
    int minutes = int.parse(components[1]);
    int seconds = int.parse(components[2]);

    return Duration(hours: hours, minutes: minutes, seconds: seconds);
  }

  Widget mData(List<Sets> strings) {
    List<Widget> list = [];
    for (var i = 0; i < strings.length; i++) {
      list.add(Text(strings[i].time.toString()));
    }
    return Row(children: list);
  }

  void getCompleteWorkout() {
    Map<String, dynamic> req = {
      "exercise_id": widget.mExerciseModel!.data!.id!,
      "status": "complete",
    };
    getCompleteWorkoutApi(req).then((value) {
      showDialog(
        context: context,
        builder: (context) {
          return CongratulationsDialog(
            onTap: () {
              Navigator.pop(context, true);
            },
          );
        },
      ).then((value) {
        Navigator.pop(context, true);
        return;
      });
      return;
    });
  }

  List allData = [];

  void allDataList() {
    for (var element in widget.mExerciseModel!.data!.sets!) {
      allData.add({
        "reps": element.reps,
        "weight": element.weight,
        "rest": element.rest,
      });
    }
  }

  int timer = 3;
  int nextIndex = 0;
  List<int> allTimer = [];
  int a = 0;
  void getAllTimerList() {
    for (var element in widget.mExerciseModel!.data!.sets!) {
      if ((widget.mExerciseModel!.data!.sets!.length - 1) == a) {
        allTimer.add(element.time.toInt() + 1);
        a++;
      } else {
        allTimer.add(element.time.toInt() + 1);
        allTimer.add(element.rest.toInt() + 1);
        a++;
      }
      setState(() {});
    }
  }

  CountDownController countDownController = CountDownController();

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: appBarWidget(widget.mExerciseModel!.data!.title.validate(),
          context: context),
      bottomNavigationBar: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          if (_workout!.checkTime())
            AppButton(
              color: primaryColor,
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              width: w * 0.4,
              onTap: () {
                _workout!.pause();
                countDownController.pause();
              },
              text: "pause",
            )
          else
            AppButton(
              color: primaryColor,
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              width: w * 0.4,
              onTap: () {
                _workout!.start();
                countDownController.resume();
              },
              text: "start",
            ),
          if (_workout!.step == WorkoutState.finished)
            AppButton(
              color: primaryColor,
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              width: w * 0.4,
              onTap: () {
                getCompleteWorkout();
              },
              text: "Complete",
            )
          else
            AppButton(
              color: primaryColor,
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              width: w * 0.4,
              onTap: () {
                finish(context);
              },
              text: "Stop",
            ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            widget.mExerciseModel!.data!.videoUrl
                    .validate()
                    .contains("https://youtu")
                ? AspectRatio(
                    aspectRatio: 12 / 7,
                    child: YoutubePlayerBuilder(
                      onExitFullScreen: () {
                        SystemChrome.setPreferredOrientations(
                            DeviceOrientation.values);
                      },
                      onEnterFullScreen: () {
                        youtubePlayerController!.toggleFullScreenMode();
                      },
                      player: YoutubePlayer(
                        controller: youtubePlayerController!,
                        showVideoProgressIndicator: true,
                        progressIndicatorColor: Colors.white,
                        thumbnail: cachedImage(
                                widget.mExerciseModel!.data!.exerciseImage
                                    .validate(),
                                fit: BoxFit.fill,
                                height: context.height())
                            .cornerRadiusWithClipRRect(0),
                        progressColors: ProgressBarColors(
                          playedColor: Colors.white,
                          bufferedColor: Colors.grey.shade200,
                          handleColor: Colors.white,
                          backgroundColor: Colors.grey,
                        ),
                        topActions: <Widget>[
                          if (MediaQuery.of(context).orientation ==
                              Orientation.landscape)
                            Align(
                              alignment: Alignment.topRight,
                              child: IconButton(
                                padding: EdgeInsets.only(
                                    top: context.statusBarHeight + 20),
                                icon: const Icon(Icons.close,
                                    color: Colors.white, size: 25.0),
                                onPressed: () {
                                  exitScreen();
                                },
                              ),
                            ),
                        ],
                        onReady: () {
                          _isPlayerReady = true;
                        },
                        onEnded: (data) {
                          //
                        },
                      ),
                      builder: (context, player) => WillPopScope(
                        onWillPop: () {
                          exitScreen();
                          return Future.value(true);
                        },
                        child: Scaffold(
                          body: SizedBox(
                            height: context.height(),
                            child: Stack(
                              alignment: Alignment.topLeft,
                              children: [
                                Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    player,
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceEvenly,
                                      children: [
                                        IconButton(
                                            icon: const Icon(
                                                CupertinoIcons.gobackward_10,
                                                color: Colors.white,
                                                size: 30),
                                            onPressed: () {
                                              Duration currentPosition =
                                                  youtubePlayerController!
                                                      .value.position;
                                              Duration targetPosition =
                                                  currentPosition -
                                                      const Duration(
                                                          seconds: 10);
                                              youtubePlayerController!
                                                  .seekTo(targetPosition);
                                            }).visible(!youtubePlayerController!
                                                .value.isPlaying &&
                                            _isPlayerReady),
                                        GestureDetector(
                                          onTap: () {
                                            if (_isPlayerReady) {
                                              youtubePlayerController!
                                                      .value.isPlaying
                                                  ? youtubePlayerController!
                                                      .pause()
                                                  : youtubePlayerController!
                                                      .play();
                                              setState(() {});
                                            }
                                          },
                                          child: const SizedBox(
                                              height: 50, width: 50),
                                        ),
                                        IconButton(
                                            icon: const Icon(
                                                CupertinoIcons.goforward_10,
                                                color: Colors.white,
                                                size: 30),
                                            onPressed: () {
                                              Duration currentPosition =
                                                  youtubePlayerController!
                                                      .value.position;
                                              Duration targetPosition =
                                                  currentPosition +
                                                      const Duration(
                                                          seconds: 10);
                                              youtubePlayerController!
                                                  .seekTo(targetPosition);
                                            }).visible(!youtubePlayerController!
                                                .value.isPlaying &&
                                            _isPlayerReady),
                                      ],
                                    ),
                                  ],
                                ).center(),
                                if (visibleOption)
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      IconButton(
                                        padding: EdgeInsets.zero,
                                        icon: const Icon(Icons.close,
                                            color: Colors.white, size: 25.0),
                                        onPressed: () {
                                          exitScreen();
                                        },
                                      ),
                                      Platform.isAndroid
                                          ? IconButton(
                                              padding: EdgeInsets.zero,
                                              onPressed: () {
                                                SimplePip(onPipEntered: () {
                                                  visibleOption = false;
                                                  setState(() {});
                                                }, onPipExited: () {
                                                  visibleOption = true;
                                                  setState(() {});
                                                }).enterPipMode();
                                              },
                                              icon: const Icon(
                                                  Icons
                                                      .picture_in_picture_alt_outlined,
                                                  color: Colors.white,
                                                  size: 25.0),
                                            )
                                          : const SizedBox(),
                                    ],
                                  ).paddingOnly(top: 30, left: 8, right: 8),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ))
                : AspectRatio(
                    aspectRatio: 12 / 7,
                    child: _chewieController != null &&
                            _chewieController!
                                .videoPlayerController.value.isInitialized
                        ? Chewie(controller: _chewieController!)
                        : cachedImage(
                                widget.mExerciseModel!.data!.exerciseImage
                                    .validate(),
                                fit: BoxFit.contain,
                                height: context.height())
                            .cornerRadiusWithClipRRect(0),
                  ),
            30.height,
            // if (widget.mExerciseModel!.data!.sets != null)
            //   Row(
            //     mainAxisAlignment: MainAxisAlignment.spaceAround,
            //     children: [
            //       Column(
            //         children: [
            //           Text(
            //               '${_workout!.rep}/${widget.mExerciseModel!.data!.sets!.length.toString()}',
            //               style: boldTextStyle(size: 18)),
            //           Text(
            //             languages.lblSets,
            //             style: secondaryTextStyle(),
            //           )
            //         ],
            //       ),
            //       Column(
            //         children: [
            //           _workout!.rep >= 1
            //               ? mSetText(
            //                   widget.mExerciseModel!.data!.based == "reps"
            //                       ? widget.mExerciseModel!.data!
            //                           .sets![_workout!.rep - 1].reps
            //                           .toString()
            //                       : widget.mExerciseModel!.data!
            //                           .sets![_workout!.rep - 1].time
            //                           .toString())
            //               : mSetText("-"),
            //           Text(
            //             widget.mExerciseModel!.data!.based == "reps"
            //                 ? languages.lblReps
            //                 : languages.lblSecond,
            //             style: secondaryTextStyle(),
            //           )
            //         ],
            //       ),
            //     ],
            //   ).paddingSymmetric(horizontal: 16),
            if (widget.mExerciseModel!.data!.sets != null)
              Column(
                children: [
                  5.height,
                  Container(
                    width: w * 0.8,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey.shade300),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Text(
                          languages.reps,
                          style: boldTextStyle(),
                        ).paddingSymmetric(vertical: 15, horizontal: 10),
                        Text(
                          languages.lblWeight,
                          style: boldTextStyle(),
                        ).paddingSymmetric(vertical: 15, horizontal: 10),
                        Text(
                          "Step",
                          style: boldTextStyle(),
                        ).paddingSymmetric(vertical: 15, horizontal: 10),
                      ],
                    ),
                  ),
                  5.height,
                  // Column(
                  //   crossAxisAlignment: CrossAxisAlignment.center,
                  //   children: List.generate(
                  //       widget.mExerciseModel!.data!.sets!.length, (index) {
                  //     return Container(
                  //       width: w * 0.8,
                  //       decoration: BoxDecoration(
                  //         border: Border.all(color: Colors.grey.shade300),
                  //         borderRadius: BorderRadius.circular(10),
                  //       ),
                  //       child: Row(
                  //         mainAxisAlignment: MainAxisAlignment.spaceAround,
                  //         children: [
                  //           Text(
                  //             "${widget.mExerciseModel!.data!.sets![_workout!.rep - 1].reps}x",
                  //             style: boldTextStyle(),
                  //           ).paddingSymmetric(vertical: 10, horizontal: 10),
                  //           Text(
                  //             "${widget.mExerciseModel!.data!.sets![_workout!.rep - 1].weight} ${languages.kg}",
                  //             style: boldTextStyle(),
                  //           ).paddingSymmetric(vertical: 10, horizontal: 10),
                  //           Text(
                  //             "${_workout!.rep}/${widget.mExerciseModel!.data!.sets!.length.toString()}",
                  //             style: boldTextStyle(),
                  //           ).paddingSymmetric(vertical: 10, horizontal: 10),
                  //         ],
                  //       ).paddingSymmetric(vertical: 8),
                  //     ).paddingSymmetric(vertical: 5);
                  //   }),
                  // ),
                  _workout!.rep - 1 < 0
                      ? const SizedBox(
                          height: 46,
                        )
                      : Container(
                          width: w * 0.8,
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey.shade300),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Text(
                                "${widget.mExerciseModel!.data!.sets![_workout!.rep - 1].reps}x",
                                style: boldTextStyle(),
                              ).paddingSymmetric(vertical: 10, horizontal: 10),
                              Text(
                                "${widget.mExerciseModel!.data!.sets![_workout!.rep - 1].weight} ${languages.kg}",
                                style: boldTextStyle(),
                              ).paddingSymmetric(vertical: 10, horizontal: 10),
                              Text(
                                "${_workout!.rep}/${widget.mExerciseModel!.data!.sets!.length.toString()}",
                                style: boldTextStyle(),
                              ).paddingSymmetric(vertical: 10, horizontal: 10),
                            ],
                          ).paddingSymmetric(vertical: 8),
                        ).paddingSymmetric(vertical: 5),
                ],
              ),
            15.height,
            CircularCountDownTimer(
              duration: timer,
              initialDuration: 0,
              controller: countDownController,
              width: MediaQuery.of(context).size.width / 2.5,
              height: MediaQuery.of(context).size.height / 3.5,
              ringColor: Colors.grey[300]!,
              ringGradient: null,
              fillColor: appRedColor,
              fillGradient: null,
              backgroundColor: black,
              backgroundGradient: null,
              strokeWidth: 20.0,
              strokeCap: StrokeCap.round,
              textStyle: const TextStyle(
                fontSize: 33.0,
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
              textFormat: CountdownTextFormat.MM_SS,
              isReverse: true,
              isReverseAnimation: true,
              onComplete: () {
                setState(() {
                  if (nextIndex < allTimer.length) {
                    nextIndex++;
                    timer = allTimer[nextIndex];
                    countDownController.restart(duration: timer);
                  }
                });
              },
              timeFormatterFunction: (defaultFormatterFunction, duration) {
                return Function.apply(defaultFormatterFunction, [duration]);
                // if (duration.inSeconds == 0) {
                //   return "go";
                // } else {
                //   return Function.apply(defaultFormatterFunction, [duration]);
                // }
              },
            ),
            // Container(
            //   child: FittedBox(
            //     child: Text(
            //       formatTime1(_workout!.timeLeft),
            //       style: boldTextStyle(size: 110),
            //     ),
            //   ),
            // ),
            // 16.height,
            // Column(
            //   children: List.generate(
            //     allData.length,
            //     (index) {
            //       return Text(
            //         allData[index].toString(),
            //         style: boldTextStyle(
            //           color: _workout!.nextInd == index
            //               ? Colors.green
            //               : Colors.black,
            //         ),
            //       );
            //     },
            //   ),
            // )
          ],
        ).center(),
      ),
    );
  }
}

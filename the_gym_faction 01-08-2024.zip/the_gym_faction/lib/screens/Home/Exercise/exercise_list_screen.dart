import 'package:animation_list/animation_list.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../../../../extensions/extension_util/int_extensions.dart';
import '../../../../extensions/extension_util/widget_extensions.dart';
import '../../../../extensions/widgets.dart';
import '../../../../screens/no_data_screen.dart';
import '../../../components/HomeComponent/exercise_component.dart';
import '../../../extensions/extension_util/string_extensions.dart';
import '../../../main.dart';
import '../../../models/exercise_response.dart';
import '../../../network/rest_api.dart';

class ExerciseListScreen extends StatefulWidget {
  const ExerciseListScreen(
      {super.key,
      this.mTitle,
      this.isBodyPart = false,
      this.isLevel = false,
      this.isEquipment = false,
      this.id});
  final bool? isBodyPart;
  final bool? isLevel;
  final bool? isEquipment;
  final String? mTitle;
  final int? id;

  @override
  State<ExerciseListScreen> createState() => _ExerciseListScreenState();
}

class _ExerciseListScreenState extends State<ExerciseListScreen> {
  ScrollController scrollController = ScrollController();
  TextEditingController searchCont = TextEditingController();
  List<ExerciseModel> mExerciseList = [];

  int page = 1;
  int? numPage;

  bool isLastPage = false;
  bool isSearch = false;

  String? mSearchValue = "";

  @override
  void initState() {
    super.initState();
    init();
    scrollController.addListener(() {
      if (scrollController.position.pixels ==
              scrollController.position.maxScrollExtent &&
          !appStore.isLoading) {
        if (page < numPage!) {
          page++;
          init();
        }
      }
    });
  }

  void init() async {
    getExerciseData();
  }

  Future<void> getExerciseData() async {
    appStore.setLoading(true);
    await getExerciseApi(
            page: page,
            mSearchValue: mSearchValue,
            id: widget.id.validate(),
            isBodyPart: widget.isBodyPart,
            isEquipment: widget.isEquipment,
            isLevel: widget.isLevel)
        .then((value) {
      appStore.setLoading(false);
      numPage = value.pagination!.totalPages;
      isLastPage = false;
      if (page == 1) {
        mExerciseList.clear();
      }
      // for (var element in value.data!) {
      //   mExerciseList.add(element);
      // }
      Iterable it = value.data!;
      it.map((e) => mExerciseList.add(e)).toList();
      setState(() {});
    }).catchError((e) {
      isLastPage = true;
      appStore.setLoading(false);
      setState(() {});
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBarWidget(
          isSearch ? "" : widget.mTitle.validate().capitalizeFirstLetter(),
          context: context),
      body: Stack(
        children: [
          mExerciseList.isNotEmpty
              ? AnimationList(
                  controller: scrollController,
                  duration: 4000,
                  children: List.generate(
                    mExerciseList.length,
                    (index) =>
                        ExerciseComponent(mExerciseModel: mExerciseList[index]),
                  ),
                )
              : NoDataScreen(mTitle: languages.lblExerciseNoFound)
                  .visible(!appStore.isLoading),
          const ShimmerEffectScreen().center().visible(appStore.isLoading)
        ],
      ),
    );
  }
}

class ShimmerEffectScreen extends StatelessWidget {
  const ShimmerEffectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return SingleChildScrollView(
      child: Column(
        children: [
          10.height,
          ListView.builder(
            itemCount: 10,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) {
              return Stack(
                children: [
                  Shimmer.fromColors(
                      baseColor: Colors.grey.shade200,
                      highlightColor: Colors.white54,
                      child: Container(
                        width: w,
                        height: h * 0.12,
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              blurRadius: 10,
                              color: Colors.grey.shade200,
                              spreadRadius: 2,
                            )
                          ],
                          color: Colors.grey.shade200,
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ).paddingSymmetric(horizontal: 20, vertical: 10)),
                  Positioned(
                    top: h * 0.035,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        40.width,
                        Shimmer.fromColors(
                          baseColor: Colors.grey.shade300,
                          highlightColor: Colors.white54,
                          child: CircleAvatar(
                              radius: 30,
                              backgroundColor: Colors.grey.shade300),
                        ),
                        20.width,
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Shimmer.fromColors(
                              baseColor: Colors.grey.shade300,
                              highlightColor: Colors.white54,
                              child: Container(
                                width: w * 0.4,
                                height: h * 0.02,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5),
                                  color: Colors.grey.shade300,
                                ),
                              ),
                            ),
                            5.height,
                            Shimmer.fromColors(
                              baseColor: Colors.grey.shade300,
                              highlightColor: Colors.white54,
                              child: Container(
                                width: w * 0.3,
                                height: h * 0.02,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5),
                                  color: Colors.grey.shade300,
                                ),
                              ),
                            ),
                            5.height,
                            Shimmer.fromColors(
                              baseColor: Colors.grey.shade300,
                              highlightColor: Colors.white54,
                              child: Container(
                                width: w * 0.2,
                                height: h * 0.02,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5),
                                  color: Colors.grey.shade300,
                                ),
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  )
                ],
              );
            },
          )
        ],
      ),
    );
  }
}

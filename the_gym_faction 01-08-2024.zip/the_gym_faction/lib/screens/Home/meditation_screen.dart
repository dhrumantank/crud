import 'package:TheGymFaction/extensions/extension_util/context_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:TheGymFaction/screens/no_data_screen.dart';
import 'package:circular_countdown_timer/circular_countdown_timer.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../components/fast_and_meditation_shimmer_effect.dart';
import '../../extensions/app_button.dart';
import '../../extensions/colors.dart';
import '../../extensions/constants.dart';
import '../../extensions/text_styles.dart';
import '../../main.dart';
import '../../models/diet_list_model.dart';
import '../../models/meditation_response.dart';
import '../../utils/app_colors.dart';
import '../../utils/app_common.dart';
import '../../utils/app_images.dart';

class MeditationScreen extends StatefulWidget {
  const MeditationScreen({super.key});

  @override
  State<MeditationScreen> createState() => _MeditationScreenState();
}

class _MeditationScreenState extends State<MeditationScreen> {
  bool select = true;
  FlutterTts flutterTts = FlutterTts();
  CountDownController countDownController = CountDownController();
  MeditationResponse meditationResponse = MeditationResponse();
  MeditationDatum meditationDatum = MeditationDatum();
  MeditationHistory meditationHistory = MeditationHistory(
    data: [],
    pendingCount: 0,
    inProgressCount: 0,
    completeCount: 0,
    totalMeditations: 0,
  );
  List<DoughnutChart> chartData = [];
  bool getData = false;
  bool getHistoryData = false;
  bool currentFast = false;
  int totalTime = 0;
  int startTime = 0;
  bool second1 = true;
  bool second2 = true;
  bool second3 = true;

  void fetchMeditationData({bool speak = false}) {
    int index = 0;
    setState(() => getData = true);
    getMeditationApi().then((value) {
      meditationResponse = value;
      for (var element in value.data!) {
        if (element.status == "in_progress") {
          meditationDatum = value.data![index];
          currentFast = true;
          totalTime = int.parse("${element.totalTime! * 60}");
          // startTime =
          //     int.parse("${(element.totalTime! - element.pendingTime!) * 60}");
          startTime = (totalTime - element.pendingTimeSeconds!);
          if (totalTime == element.pendingTimeSeconds!) {
            startTime = 0;
          }
          index++;
          setState(() {});
        } else {
          index++;
          setState(() {});
        }
      }
      setState(() => getData = false);
      if (speak == true) {
        flutterTts.speak("Your Meditation Start");
      }
    });
  }

  void addStartMeditationApi(int id) {
    Map<String, dynamic> req = {"meditation_id": id};
    setStartMeditationApi(req).then((value) {
      if (value["success"] == true) {
        fetchMeditationData(speak: true);
      }
      toast(value["message"]);
      return;
    });
  }

  void addMeditationHistoryData() {
    setState(() => getHistoryData = true);
    getMeditationHistoryApi().then((value) {
      meditationHistory = value;
      setState(() => getHistoryData = false);
      return null;
    });
  }

  @override
  void initState() {
    fetchMeditationData();
    addMeditationHistoryData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(h * 0.14),
        child: Column(
          children: [
            (h * 0.03).toInt().height,
            ListTile(
              leading: IconButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                icon: const Icon(
                  Icons.arrow_back_ios_new_outlined,
                  color: black,
                ),
              ),
              titleAlignment: ListTileTitleAlignment.center,
              title: Text(
                "Meditation",
                style: boldTextStyle(),
              ),
            ),
            CustomTabBar(
              select: select,
              fistOnTap: () {
                setState(() {
                  select = !select;
                });
              },
              secondOnTap: () {
                setState(() {
                  select = !select;
                });
              },
            ),
          ],
        ),
      ),
      body: select
          ? getData
              ? const FastAndMeditationShimmerEffect()
              : MeditationData(
                  flutterTts: flutterTts,
                  onTab: (index) {
                    addStartMeditationApi(meditationResponse.data![index].id!);
                    Navigator.pop(context);
                  },
                  countDownController: countDownController,
                  currentFast: currentFast,
                  meditationDatum: meditationDatum,
                  meditationResponse: meditationResponse,
                  getData: getData,
                  startTime: startTime,
                  totalTime: totalTime,
                  call: (duration) {
                    if (duration.inSeconds == 3) {
                      if (second3) {
                        flutterTts.speak(languages.lblThree.toString());
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          setState(() => second3 = false);
                        });
                      }
                    }
                    if (duration.inSeconds == 2) {
                      if (second2) {
                        flutterTts.speak(languages.lblTwo.toString());
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          setState(() => second2 = false);
                        });
                      }
                    }
                    if (duration.inSeconds == 1) {
                      if (second1) {
                        flutterTts.speak(languages.lblOne.toString());
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          setState(() => second1 = false);
                        });
                      }
                    }
                  },
                )
          : getHistoryData
              ? const FastAndMeditationHistoryShimmer()
              : meditationHistory.data!.isNotEmpty
                  ? MeditationHistoryScreen(
                      getHistoryData: getHistoryData,
                      chartData: chartData,
                      meditationHistory: meditationHistory,
                      completedData: meditationHistory.completeCount!,
                    )
                  : const NoDataScreen(mTitle: "No Meditation History"),
    );
  }
}

class MeditationData extends StatelessWidget {
  const MeditationData({
    super.key,
    required this.getData,
    required this.currentFast,
    required this.totalTime,
    required this.startTime,
    required this.countDownController,
    required this.onTab,
    required this.meditationDatum,
    required this.meditationResponse,
    required this.flutterTts,
    required this.call,
  });
  final bool getData;
  final bool currentFast;
  final int totalTime;
  final int startTime;

  final FlutterTts flutterTts;
  final CountDownController countDownController;
  final MeditationDatum meditationDatum;
  final MeditationResponse meditationResponse;
  final void Function(dynamic) onTab;
  final void Function(Duration) call;

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SingleChildScrollView(
      child: Column(children: [
        currentFast
            ? Container(
                width: w,
                // height: h * 0.4,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade200,
                      spreadRadius: 3,
                      blurRadius: 10,
                    )
                  ],
                  color: whiteColor,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    10.height,
                    Text(
                      "Current Meditation",
                      style: boldTextStyle(),
                    ),
                    20.height,
                    CircularCountDownTimer(
                      duration: totalTime,
                      initialDuration: startTime,
                      controller: countDownController,
                      width: w * 0.4,
                      height: h * 0.2,
                      autoStart: true,
                      ringColor: Colors.grey[300]!,
                      fillColor: appRedColor,
                      backgroundColor: black,
                      strokeWidth: 20.0,
                      strokeCap: StrokeCap.round,
                      textStyle: boldTextStyle(color: Colors.white, size: 25),
                      textFormat: CountdownTextFormat.HH_MM_SS,
                      isReverse: true,
                      isReverseAnimation: true,
                      timeFormatterFunction:
                          (defaultFormatterFunction, duration) {
                        // return Function.apply(defaultFormatterFunction, [duration]);
                        if (duration.inSeconds == 0) {
                          flutterTts.speak("Meditation Complete");
                          return "Complete";
                        } else {
                          call(duration);
                          return Function.apply(
                            defaultFormatterFunction,
                            [duration],
                          );
                        }
                      },
                    ).center(),
                    20.height,
                    Row(
                      children: [
                        Container(
                          width: w * 0.11,
                          height: h * 0.05,
                          decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.shade200,
                                spreadRadius: 3,
                                blurRadius: 10,
                              )
                            ],
                            borderRadius: BorderRadius.circular(80),
                          ),
                          child: const Image(
                            image: AssetImage(meditation),
                          ),
                        ),
                        10.width,
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(meditationDatum.title.toString()),
                            1.height,
                            Text("${meditationDatum.time} Minutes"),
                            1.height,
                            Text.rich(
                                TextSpan(text: "Start Time :- ", children: [
                              TextSpan(
                                  text: meditationDatum.startTime.toString())
                            ])),
                            1.height,
                            Text.rich(TextSpan(text: "End Time :- ", children: [
                              TextSpan(text: meditationDatum.endTime.toString())
                            ])),
                          ],
                        ),
                      ],
                    ),
                    20.height,
                  ],
                ).paddingSymmetric(horizontal: 20),
              ).paddingSymmetric(vertical: 20, horizontal: 20)
            : Container(
                width: w,
                // height: h * 0.4,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade200,
                      spreadRadius: 3,
                      blurRadius: 10,
                    )
                  ],
                  color: whiteColor,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    10.height,
                    Text(
                      "Current Meditation",
                      style: boldTextStyle(),
                    ),
                    20.height,
                    Text(
                      "Current Meditation Is Not Found",
                      style: boldTextStyle(),
                    ).paddingSymmetric(vertical: 10, horizontal: 20),
                    20.height,
                  ],
                ).paddingSymmetric(horizontal: 20),
              ).paddingSymmetric(vertical: 20, horizontal: 20),
        meditationResponse.data!.isNotEmpty
            ? ListView.builder(
                itemCount: meditationResponse.data!.length,
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  MeditationDatum meditationDatum =
                      meditationResponse.data![index];
                  return Container(
                    width: w,
                    // height: h * 0.2,
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.shade200,
                          spreadRadius: 3,
                          blurRadius: 10,
                        )
                      ],
                      color: whiteColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Stack(
                      children: [
                        Column(
                          children: [
                            20.height,
                            Row(
                              children: [
                                20.width,
                                Container(
                                  width: w * 0.11,
                                  height: h * 0.05,
                                  decoration: BoxDecoration(
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.shade200,
                                        spreadRadius: 3,
                                        blurRadius: 10,
                                      )
                                    ],
                                    borderRadius: BorderRadius.circular(80),
                                  ),
                                  child: const Image(
                                    image: AssetImage(meditation),
                                  ),
                                ),
                                10.width,
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                        constraints:
                                            BoxConstraints(maxWidth: w * 0.7),
                                        child: Text(
                                            meditationDatum.title.toString())),
                                    1.height,
                                    Text("${meditationDatum.time} Minutes"),
                                  ],
                                ),
                              ],
                            ),
                            Align(
                                alignment: Alignment.bottomRight,
                                child: IntrinsicWidth(
                                  child: Container(
                                    margin: const EdgeInsets.only(right: 10),
                                    decoration: BoxDecoration(
                                      color: Colors.green,
                                      borderRadius: BorderRadius.circular(5),
                                    ),
                                    child: Row(
                                      children: [
                                        Text(
                                          "Start Meditation",
                                          style: boldTextStyle(
                                              color: whiteColor, size: 12),
                                        ).paddingSymmetric(
                                            horizontal: 8, vertical: 4),
                                        const Icon(
                                          Icons.keyboard_arrow_right,
                                          color: Colors.white,
                                        )
                                      ],
                                    ),
                                  ),
                                )),
                            10.height,
                          ],
                        ),
                      ],
                    ),
                  ).onTap(() {
                    showDialog(
                      context: context,
                      builder: (context) {
                        return FastingStartDialog(
                          onTab: () {
                            onTab(index);
                          },
                          startDate: meditationDatum.title,
                        );
                      },
                    );
                  }).paddingSymmetric(vertical: 5, horizontal: 20);
                },
              )
            : Container(
                width: w,
                // height: h * 0.2,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade200,
                      spreadRadius: 3,
                      blurRadius: 10,
                    )
                  ],
                  color: whiteColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Text("No Data")
                    .paddingSymmetric(horizontal: 10, vertical: 20),
              ).paddingSymmetric(horizontal: 20),
      ]),
    );
  }
}

class MeditationHistoryScreen extends StatelessWidget {
  const MeditationHistoryScreen({
    super.key,
    required this.chartData,
    required this.meditationHistory,
    required this.completedData,
    required this.getHistoryData,
  });
  final List<DoughnutChart> chartData;
  final MeditationHistory meditationHistory;
  final int completedData;
  final bool getHistoryData;

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    DateFormat dateFormat2 = DateFormat("dd-MM-yyyy HH:mm");
    return SingleChildScrollView(
      child: Column(
        children: [
          // ChartData(
          //   chartData: chartData,
          //   meditation: completedData,
          // ),
          ListView.builder(
            itemCount: meditationHistory.data!.length,
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemBuilder: (context, index) {
              MeditationHistoryDatum meditationData =
                  meditationHistory.data![index];
              return Container(
                width: w,
                // height: h * 0.2,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade200,
                      spreadRadius: 3,
                      blurRadius: 10,
                    )
                  ],
                  color: whiteColor,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Stack(
                  children: [
                    Column(
                      children: [
                        40.height,
                        Row(
                          children: [
                            20.width,
                            Container(
                              width: w * 0.11,
                              height: h * 0.05,
                              decoration: BoxDecoration(
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.grey.shade200,
                                    spreadRadius: 3,
                                    blurRadius: 10,
                                  )
                                ],
                                borderRadius: BorderRadius.circular(80),
                              ),
                              child: const Image(image: AssetImage(meditation)),
                            ),
                            10.width,
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                    constraints:
                                        BoxConstraints(maxWidth: w * 0.7),
                                    child:
                                        Text(meditationData.title.toString())),
                                2.height,
                                Text(
                                    "${meditationData.time.toString()} Minutes"),
                                2.height,
                                Text.rich(
                                  TextSpan(text: "Start Time :- ", children: [
                                    TextSpan(
                                      text: dateFormat2
                                          .format(meditationData.startTime!),
                                    )
                                  ]),
                                ),
                                2.height,
                                Text.rich(
                                  TextSpan(text: "End Time :- ", children: [
                                    TextSpan(
                                      text: dateFormat2
                                          .format(meditationData.endTime!),
                                    )
                                  ]),
                                ),
                              ],
                            ),
                          ],
                        ),
                        20.height,
                      ],
                    ),
                    Align(
                      alignment: Alignment.topRight,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.green,
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Text(
                          "Completed",
                          style: boldTextStyle(color: whiteColor, size: 12),
                        ).paddingSymmetric(horizontal: 8, vertical: 4),
                      ).paddingSymmetric(horizontal: 10, vertical: 8),
                    ),
                  ],
                ),
              ).paddingSymmetric(vertical: 5, horizontal: 20);
            },
          ),
        ],
      ),
    );
  }
}

class CustomTabBar extends StatelessWidget {
  const CustomTabBar(
      {super.key, required this.select, this.fistOnTap, this.secondOnTap});
  final bool select;
  final void Function()? fistOnTap;
  final void Function()? secondOnTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(top: 22),
      decoration: BoxDecoration(
          border: Border(
              bottom: BorderSide(
                  color:
                      appStore.isDarkMode ? whiteColor : context.dividerColor,
                  width: 0.5))),
      child: Row(children: [
        GestureDetector(
          onTap: fistOnTap,
          child: Container(
              padding: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(
                  border: Border(
                      bottom: BorderSide(
                          width: 1.5,
                          color: select ? primaryColor : Colors.transparent))),
              child: Text("Add Meditation",
                      style: boldTextStyle(
                          color:
                              select ? primaryColor : textSecondaryColorGlobal))
                  .center()),
        ).expand(),
        GestureDetector(
          onTap: secondOnTap,
          child: Container(
            padding: const EdgeInsets.only(bottom: 8),
            decoration: BoxDecoration(
                border: Border(
                    bottom: BorderSide(
                        width: 1.5,
                        color: select ? Colors.transparent : primaryColor))),
            child: Text("Meditation History",
                    style: boldTextStyle(
                        color:
                            select ? textSecondaryColorGlobal : primaryColor))
                .center(),
          ),
        ).expand(),
      ]).paddingSymmetric(horizontal: 16),
    );
  }
}

class FastingStartDialog extends StatelessWidget {
  const FastingStartDialog({super.key, this.startDate, required this.onTab});
  final String? startDate;

  final void Function() onTab;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        width: w,
        height: h * 0.3,
        decoration: BoxDecoration(
          color: whiteColor,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            10.height,
            Text(
              "Start Meditation For $startDate",
              style: boldTextStyle(),
            ),
            10.height,
            Text(
              "Are You Sure Start Meditation?",
              style: boldTextStyle(),
            ),
            50.height,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                AppButton(
                  color: appRedColor,
                  onTap: () {
                    Navigator.pop(context);
                  },
                  text: "No",
                ),
                AppButton(
                  color: Colors.green,
                  onTap: onTab,
                  text: "Yes",
                ),
              ],
            ),
          ],
        ).paddingSymmetric(horizontal: 20),
      ),
    );
  }
}

class ChartData extends StatelessWidget {
  const ChartData({
    super.key,
    required this.chartData,
    required this.meditation,
  });
  final List<DoughnutChart> chartData;
  final int meditation;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return SizedBox(
      width: w * 0.6,
      height: h * 0.3,
      child: Stack(
        children: [
          SfCircularChart(
            tooltipBehavior: TooltipBehavior(enable: true),
            series: <CircularSeries<DoughnutChart, String>>[
              DoughnutSeries<DoughnutChart, String>(
                dataSource: chartData,
                xValueMapper: (DoughnutChart data, _) => data.x,
                yValueMapper: (DoughnutChart data, _) => data.y,
                pointColorMapper: (DoughnutChart data, _) => data.color,
                dataLabelMapper: (DoughnutChart data, _) => data.text,
                radius: '100%',
                innerRadius: '60%',
                dataLabelSettings: const DataLabelSettings(
                    isVisible: true, textStyle: TextStyle(color: whiteColor)
                    // labelPosition: ChartDataLabelPosition.inside,
                    ),
              ),
            ],
          ),
          Align(
            alignment: Alignment.center,
            child: Text(
              "$meditation Meditation\nCompleted",
              style: boldTextStyle(),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}

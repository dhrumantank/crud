import 'dart:math';

import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:animation_list/animation_list.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../../../components/HomeComponent/equipment_component.dart';
import '../../../extensions/colors.dart';
import '../../../extensions/loader_widget.dart';
import '../../../extensions/widgets.dart';
import '../../../main.dart';
import '../../../models/equipment_response.dart';
import '../../../network/rest_api.dart';

class ViewEquipmentScreen extends StatefulWidget {
  const ViewEquipmentScreen({super.key});

  @override
  State<ViewEquipmentScreen> createState() => _ViewEquipmentScreenState();
}

class _ViewEquipmentScreenState extends State<ViewEquipmentScreen> {
  ScrollController scrollController = ScrollController();
  EquipmentResponse2 equipmentResponse = EquipmentResponse2();

  List<EquipmentResponse2Datum> mEquipmentList = [];

  int page = 1;
  int? numPage;

  bool isLastPage = false;

  @override
  void initState() {
    super.initState();
    getEquipmentData();
    scrollController.addListener(() {
      if (scrollController.position.extentAfter < 1) {
        if (page < numPage!) {
          page++;
          setState(() => isLastPage = true);
          getEquipmentData();
        }
      }
    });
  }

  Future<void> getEquipmentData() async {
    if (page == 1) {
      appStore.setLoading(true);
    }
    await getEquipmentListApi(page: page).then((value) {
      for (var element in value.data!.data!) {
        mEquipmentList.add(element);
      }
      numPage = value.data!.lastPage;
      appStore.setLoading(false);
      setState(() => isLastPage = false);
    }).catchError((e) {
      setState(() => isLastPage = false);
      appStore.setLoading(false);
      setState(() {});
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  int colorIndex = 0;
  List<Color> color = [
    const Color(0xFFb8daff),
    const Color(0xFFc3e6cb),
    const Color(0xFFf5c6cb),
    const Color(0xFFffeeba),
    const Color(0xFFc6c8ca),
  ];
  Random random = Random();
  void changeIndex() {
    setState(() => colorIndex = random.nextInt(color.length));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: appBarWidget(languages.lblEquipmentsExercise,
          elevation: 0, context: context),
      body: appStore.isLoading
          ? const EquipmentShimmerEffect()
          : SingleChildScrollView(
              controller: scrollController,
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  AnimationList(
                    duration: 4000,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    children: List.generate(
                      mEquipmentList.length,
                      (index) {
                        changeIndex();
                        return EquipmentComponent(
                            randomColor: color[colorIndex],
                            mEquipmentModel2: mEquipmentList[index]);
                      },
                    ),
                  ),
                  if (isLastPage) 20.height,
                  if (isLastPage) const Loader().center(),
                  if (isLastPage) 20.height,
                ],
              ),
            ),
    );
  }
}

class EquipmentShimmerEffect extends StatelessWidget {
  const EquipmentShimmerEffect({super.key});

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return SingleChildScrollView(
      child: Column(
        children: [
          10.height,
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: List.generate(
              15,
              (index) => Stack(
                children: [
                  Shimmer.fromColors(
                    baseColor: Colors.grey.shade200,
                    highlightColor: whiteColor,
                    child: Container(
                      width: w,
                      height: h * 0.15,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.grey.shade200,
                      ),
                    ).paddingSymmetric(vertical: 10),
                  ),
                  SizedBox(
                    width: w,
                    height: h * 0.15,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Shimmer.fromColors(
                          baseColor: Colors.grey.shade300,
                          highlightColor: whiteColor,
                          child: Container(
                            height: h * 0.04,
                            width: w * 0.3,
                            decoration: BoxDecoration(
                              color: Colors.grey.shade300,
                              borderRadius: BorderRadius.circular(5),
                            ),
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Shimmer.fromColors(
                              baseColor: Colors.grey.shade300,
                              highlightColor: whiteColor,
                              child: Container(
                                height: h * 0.025,
                                width: w * 0.2,
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade300,
                                  borderRadius: BorderRadius.circular(5),
                                ),
                              ),
                            ),
                            7.width,
                            Shimmer.fromColors(
                              baseColor: Colors.grey.shade300,
                              highlightColor: whiteColor,
                              child: Container(
                                height: h * 0.025,
                                width: w * 0.06,
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade300,
                                  borderRadius: BorderRadius.circular(5),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Shimmer.fromColors(
                              baseColor: Colors.grey.shade300,
                              highlightColor: whiteColor,
                              child: Container(
                                height: h * 0.025,
                                width: w * 0.06,
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade300,
                                  borderRadius: BorderRadius.circular(5),
                                ),
                              ),
                            ),
                            7.width,
                            Shimmer.fromColors(
                              baseColor: Colors.grey.shade300,
                              highlightColor: whiteColor,
                              child: Container(
                                height: h * 0.025,
                                width: w * 0.06,
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade300,
                                  borderRadius: BorderRadius.circular(5),
                                ),
                              ),
                            ),
                            7.width,
                            Shimmer.fromColors(
                              baseColor: Colors.grey.shade300,
                              highlightColor: whiteColor,
                              child: Container(
                                height: h * 0.025,
                                width: w * 0.06,
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade300,
                                  borderRadius: BorderRadius.circular(5),
                                ),
                              ),
                            ),
                            7.width,
                          ],
                        )
                      ],
                    ).paddingSymmetric(horizontal: 20),
                  ).paddingSymmetric(vertical: 10),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Shimmer.fromColors(
                      baseColor: Colors.grey.shade300,
                      highlightColor: whiteColor,
                      child: Container(
                        width: w * 0.5,
                        height: h * 0.15,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: const BorderRadius.only(
                            bottomRight: Radius.circular(20),
                            topRight: Radius.circular(20),
                            topLeft: Radius.elliptical(5, 30),
                            bottomLeft: Radius.elliptical(110, 150),
                          ),
                        ),
                      ),
                    ).paddingSymmetric(vertical: 10),
                  ),
                ],
              ),
            ),
          ),
        ],
      ).paddingSymmetric(horizontal: 15),
    );
  }
}

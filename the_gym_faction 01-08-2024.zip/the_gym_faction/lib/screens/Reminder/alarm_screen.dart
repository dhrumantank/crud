import 'package:flutter/material.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/utils/app_images.dart';

import '../../extensions/widgets.dart';

class AlarmScreen extends StatefulWidget {
  const AlarmScreen({super.key});

  @override
  State<AlarmScreen> createState() => _AlarmScreenState();
}

class _AlarmScreenState extends State<AlarmScreen> {
  // DateTime dateTime = DateTime.utc(2024, 06, 27, 05, 52);
  // late bool creating;
  // late DateTime selectedDateTime;
  // late bool loopAudio;
  // late bool vibrate;
  // late double? volume;
  // late String assetAudio;
  // late List<AlarmSettings> alarms;
  // int? newId;
  //
  // static StreamSubscription<AlarmSettings>? subscriptionData;

  // @override
  // void initState() {
  //   selectedDateTime = DateTime.now().add(const Duration(minutes: 2));
  //   selectedDateTime = selectedDateTime.copyWith(second: 0, millisecond: 0);
  //   loopAudio = true;
  //   vibrate = true;
  //   volume = null;
  //   assetAudio = 'assets/audio/Ringtone.mp3';
  //   super.initState();
  //   subscriptionData ??= Alarm.ringStream.stream.listen(
  //     (event) {
  //       newId = event.id;
  //       setState(() {
  //         Timer(const Duration(seconds: 30), () {
  //           Alarm.stop(event.id);
  //         });
  //       });
  //     },
  //   );
  //   loadAlarms();
  // }

  // void loadAlarms() {
  //   setState(() {
  //     alarms = Alarm.getAlarms();
  //     alarms.sort((a, b) => a.dateTime.isBefore(b.dateTime) ? 0 : 1);
  //   });
  // }
  //
  // AlarmSettings buildAlarmSettings() {
  //   final id = DateTime.now().millisecondsSinceEpoch % 10000 + 1;
  //   final alarmSettings = AlarmSettings(
  //     id: id,
  //     dateTime: selectedDateTime,
  //     loopAudio: loopAudio,
  //     vibrate: vibrate,
  //     volume: volume,
  //     assetAudioPath: assetAudio,
  //     notificationTitle: 'Alarm example',
  //     notificationBody: 'Your alarm ($id) is ringing',
  //     enableNotificationOnKill: Platform.isIOS,
  //   );
  //   return alarmSettings;
  // }
  //
  // void saveAlarm() {
  //   Alarm.set(alarmSettings: buildAlarmSettings()).then((res) {
  //     if (res) {
  //       if (kDebugMode) {
  //         print(
  //             "============================== Done ====================================");
  //       }
  //     }
  //   });
  // }
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: appBarWidget(
        "Alarm",
        context: context,
        titleSpacing: 16,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: w * 0.8,
            height: h * 0.385,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(200),
              border: Border.all(
                color: const Color(0xFFF67558),
                width: 4,
              ),
            ),
            child: Column(
              children: [
                30.height,
                const ImageIcon(
                  AssetImage(ic_notification),
                  color: Color(0xFFF67558),
                  size: 25,
                ),
                30.height,
              ],
            ),
          ).center(),
        ],
      ),
    );
  }
}

import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/utils/app_colors.dart';
import 'package:flutter/material.dart';

import '../../extensions/constants.dart';
import '../../extensions/widgets.dart';
import '../../main.dart';
import '../../utils/app_images.dart';
import 'AddReminder/reminder_screen.dart';

class Reminder extends StatefulWidget {
  const Reminder({super.key});

  @override
  State<Reminder> createState() => _ReminderState();
}

class _ReminderState extends State<Reminder> {
  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: appBarWidget(
        languages.lblReminder,
        context: context,
        showBack: false,
        titleSpacing: 16,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(languages.lblReminder),
            5.height,
            Container(
              alignment: Alignment.center,
              width: w,
              height: h * 0.08,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.shade200,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: ListTile(
                leading: Image.asset(ic_reminder,
                    width: 20, height: 20, color: textPrimaryColorGlobal),
                title: Text(languages.lblDailyReminders),
                trailing: const Icon(Icons.chevron_right, color: grayColor),
                onTap: () {
                  const ReminderScreen().launch(context);
                },
              ),
            ),
            10.height,
            // const Text("Alarm"),
            // 10.height,
            // Container(
            //   alignment: Alignment.center,
            //   width: w,
            //   height: h * 0.08,
            //   decoration: BoxDecoration(
            //     color: Colors.white,
            //     borderRadius: BorderRadius.circular(20),
            //     boxShadow: [
            //       BoxShadow(
            //         color: Colors.grey.shade200,
            //         spreadRadius: 1,
            //       ),
            //     ],
            //   ),
            //   child: ListTile(
            //     leading: const ImageIcon(
            //       AssetImage(alarmClock),
            //       color: black,
            //     ),
            //     title: const Text("Alarm"),
            //     trailing:
            //         const Icon(Icons.chevron_right, color: grayColor),
            //     onTap: () {
            //       const AlarmScreen().launch(context);
            //     },
            //   ),
            // ),
            // 10.height,
          ],
        ).paddingSymmetric(horizontal: 20),
      ),
    );
  }
}

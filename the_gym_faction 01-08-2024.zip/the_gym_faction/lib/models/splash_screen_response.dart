import 'dart:convert';

class SplashScreenResponse {
  bool? success;
  List<SplashScreenDatum>? data;
  String? message;

  SplashScreenResponse({
    this.success,
    this.data,
    this.message,
  });

  factory SplashScreenResponse.fromRawJson(String str) =>
      SplashScreenResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory SplashScreenResponse.fromJson(Map<String, dynamic> json) =>
      SplashScreenResponse(
        success: json["success"],
        data: json["data"] == null
            ? []
            : List<SplashScreenDatum>.from(
                json["data"]!.map((x) => SplashScreenDatum.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "message": message,
      };
}

class SplashScreenDatum {
  int? id;
  String? image;
  String? description;
  DateTime? createdAt;
  String? updatedAt;

  SplashScreenDatum({
    this.id,
    this.image,
    this.description,
    this.createdAt,
    this.updatedAt,
  });

  factory SplashScreenDatum.fromRawJson(String str) =>
      SplashScreenDatum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory SplashScreenDatum.fromJson(Map<String, dynamic> json) =>
      SplashScreenDatum(
        id: json["id"],
        image: json["image"],
        description: json["description"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "image": image,
        "description": description,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt,
      };
}

import 'dart:convert';

class DailyWorkoutModel {
  int? exerciseCount;
  int? completeExerciseCount;
  String? bodyPartName;
  String? image;
  String? workoutBackground;

  DailyWorkoutModel({
    this.exerciseCount,
    this.completeExerciseCount,
    this.bodyPartName,
    this.image,
    this.workoutBackground,
  });

  factory DailyWorkoutModel.fromRawJson(String str) =>
      DailyWorkoutModel.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory DailyWorkoutModel.fromJson(Map<String, dynamic> json) =>
      DailyWorkoutModel(
        exerciseCount: json["exerciseCount"],
        completeExerciseCount: json["completeExerciseCount"],
        bodyPartName: json["bodyPartName"],
        image: json["image"],
        workoutBackground: json["workout_background"],
      );

  Map<String, dynamic> toJson() => {
        "exerciseCount": exerciseCount,
        "completeExerciseCount": completeExerciseCount,
        "bodyPartName": bodyPartName,
        "image": image,
        "workout_background": workoutBackground,
      };
}

import 'dart:convert';
import 'dart:ui';

class DietListResponse {
  bool? success;
  Data? data;
  double? totalCalories;
  double? consumedCalories;
  double? totalCaloriesPercentage;
  double? consumedCaloriesPercentage;
  String? message;

  DietListResponse({
    this.success,
    this.data,
    this.totalCalories,
    this.consumedCalories,
    this.totalCaloriesPercentage,
    this.consumedCaloriesPercentage,
    this.message,
  });

  factory DietListResponse.fromRawJson(String str) =>
      DietListResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory DietListResponse.fromJson(Map<String, dynamic> json) =>
      DietListResponse(
        success: json["success"],
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
        totalCalories: json["total_calories"]?.toDouble(),
        consumedCalories: json["consumed_calories"]?.toDouble(),
        totalCaloriesPercentage: json["total_calories_percentage"]?.toDouble(),
        consumedCaloriesPercentage:
            json["consumed_calories_percentage"]?.toDouble(),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data?.toJson(),
        "total_calories": totalCalories,
        "consumed_calories": consumedCalories,
        "total_calories_percentage": totalCaloriesPercentage,
        "consumed_calories_percentage": consumedCaloriesPercentage,
        "message": message,
      };
}

class Data {
  List<Category>? categories;

  Data({
    this.categories,
  });

  factory Data.fromRawJson(String str) => Data.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        categories: json["categories"] == null
            ? []
            : List<Category>.from(
                json["categories"]!.map((x) => Category.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "categories": categories == null
            ? []
            : List<dynamic>.from(categories!.map((x) => x.toJson())),
      };
}

class Category {
  String? categoryName;
  List<DietListResponseDiet>? diets;

  Category({
    this.categoryName,
    this.diets,
  });

  factory Category.fromRawJson(String str) =>
      Category.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Category.fromJson(Map<String, dynamic> json) => Category(
        categoryName: json["category_name"],
        diets: json["diets"] == null
            ? []
            : List<DietListResponseDiet>.from(
                json["diets"]!.map((x) => DietListResponseDiet.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "category_name": categoryName,
        "diets": diets == null
            ? []
            : List<dynamic>.from(diets!.map((x) => x.toJson())),
      };
}

class DietListResponseDiet {
  int? id;
  String? title;
  int? categorydietId;
  int? foodCatId;
  String? image;
  String? calories;
  String? carbs;
  String? protein;
  String? fat;
  String? servings;
  String? allergyId;
  int? eatType;
  String? totalTime;
  String? isFeatured;
  String? status;
  String? ingredients;
  String? description;
  int? isPremium;
  int? sheetSrNo;
  String? originalCourse;
  String? sheetCuisine;
  String? sheetDiet;
  int? createdBy;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? consumed;
  double? caloriesForOne;

  DietListResponseDiet({
    this.id,
    this.title,
    this.categorydietId,
    this.foodCatId,
    this.image,
    this.calories,
    this.carbs,
    this.protein,
    this.fat,
    this.servings,
    this.allergyId,
    this.eatType,
    this.totalTime,
    this.isFeatured,
    this.status,
    this.ingredients,
    this.description,
    this.isPremium,
    this.sheetSrNo,
    this.originalCourse,
    this.sheetCuisine,
    this.sheetDiet,
    this.createdBy,
    this.createdAt,
    this.updatedAt,
    this.consumed,
    this.caloriesForOne,
  });

  factory DietListResponseDiet.fromRawJson(String str) =>
      DietListResponseDiet.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory DietListResponseDiet.fromJson(Map<String, dynamic> json) =>
      DietListResponseDiet(
        id: json["id"],
        title: json["title"],
        categorydietId: json["categorydiet_id"],
        foodCatId: json["food_cat_id"],
        image: json["image"],
        calories: json["calories"],
        carbs: json["carbs"],
        protein: json["protein"],
        fat: json["fat"],
        servings: json["servings"],
        allergyId: json["allergy_id"],
        eatType: json["eat_type"],
        totalTime: json["total_time"],
        isFeatured: json["is_featured"],
        status: json["status"],
        ingredients: json["ingredients"],
        description: json["description"],
        isPremium: json["is_premium"],
        sheetSrNo: json["sheet_sr_no"],
        originalCourse: json["original_course"],
        sheetCuisine: json["sheet_cuisine"],
        sheetDiet: json["sheet_diet"],
        createdBy: json["created_by"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        consumed: json["consumed"],
        caloriesForOne: json["calories_for_one"]?.toDouble(),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "categorydiet_id": categorydietId,
        "food_cat_id": foodCatId,
        "image": image,
        "calories": calories,
        "carbs": carbs,
        "protein": protein,
        "fat": fat,
        "servings": servings,
        "allergy_id": allergyId,
        "eat_type": eatType,
        "total_time": totalTime,
        "is_featured": isFeatured,
        "status": status,
        "ingredients": ingredients,
        "description": description,
        "is_premium": isPremium,
        "sheet_sr_no": sheetSrNo,
        "original_course": originalCourse,
        "sheet_cuisine": sheetCuisine,
        "sheet_diet": sheetDiet,
        "created_by": createdBy,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "consumed": consumed,
        "calories_for_one": caloriesForOne,
      };
}

class DoughnutChart {
  DoughnutChart(this.x, this.y, this.text, this.color);

  final String x;
  final double y;
  final String text;
  final Color? color;
}

import 'dart:convert';

class LoginUserData {
  bool? success;
  Data? data;
  String? message;
  String? token;

  LoginUserData({
    this.success,
    this.data,
    this.message,
    this.token,
  });

  factory LoginUserData.fromRawJson(String str) =>
      LoginUserData.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory LoginUserData.fromJson(Map<String, dynamic> json) => LoginUserData(
        success: json["success"],
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
        message: json["message"],
        token: json["token"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data?.toJson(),
        "message": message,
        "token": token,
      };
}

class Data {
  int? id;
  String? gymOwnerId;
  dynamic coachId;
  String? username;
  String? firstName;
  String? lastName;
  String? email;
  String? phoneNumber;
  String? profileImage;
  dynamic emailVerifiedAt;
  String? userType;
  String? workoutDays;
  dynamic dietryPreferance;
  String? password;
  String? status;
  dynamic inactiveReason;
  String? otp;
  dynamic loginType;
  String? gender;
  String? displayName;
  int? eatType;
  String? goal;
  String? foodCategory;
  String? allergy;
  int? dietStatus;
  dynamic playerId;
  int? isSubscribe;
  DateTime? lastNotificationSeen;
  String? deviceToken;
  DateTime? userCreateDate;
  int? createdBy;
  String? duration;
  DateTime? startDate;
  DateTime? endDate;
  String? deletedStatus;
  DateTime? createdAt;
  DateTime? updatedAt;
  dynamic deletedAt;
  String? age;
  String? weight;
  String? height;
  String? weightUnit;
  String? heightUnit;
  dynamic address;

  Data({
    this.id,
    this.gymOwnerId,
    this.coachId,
    this.username,
    this.firstName,
    this.lastName,
    this.email,
    this.phoneNumber,
    this.profileImage,
    this.emailVerifiedAt,
    this.userType,
    this.workoutDays,
    this.dietryPreferance,
    this.password,
    this.status,
    this.inactiveReason,
    this.otp,
    this.loginType,
    this.gender,
    this.displayName,
    this.eatType,
    this.goal,
    this.foodCategory,
    this.allergy,
    this.dietStatus,
    this.playerId,
    this.isSubscribe,
    this.lastNotificationSeen,
    this.deviceToken,
    this.userCreateDate,
    this.createdBy,
    this.duration,
    this.startDate,
    this.endDate,
    this.deletedStatus,
    this.createdAt,
    this.updatedAt,
    this.deletedAt,
    this.age,
    this.weight,
    this.height,
    this.weightUnit,
    this.heightUnit,
    this.address,
  });

  factory Data.fromRawJson(String str) => Data.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        id: json["id"],
        gymOwnerId: json["gym_owner_id"],
        coachId: json["coach_id"],
        username: json["username"],
        firstName: json["first_name"],
        lastName: json["last_name"],
        email: json["email"],
        phoneNumber: json["phone_number"],
        profileImage: json["profile_image"],
        emailVerifiedAt: json["email_verified_at"],
        userType: json["user_type"],
        workoutDays: json["workout_days"],
        dietryPreferance: json["dietry_preferance"],
        password: json["password"],
        status: json["status"],
        inactiveReason: json["inactive_reason"],
        otp: json["otp"],
        loginType: json["login_type"],
        gender: json["gender"],
        displayName: json["display_name"],
        eatType: json["eat_type"],
        goal: json["goal"],
        foodCategory: json["food_category"],
        allergy: json["allergy"],
        dietStatus: json["diet_status"],
        playerId: json["player_id"],
        isSubscribe: json["is_subscribe"],
        lastNotificationSeen: json["last_notification_seen"] == null
            ? null
            : DateTime.parse(json["last_notification_seen"]),
        deviceToken: json["device_token"],
        userCreateDate: json["user_create_date"] == null
            ? null
            : DateTime.parse(json["user_create_date"]),
        createdBy: json["created_by"],
        duration: json["duration"],
        startDate: json["start_date"] == null
            ? null
            : DateTime.parse(json["start_date"]),
        endDate:
            json["end_date"] == null ? null : DateTime.parse(json["end_date"]),
        deletedStatus: json["deleted_status"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        deletedAt: json["deleted_at"],
        age: json["age"],
        weight: json["weight"],
        height: json["height"],
        weightUnit: json["weight_unit"],
        heightUnit: json["height_unit"],
        address: json["address"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "gym_owner_id": gymOwnerId,
        "coach_id": coachId,
        "username": username,
        "first_name": firstName,
        "last_name": lastName,
        "email": email,
        "phone_number": phoneNumber,
        "profile_image": profileImage,
        "email_verified_at": emailVerifiedAt,
        "user_type": userType,
        "workout_days": workoutDays,
        "dietry_preferance": dietryPreferance,
        "password": password,
        "status": status,
        "inactive_reason": inactiveReason,
        "otp": otp,
        "login_type": loginType,
        "gender": gender,
        "display_name": displayName,
        "eat_type": eatType,
        "goal": goal,
        "food_category": foodCategory,
        "allergy": allergy,
        "diet_status": dietStatus,
        "player_id": playerId,
        "is_subscribe": isSubscribe,
        "last_notification_seen": lastNotificationSeen?.toIso8601String(),
        "device_token": deviceToken,
        "user_create_date":
            "${userCreateDate!.year.toString().padLeft(4, '0')}-${userCreateDate!.month.toString().padLeft(2, '0')}-${userCreateDate!.day.toString().padLeft(2, '0')}",
        "created_by": createdBy,
        "duration": duration,
        "start_date":
            "${startDate!.year.toString().padLeft(4, '0')}-${startDate!.month.toString().padLeft(2, '0')}-${startDate!.day.toString().padLeft(2, '0')}",
        "end_date":
            "${endDate!.year.toString().padLeft(4, '0')}-${endDate!.month.toString().padLeft(2, '0')}-${endDate!.day.toString().padLeft(2, '0')}",
        "deleted_status": deletedStatus,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "deleted_at": deletedAt,
        "age": age,
        "weight": weight,
        "height": height,
        "weight_unit": weightUnit,
        "height_unit": heightUnit,
        "address": address,
      };
}

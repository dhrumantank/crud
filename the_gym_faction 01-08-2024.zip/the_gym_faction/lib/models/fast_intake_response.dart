import 'dart:convert';

class FastIntakeResponse {
  bool? success;
  List<FastIntakeDatum>? data;
  String? message;

  FastIntakeResponse({
    this.success,
    this.data,
    this.message,
  });

  factory FastIntakeResponse.fromRawJson(String str) =>
      FastIntakeResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory FastIntakeResponse.fromJson(Map<String, dynamic> json) =>
      FastIntakeResponse(
        success: json["success"],
        data: json["data"] == null
            ? []
            : List<FastIntakeDatum>.from(
                json["data"]!.map((x) => FastIntakeDatum.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "message": message,
      };
}

class FastIntakeDatum {
  int? id;
  String? title;
  String? description;
  String? image;
  DateTime? createdAt;
  DateTime? updatedAt;
  String? startTime;
  String? endTime;
  int? totalTime;
  String? status;
  dynamic pendingTime;
  int? pendingTimeSeconds;

  FastIntakeDatum({
    this.id,
    this.title,
    this.description,
    this.image,
    this.createdAt,
    this.updatedAt,
    this.startTime,
    this.endTime,
    this.totalTime,
    this.status,
    this.pendingTime,
    this.pendingTimeSeconds,
  });

  factory FastIntakeDatum.fromRawJson(String str) =>
      FastIntakeDatum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory FastIntakeDatum.fromJson(Map<String, dynamic> json) =>
      FastIntakeDatum(
        id: json["id"],
        title: json["title"],
        description: json["description"],
        image: json["image"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        startTime: json["start_time"],
        endTime: json["end_time"],
        totalTime: json["total_time"],
        status: json["status"],
        pendingTime: json["pending_time"],
        pendingTimeSeconds: json["pending_time_seconds"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "description": description,
        "image": image,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "start_time": startTime,
        "end_time": endTime,
        "total_time": totalTime,
        "status": status,
        "pending_time": pendingTime,
        "pending_time_seconds": pendingTimeSeconds,
      };
}

class SalesOrderChart {
  SalesOrderChart(this.x, this.y);

  final String x;
  final double y;
}

//
//
//
//
//

class FastIntakeHistory {
  bool? success;
  List<FastIntakeHistoryDataDatum>? data;
  int? inProgressCount;
  int? completeCount;
  int? pendingCount;
  int? totalFastIntakes;
  String? message;

  FastIntakeHistory({
    this.success,
    this.data,
    this.inProgressCount,
    this.completeCount,
    this.pendingCount,
    this.totalFastIntakes,
    this.message,
  });

  factory FastIntakeHistory.fromRawJson(String str) =>
      FastIntakeHistory.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory FastIntakeHistory.fromJson(Map<String, dynamic> json) =>
      FastIntakeHistory(
        success: json["success"],
        data: json["data"] == null
            ? []
            : List<FastIntakeHistoryDataDatum>.from(json["data"]!
                .map((x) => FastIntakeHistoryDataDatum.fromJson(x))),
        inProgressCount: json["inProgressCount"],
        completeCount: json["completeCount"],
        pendingCount: json["pendingCount"],
        totalFastIntakes: json["totalFastIntakes"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "inProgressCount": inProgressCount,
        "completeCount": completeCount,
        "pendingCount": pendingCount,
        "totalFastIntakes": totalFastIntakes,
        "message": message,
      };
}

class FastIntakeHistoryDataDatum {
  int? id;
  String? gymOwnerId;
  String? userId;
  String? fastId;
  DateTime? startTime;
  DateTime? endTime;
  DateTime? date;
  String? status;
  DateTime? createdAt;
  DateTime? updatedAt;
  String? title;
  String? description;
  String? image;

  FastIntakeHistoryDataDatum({
    this.id,
    this.gymOwnerId,
    this.userId,
    this.fastId,
    this.startTime,
    this.endTime,
    this.date,
    this.status,
    this.createdAt,
    this.updatedAt,
    this.title,
    this.description,
    this.image,
  });

  factory FastIntakeHistoryDataDatum.fromRawJson(String str) =>
      FastIntakeHistoryDataDatum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory FastIntakeHistoryDataDatum.fromJson(Map<String, dynamic> json) =>
      FastIntakeHistoryDataDatum(
        id: json["id"],
        gymOwnerId: json["gym_owner_id"],
        userId: json["user_id"],
        fastId: json["fast_id"],
        startTime: json["start_time"] == null
            ? null
            : DateTime.parse(json["start_time"]),
        endTime:
            json["end_time"] == null ? null : DateTime.parse(json["end_time"]),
        date: json["date"] == null ? null : DateTime.parse(json["date"]),
        status: json["status"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        title: json["title"],
        description: json["description"],
        image: json["image"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "gym_owner_id": gymOwnerId,
        "user_id": userId,
        "fast_id": fastId,
        "start_time": startTime?.toIso8601String(),
        "end_time": endTime?.toIso8601String(),
        "date":
            "${date!.year.toString().padLeft(4, '0')}-${date!.month.toString().padLeft(2, '0')}-${date!.day.toString().padLeft(2, '0')}",
        "status": status,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "title": title,
        "description": description,
        "image": image,
      };
}

import 'dart:convert';

class GymOwnerList {
  bool? success;
  List<GymOwnerListDatum>? data;
  String? message;

  GymOwnerList({
    this.success,
    this.data,
    this.message,
  });

  factory GymOwnerList.fromRawJson(String str) =>
      GymOwnerList.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory GymOwnerList.fromJson(Map<String, dynamic> json) => GymOwnerList(
        success: json["success"],
        data: json["data"] == null
            ? []
            : List<GymOwnerListDatum>.from(
                json["data"]!.map((x) => GymOwnerListDatum.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "message": message,
      };
}

class GymOwnerListDatum {
  int? id;
  String? gymName;
  String? ownerName;
  String? phoneNumber;
  String? logo;
  String? email;
  String? address;
  int? status;
  DateTime? createdAt;
  DateTime? updatedAt;

  GymOwnerListDatum({
    this.id,
    this.gymName,
    this.ownerName,
    this.phoneNumber,
    this.logo,
    this.email,
    this.address,
    this.status,
    this.createdAt,
    this.updatedAt,
  });

  factory GymOwnerListDatum.fromRawJson(String str) =>
      GymOwnerListDatum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory GymOwnerListDatum.fromJson(Map<String, dynamic> json) =>
      GymOwnerListDatum(
        id: json["id"],
        gymName: json["gym_name"],
        ownerName: json["owner_name"],
        phoneNumber: json["phone_number"],
        logo: json["logo"],
        email: json["email"],
        address: json["address"],
        status: json["status"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "gym_name": gymName,
        "owner_name": ownerName,
        "phone_number": phoneNumber,
        "logo": logo,
        "email": email,
        "address": address,
        "status": status,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
      };
}

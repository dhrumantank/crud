import 'dart:convert';

class UserAppVersionCheckResponse {
  bool? success;
  Data? data;
  String? message;

  UserAppVersionCheckResponse({
    this.success,
    this.data,
    this.message,
  });

  factory UserAppVersionCheckResponse.fromRawJson(String str) =>
      UserAppVersionCheckResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory UserAppVersionCheckResponse.fromJson(Map<String, dynamic> json) =>
      UserAppVersionCheckResponse(
        success: json["success"],
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data?.toJson(),
        "message": message,
      };
}

class Data {
  String? androidVersion;
  String? iosVersion;
  String? androidLink;
  String? iosLink;

  Data({
    this.androidVersion,
    this.iosVersion,
    this.androidLink,
    this.iosLink,
  });

  factory Data.fromRawJson(String str) => Data.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        androidVersion: json["android_version"],
        iosVersion: json["ios_version"],
        androidLink: json["android_link"],
        iosLink: json["ios_link"],
      );

  Map<String, dynamic> toJson() => {
        "android_version": androidVersion,
        "ios_version": iosVersion,
        "android_link": androidLink,
        "ios_link": iosLink,
      };
}

class QuestionAnswerModel {
  String? question;
  StringBuffer? answer;
  bool? isLoading;
  String? smartCompose;

  QuestionAnswerModel({
    this.question,
    this.answer,
    this.isLoading,
    this.smartCompose,
  });
}

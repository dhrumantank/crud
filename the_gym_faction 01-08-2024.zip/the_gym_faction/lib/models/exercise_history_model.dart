import 'dart:convert';

class ExerciseHistoryResponse {
  bool? success;
  List<ExerciseHistoryDatum>? data;
  String? message;
  Pagination? pagination;

  ExerciseHistoryResponse({
    this.success,
    this.data,
    this.message,
    this.pagination,
  });

  factory ExerciseHistoryResponse.fromRawJson(String str) =>
      ExerciseHistoryResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory ExerciseHistoryResponse.fromJson(Map<String, dynamic> json) =>
      ExerciseHistoryResponse(
        success: json["success"],
        data: json["data"] == null
            ? []
            : List<ExerciseHistoryDatum>.from(
                json["data"]!.map((x) => ExerciseHistoryDatum.fromJson(x))),
        message: json["message"],
        pagination: json["pagination"] == null
            ? null
            : Pagination.fromJson(json["pagination"]),
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "message": message,
        "pagination": pagination?.toJson(),
      };
}

class ExerciseHistoryDatum {
  DateTime? date;
  List<Workout>? workouts;

  ExerciseHistoryDatum({
    this.date,
    this.workouts,
  });

  factory ExerciseHistoryDatum.fromRawJson(String str) =>
      ExerciseHistoryDatum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory ExerciseHistoryDatum.fromJson(Map<String, dynamic> json) =>
      ExerciseHistoryDatum(
        date: json["date"] == null ? null : DateTime.parse(json["date"]),
        workouts: json["workouts"] == null
            ? []
            : List<Workout>.from(
                json["workouts"]!.map((x) => Workout.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "date":
            "${date!.year.toString().padLeft(4, '0')}-${date!.month.toString().padLeft(2, '0')}-${date!.day.toString().padLeft(2, '0')}",
        "workouts": workouts == null
            ? []
            : List<dynamic>.from(workouts!.map((x) => x.toJson())),
      };
}

class Workout {
  String? bodyPartTitle;
  List<Exercise>? exercises;

  Workout({
    this.bodyPartTitle,
    this.exercises,
  });

  factory Workout.fromRawJson(String str) => Workout.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Workout.fromJson(Map<String, dynamic> json) => Workout(
        bodyPartTitle: json["body_part_title"],
        exercises: json["exercises"] == null
            ? []
            : List<Exercise>.from(
                json["exercises"]!.map((x) => Exercise.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "body_part_title": bodyPartTitle,
        "exercises": exercises == null
            ? []
            : List<dynamic>.from(exercises!.map((x) => x.toJson())),
      };
}

class Exercise {
  int? id;
  String? title;
  String? instruction;
  String? tips;
  String? exerciseImage;
  dynamic videoType;
  String? videoUrl;
  int? bodyPartIds;
  List<HistoryDuration>? duration;
  dynamic based;
  dynamic type;
  int? equipmentId;
  int? levelId;
  List<Set>? sets;
  dynamic status;
  int? selectedExercise;
  int? createdBy;
  int? isPremium;
  DateTime? createdAt;
  DateTime? updatedAt;

  Exercise({
    this.id,
    this.title,
    this.instruction,
    this.tips,
    this.exerciseImage,
    this.videoType,
    this.videoUrl,
    this.bodyPartIds,
    this.duration,
    this.based,
    this.type,
    this.equipmentId,
    this.levelId,
    this.sets,
    this.status,
    this.selectedExercise,
    this.createdBy,
    this.isPremium,
    this.createdAt,
    this.updatedAt,
  });

  factory Exercise.fromRawJson(String str) =>
      Exercise.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Exercise.fromJson(Map<String, dynamic> json) => Exercise(
        id: json["id"],
        title: json["title"],
        instruction: json["instruction"],
        tips: json["tips"],
        exerciseImage: json["exercise_image"],
        videoType: json["video_type"],
        videoUrl: json["video_url"],
        bodyPartIds: json["bodypart_ids"],
        duration: json["duration"] == null
            ? []
            : List<HistoryDuration>.from(
                json["duration"]!.map(
                  (x) => HistoryDuration.fromJson(x),
                ),
              ),
        based: json["based"],
        type: json["type"],
        equipmentId: json["equipment_id"],
        levelId: json["level_id"],
        sets: json["sets"] == null
            ? []
            : List<Set>.from(json["sets"]!.map((x) => Set.fromJson(x))),
        status: json["status"],
        selectedExercise: json["selected_exercise"],
        createdBy: json["created_by"],
        isPremium: json["is_premium"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "instruction": instruction,
        "tips": tips,
        "exercise_image": exerciseImage,
        "video_type": videoType,
        "video_url": videoUrl,
        "bodypart_ids": bodyPartIds,
        "duration": duration == null
            ? []
            : List<dynamic>.from(duration!.map((x) => x.toJson())),
        "based": based,
        "type": type,
        "equipment_id": equipmentId,
        "level_id": levelId,
        "sets": sets == null
            ? []
            : List<dynamic>.from(sets!.map((x) => x.toJson())),
        "status": status,
        "selected_exercise": selectedExercise,
        "created_by": createdBy,
        "is_premium": isPremium,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
      };
}

class Set {
  String? reps;
  String? rest;
  String? time;
  String? weight;

  Set({
    this.reps,
    this.rest,
    this.time,
    this.weight,
  });

  factory Set.fromRawJson(String str) => Set.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Set.fromJson(Map<String, dynamic> json) => Set(
        reps: json["reps"],
        rest: json["rest"],
        time: json["time"],
        weight: json["weight"],
      );

  Map<String, dynamic> toJson() => {
        "reps": reps,
        "rest": rest,
        "time": time,
        "weight": weight,
      };
}

class HistoryDuration {
  String? duration;
  String? type;

  HistoryDuration({
    this.duration,
    this.type,
  });

  factory HistoryDuration.fromRawJson(String str) =>
      HistoryDuration.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory HistoryDuration.fromJson(Map<String, dynamic> json) =>
      HistoryDuration(
        duration: json["duration"],
        type: json["type"],
      );

  Map<String, dynamic> toJson() => {
        "duration": duration,
        "type": type,
      };
}

class Pagination {
  int? currentPage;
  int? totalPages;
  int? totalItems;
  int? perPage;
  String? nextPageUrl;
  dynamic prevPageUrl;

  Pagination({
    this.currentPage,
    this.totalPages,
    this.totalItems,
    this.perPage,
    this.nextPageUrl,
    this.prevPageUrl,
  });

  factory Pagination.fromRawJson(String str) =>
      Pagination.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Pagination.fromJson(Map<String, dynamic> json) => Pagination(
        currentPage: json["current_page"],
        totalPages: json["total_pages"],
        totalItems: json["total_items"],
        perPage: json["per_page"],
        nextPageUrl: json["next_page_url"],
        prevPageUrl: json["prev_page_url"],
      );

  Map<String, dynamic> toJson() => {
        "current_page": currentPage,
        "total_pages": totalPages,
        "total_items": totalItems,
        "per_page": perPage,
        "next_page_url": nextPageUrl,
        "prev_page_url": prevPageUrl,
      };
}

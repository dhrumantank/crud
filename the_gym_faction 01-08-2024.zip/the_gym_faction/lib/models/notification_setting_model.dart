import 'dart:convert';

class NotificationSettingResponse {
  bool? status;
  List<NotificationResponseDatum>? data;
  String? message;

  NotificationSettingResponse({
    this.status,
    this.data,
    this.message,
  });

  factory NotificationSettingResponse.fromRawJson(String str) =>
      NotificationSettingResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory NotificationSettingResponse.fromJson(Map<String, dynamic> json) =>
      NotificationSettingResponse(
        status: json["status"],
        data: json["data"] == null
            ? []
            : List<NotificationResponseDatum>.from(json["data"]!
                .map((x) => NotificationResponseDatum.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "message": message,
      };
}

class NotificationResponseDatum {
  int? id;
  String? title;
  String? reminderTitle;
  String? notificationTitle;
  String? notificationBody;
  dynamic variables;
  DateTime? createdAt;
  DateTime? updatedAt;
  String? status;

  NotificationResponseDatum({
    this.id,
    this.title,
    this.reminderTitle,
    this.notificationTitle,
    this.notificationBody,
    this.variables,
    this.createdAt,
    this.updatedAt,
    this.status,
  });

  factory NotificationResponseDatum.fromRawJson(String str) =>
      NotificationResponseDatum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory NotificationResponseDatum.fromJson(Map<String, dynamic> json) =>
      NotificationResponseDatum(
        id: json["id"],
        title: json["title"],
        reminderTitle: json["reminder_title"],
        notificationTitle: json["notification_title"],
        notificationBody: json["notification_body"],
        variables: json["variables"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        status: json["status"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "reminder_title": reminderTitle,
        "notification_title": notificationTitle,
        "notification_body": notificationBody,
        "variables": variables,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "status": status,
      };
}

import 'dart:convert';

class UserAccountBlockedCheckResponse {
  bool? success;
  List<Datum>? data;
  String? message;

  UserAccountBlockedCheckResponse({
    this.success,
    this.data,
    this.message,
  });

  factory UserAccountBlockedCheckResponse.fromRawJson(String str) =>
      UserAccountBlockedCheckResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory UserAccountBlockedCheckResponse.fromJson(Map<String, dynamic> json) =>
      UserAccountBlockedCheckResponse(
        success: json["success"],
        data: json["data"] == null
            ? []
            : List<Datum>.from(json["data"]!.map((x) => Datum.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "message": message,
      };
}

class Datum {
  int? id;
  String? type;
  String? reason;
  String? contect;
  DateTime? createdAt;
  DateTime? updatedAt;

  Datum({
    this.id,
    this.type,
    this.reason,
    this.contect,
    this.createdAt,
    this.updatedAt,
  });

  factory Datum.fromRawJson(String str) => Datum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        id: json["id"],
        type: json["type"],
        reason: json["reason"],
        contect: json["contect"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "type": type,
        "reason": reason,
        "contect": contect,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
      };
}

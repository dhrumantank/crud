import 'dart:convert';

class WorkoutDaysHistory {
  bool? success;
  String? status;
  List<WorkoutDaysHistoryDatum>? data;
  String? message;

  WorkoutDaysHistory({
    this.success,
    this.status,
    this.data,
    this.message,
  });

  factory WorkoutDaysHistory.fromRawJson(String str) =>
      WorkoutDaysHistory.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory WorkoutDaysHistory.fromJson(Map<String, dynamic> json) =>
      WorkoutDaysHistory(
        success: json["success"],
        status: json["status"],
        data: json["data"] == null
            ? []
            : List<WorkoutDaysHistoryDatum>.from(
                json["data"]!.map((x) => WorkoutDaysHistoryDatum.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "status": status,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "message": message,
      };
}

class WorkoutDaysHistoryDatum {
  int? id;
  String? title;
  String? instruction;
  String? tips;
  String? exerciseImage;
  String? videoType;
  String? videoUrl;
  int? bodypartIds;
  List<WorkoutDayDuration>? duration;
  String? based;
  String? type;
  int? equipmentId;
  int? levelId;
  List<Set>? sets;
  String? status;
  int? createdBy;
  int? isPremium;
  DateTime? createdAt;
  DateTime? updatedAt;
  String? workoutStatus;

  WorkoutDaysHistoryDatum({
    this.id,
    this.title,
    this.instruction,
    this.tips,
    this.exerciseImage,
    this.videoType,
    this.videoUrl,
    this.bodypartIds,
    this.duration,
    this.based,
    this.type,
    this.equipmentId,
    this.levelId,
    this.sets,
    this.status,
    this.createdBy,
    this.isPremium,
    this.createdAt,
    this.updatedAt,
    this.workoutStatus,
  });

  factory WorkoutDaysHistoryDatum.fromRawJson(String str) =>
      WorkoutDaysHistoryDatum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory WorkoutDaysHistoryDatum.fromJson(Map<String, dynamic> json) =>
      WorkoutDaysHistoryDatum(
        id: json["id"],
        title: json["title"],
        instruction: json["instruction"],
        tips: json["tips"],
        exerciseImage: json["exercise_image"],
        videoType: json["video_type"],
        videoUrl: json["video_url"],
        bodypartIds: json["bodypart_ids"],
        duration: json["duration"] == null
            ? []
            : List<WorkoutDayDuration>.from(
                json["duration"]!.map((x) => WorkoutDayDuration.fromJson(x))),
        based: json["based"],
        type: json["type"],
        equipmentId: json["equipment_id"],
        levelId: json["level_id"],
        sets: json["sets"] == null
            ? []
            : List<Set>.from(json["sets"]!.map((x) => Set.fromJson(x))),
        status: json["status"],
        createdBy: json["created_by"],
        isPremium: json["is_premium"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        workoutStatus: json["workout_status"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "instruction": instruction,
        "tips": tips,
        "exercise_image": exerciseImage,
        "video_type": videoType,
        "video_url": videoUrl,
        "bodypart_ids": bodypartIds,
        "duration": duration == null
            ? []
            : List<dynamic>.from(duration!.map((e) => e.toJson())),
        "based": based,
        "type": type,
        "equipment_id": equipmentId,
        "level_id": levelId,
        "sets": sets == null
            ? []
            : List<dynamic>.from(sets!.map((x) => x.toJson())),
        "status": status,
        "created_by": createdBy,
        "is_premium": isPremium,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "workout_status": workoutStatus,
      };
}

class Set {
  String? reps;
  String? rest;
  String? time;
  String? weight;
  String? type;

  Set({
    this.reps,
    this.rest,
    this.time,
    this.weight,
    this.type,
  });

  factory Set.fromRawJson(String str) => Set.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Set.fromJson(Map<String, dynamic> json) => Set(
        reps: json["reps"],
        rest: json["rest"],
        time: json["time"],
        weight: json["weight"],
        type: json["type"],
      );

  Map<String, dynamic> toJson() => {
        "reps": reps,
        "rest": rest,
        "time": time,
        "weight": weight,
        "type": type,
      };
}

class WorkoutDayDuration {
  String? duration;
  String? type;

  WorkoutDayDuration({
    this.duration,
    this.type,
  });

  factory WorkoutDayDuration.fromRawJson(String str) =>
      WorkoutDayDuration.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory WorkoutDayDuration.fromJson(Map<String, dynamic> json) =>
      WorkoutDayDuration(
        duration: json["duration"],
        type: json["type"],
      );

  Map<String, dynamic> toJson() => {
        "duration": duration,
        "type": type,
      };
}

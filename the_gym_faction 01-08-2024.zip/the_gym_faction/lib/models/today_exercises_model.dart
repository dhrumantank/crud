import 'dart:convert';

class TodayExercises {
  bool? success;
  String? status;
  List<TodayExercisesDatum>? data;
  String? message;

  TodayExercises({
    this.success,
    this.status,
    this.data,
    this.message,
  });

  factory TodayExercises.fromRawJson(String str) =>
      TodayExercises.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory TodayExercises.fromJson(Map<String, dynamic> json) => TodayExercises(
        success: json["success"],
        status: json["status"],
        data: json["data"] == null
            ? []
            : List<TodayExercisesDatum>.from(
                json["data"]!.map((x) => TodayExercisesDatum.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "status": status,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "message": message,
      };
}

class TodayExercisesDatum {
  int? id;
  String? title;
  String? instruction;
  String? tips;
  String? exerciseImage;
  String? videoType;
  dynamic videoUrl;
  int? bodypartIds;
  List<TodayExercisesDuration>? duration;
  String? based;
  String? type;
  int? equipmentId;
  int? levelId;
  List<TodayExercisesSet>? sets;
  String? status;
  int? selectedExercise;
  int? createdBy;
  int? isPremium;
  DateTime? createdAt;
  DateTime? updatedAt;
  String? workoutStatus;

  TodayExercisesDatum({
    this.id,
    this.title,
    this.instruction,
    this.tips,
    this.exerciseImage,
    this.videoType,
    this.videoUrl,
    this.bodypartIds,
    this.duration,
    this.based,
    this.type,
    this.equipmentId,
    this.levelId,
    this.sets,
    this.status,
    this.selectedExercise,
    this.createdBy,
    this.isPremium,
    this.createdAt,
    this.updatedAt,
    this.workoutStatus,
  });

  factory TodayExercisesDatum.fromRawJson(String str) =>
      TodayExercisesDatum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory TodayExercisesDatum.fromJson(Map<String, dynamic> json) =>
      TodayExercisesDatum(
        id: json["id"],
        title: json["title"],
        instruction: json["instruction"],
        tips: json["tips"],
        exerciseImage: json["exercise_image"],
        videoType: json["video_type"],
        videoUrl: json["video_url"],
        bodypartIds: json["bodypart_ids"],
        duration: json["duration"] == null
            ? []
            : List<TodayExercisesDuration>.from(json["duration"]!
                .map((x) => TodayExercisesDuration.fromJson(x))),
        based: json["based"],
        type: json["type"],
        equipmentId: json["equipment_id"],
        levelId: json["level_id"],
        sets: json["sets"] == null
            ? []
            : List<TodayExercisesSet>.from(
                json["sets"]!.map((x) => TodayExercisesSet.fromJson(x))),
        status: json["status"],
        selectedExercise: json["selected_exercise"],
        createdBy: json["created_by"],
        isPremium: json["is_premium"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        workoutStatus: json["workout_status"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "instruction": instruction,
        "tips": tips,
        "exercise_image": exerciseImage,
        "video_type": videoType,
        "video_url": videoUrl,
        "bodypart_ids": bodypartIds,
        "duration": duration == null
            ? []
            : List<dynamic>.from(duration!.map((x) => x.toJson())),
        "based": based,
        "type": type,
        "equipment_id": equipmentId,
        "level_id": levelId,
        "sets": sets == null
            ? []
            : List<dynamic>.from(sets!.map((x) => x.toJson())),
        "status": status,
        "selected_exercise": selectedExercise,
        "created_by": createdBy,
        "is_premium": isPremium,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "workout_status": workoutStatus,
      };
}

class TodayExercisesSet {
  String? reps;
  String? rest;
  String? time;
  String? weight;
  String? type;

  TodayExercisesSet({
    this.reps,
    this.rest,
    this.time,
    this.weight,
    this.type,
  });

  factory TodayExercisesSet.fromRawJson(String str) =>
      TodayExercisesSet.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory TodayExercisesSet.fromJson(Map<String, dynamic> json) =>
      TodayExercisesSet(
        reps: json["reps"],
        rest: json["rest"],
        time: json["time"],
        weight: json["weight"],
        type: json["type"],
      );

  Map<String, dynamic> toJson() => {
        "reps": reps,
        "rest": rest,
        "time": time,
        "weight": weight,
        "type": type,
      };
}

class TodayExercisesDuration {
  String? duration;
  String? type;

  TodayExercisesDuration({
    this.duration,
    this.type,
  });

  factory TodayExercisesDuration.fromRawJson(String str) =>
      TodayExercisesDuration.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory TodayExercisesDuration.fromJson(Map<String, dynamic> json) =>
      TodayExercisesDuration(
        duration: json["duration"],
        type: json["type"],
      );

  Map<String, dynamic> toJson() => {
        "duration": duration,
        "type": type,
      };
}

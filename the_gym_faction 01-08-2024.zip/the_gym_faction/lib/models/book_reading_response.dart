import 'dart:convert';

class BookReadingResponse {
  bool? success;
  List<BookReadingDatum>? data;
  String? message;

  BookReadingResponse({
    this.success,
    this.data,
    this.message,
  });

  factory BookReadingResponse.fromRawJson(String str) =>
      BookReadingResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory BookReadingResponse.fromJson(Map<String, dynamic> json) =>
      BookReadingResponse(
        success: json["success"],
        data: json["data"] == null
            ? []
            : List<BookReadingDatum>.from(
                json["data"]!.map((x) => BookReadingDatum.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "message": message,
      };
}

class BookReadingDatum {
  int? id;
  int? userId;
  int? gymOwnerId;
  String? bookName;
  DateTime? date;
  String? author;
  DateTime? createdAt;
  DateTime? updatedAt;

  BookReadingDatum({
    this.id,
    this.userId,
    this.gymOwnerId,
    this.bookName,
    this.date,
    this.author,
    this.createdAt,
    this.updatedAt,
  });

  factory BookReadingDatum.fromRawJson(String str) =>
      BookReadingDatum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory BookReadingDatum.fromJson(Map<String, dynamic> json) =>
      BookReadingDatum(
        id: json["id"],
        userId: json["user_id"],
        gymOwnerId: json["gym_owner_id"],
        bookName: json["book_name"],
        date: json["date"] == null ? null : DateTime.parse(json["date"]),
        author: json["author"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_id": userId,
        "gym_owner_id": gymOwnerId,
        "book_name": bookName,
        "date":
            "${date!.year.toString().padLeft(4, '0')}-${date!.month.toString().padLeft(2, '0')}-${date!.day.toString().padLeft(2, '0')}",
        "author": author,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
      };
}

//
//
//
//
//
//
//
//

class BookHistoryResponse {
  bool? success;
  List<BookHistoryDatum>? data;
  String? message;

  BookHistoryResponse({
    this.success,
    this.data,
    this.message,
  });

  factory BookHistoryResponse.fromRawJson(String str) =>
      BookHistoryResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory BookHistoryResponse.fromJson(Map<String, dynamic> json) =>
      BookHistoryResponse(
        success: json["success"],
        data: json["data"] == null
            ? []
            : List<BookHistoryDatum>.from(
                json["data"]!.map((x) => BookHistoryDatum.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "message": message,
      };
}

class BookHistoryDatum {
  int? id;
  String? gymOwnerId;
  String? userId;
  int? bookId;
  String? image;
  String? learn;
  String? pages;
  DateTime? date;
  DateTime? createdAt;
  DateTime? updatedAt;
  dynamic title;

  BookHistoryDatum({
    this.id,
    this.gymOwnerId,
    this.userId,
    this.bookId,
    this.image,
    this.learn,
    this.pages,
    this.date,
    this.createdAt,
    this.updatedAt,
    this.title,
  });

  factory BookHistoryDatum.fromRawJson(String str) =>
      BookHistoryDatum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory BookHistoryDatum.fromJson(Map<String, dynamic> json) =>
      BookHistoryDatum(
        id: json["id"],
        gymOwnerId: json["gym_owner_id"],
        userId: json["user_id"],
        bookId: json["book_id"],
        image: json["image"],
        learn: json["learn"],
        pages: json["pages"],
        date: json["date"] == null ? null : DateTime.parse(json["date"]),
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        title: json["title"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "gym_owner_id": gymOwnerId,
        "user_id": userId,
        "book_id": bookId,
        "image": image,
        "learn": learn,
        "pages": pages,
        "date":
            "${date!.year.toString().padLeft(4, '0')}-${date!.month.toString().padLeft(2, '0')}-${date!.day.toString().padLeft(2, '0')}",
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "title": title,
      };
}

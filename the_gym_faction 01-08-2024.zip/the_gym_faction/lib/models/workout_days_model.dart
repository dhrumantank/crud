import 'dart:convert';

class WorkoutDays {
  int? id;
  String? title;
  String? image;
  String? day;
  String? status;
  DateTime? todayDate;

  WorkoutDays({
    this.id,
    this.title,
    this.image,
    this.day,
    this.status,
    this.todayDate,
  });

  factory WorkoutDays.fromRawJson(String str) =>
      WorkoutDays.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory WorkoutDays.fromJson(Map<String, dynamic> json) => WorkoutDays(
        id: json["id"],
        title: json["title"],
        image: json["image"],
        day: json["day"],
        status: json["status"],
        todayDate: json["today_date"] == null
            ? null
            : DateTime.parse(json["today_date"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "image": image,
        "day": day,
        "status": status,
        "today_date":
            "${todayDate!.year.toString().padLeft(4, '0')}-${todayDate!.month.toString().padLeft(2, '0')}-${todayDate!.day.toString().padLeft(2, '0')}",
      };
}

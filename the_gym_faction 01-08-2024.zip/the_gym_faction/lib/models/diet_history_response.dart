import 'dart:convert';

class DietHistoryResponse {
  bool? success;
  List<DietHistoryDatum>? data;
  String? message;
  Pagination? pagination;

  DietHistoryResponse({
    this.success,
    this.data,
    this.message,
    this.pagination,
  });

  factory DietHistoryResponse.fromRawJson(String str) =>
      DietHistoryResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory DietHistoryResponse.fromJson(Map<String, dynamic> json) =>
      DietHistoryResponse(
        success: json["success"],
        data: json["data"] == null
            ? []
            : List<DietHistoryDatum>.from(
                json["data"]!.map((x) => DietHistoryDatum.fromJson(x))),
        message: json["message"],
        pagination: json["pagination"] == null
            ? null
            : Pagination.fromJson(json["pagination"]),
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "message": message,
        "pagination": pagination?.toJson(),
      };
}

class DietHistoryDatum {
  DateTime? date;
  List<Diet>? diets;

  DietHistoryDatum({
    this.date,
    this.diets,
  });

  factory DietHistoryDatum.fromRawJson(String str) =>
      DietHistoryDatum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory DietHistoryDatum.fromJson(Map<String, dynamic> json) =>
      DietHistoryDatum(
        date: json["date"] == null ? null : DateTime.parse(json["date"]),
        diets: json["diets"] == null
            ? []
            : List<Diet>.from(json["diets"]!.map((x) => Diet.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "date":
            "${date!.year.toString().padLeft(4, '0')}-${date!.month.toString().padLeft(2, '0')}-${date!.day.toString().padLeft(2, '0')}",
        "diets": diets == null
            ? []
            : List<dynamic>.from(diets!.map((x) => x.toJson())),
      };
}

class Diet {
  int? id;
  String? title;
  int? categorydietId;
  int? foodCatId;
  String? image;
  String? calories;
  String? carbs;
  String? protein;
  String? fat;
  String? servings;
  String? allergyId;
  int? eatType;
  String? totalTime;
  dynamic isFeatured;
  dynamic status;
  String? ingredients;
  String? description;
  int? isPremium;
  int? sheetSrNo;
  String? originalCourse;
  String? sheetCuisine;
  String? sheetDiet;
  int? createdBy;
  DateTime? createdAt;
  DateTime? updatedAt;
  int? consumed;

  Diet({
    this.id,
    this.title,
    this.categorydietId,
    this.foodCatId,
    this.image,
    this.calories,
    this.carbs,
    this.protein,
    this.fat,
    this.servings,
    this.allergyId,
    this.eatType,
    this.totalTime,
    this.isFeatured,
    this.status,
    this.ingredients,
    this.description,
    this.isPremium,
    this.sheetSrNo,
    this.originalCourse,
    this.sheetCuisine,
    this.sheetDiet,
    this.createdBy,
    this.createdAt,
    this.updatedAt,
    this.consumed,
  });

  factory Diet.fromRawJson(String str) => Diet.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Diet.fromJson(Map<String, dynamic> json) => Diet(
        id: json["id"],
        title: json["title"],
        categorydietId: json["categorydiet_id"],
        foodCatId: json["food_cat_id"],
        image: json["image"],
        calories: json["calories"],
        carbs: json["carbs"],
        protein: json["protein"],
        fat: json["fat"],
        servings: json["servings"],
        allergyId: json["allergy_id"],
        eatType: json["eat_type"],
        totalTime: json["total_time"],
        isFeatured: json["is_featured"],
        status: json["status"],
        ingredients: json["ingredients"],
        description: json["description"],
        isPremium: json["is_premium"],
        sheetSrNo: json["sheet_sr_no"],
        originalCourse: json["original_course"],
        sheetCuisine: json["sheet_cuisine"],
        sheetDiet: json["sheet_diet"],
        createdBy: json["created_by"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        consumed: json["consumed"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "categorydiet_id": categorydietId,
        "food_cat_id": foodCatId,
        "image": image,
        "calories": calories,
        "carbs": carbs,
        "protein": protein,
        "fat": fat,
        "servings": servings,
        "allergy_id": allergyId,
        "eat_type": eatType,
        "total_time": totalTime,
        "is_featured": isFeatured,
        "status": status,
        "ingredients": ingredients,
        "description": description,
        "is_premium": isPremium,
        "sheet_sr_no": sheetSrNo,
        "original_course": originalCourse,
        "sheet_cuisine": sheetCuisine,
        "sheet_diet": sheetDiet,
        "created_by": createdBy,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "consumed": consumed,
      };
}

class Pagination {
  int? currentPage;
  int? totalPages;
  int? totalItems;
  int? perPage;
  String? nextPageUrl;
  dynamic prevPageUrl;

  Pagination({
    this.currentPage,
    this.totalPages,
    this.totalItems,
    this.perPage,
    this.nextPageUrl,
    this.prevPageUrl,
  });

  factory Pagination.fromRawJson(String str) =>
      Pagination.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Pagination.fromJson(Map<String, dynamic> json) => Pagination(
        currentPage: json["current_page"],
        totalPages: json["total_pages"],
        totalItems: json["total_items"],
        perPage: json["per_page"],
        nextPageUrl: json["next_page_url"],
        prevPageUrl: json["prev_page_url"],
      );

  Map<String, dynamic> toJson() => {
        "current_page": currentPage,
        "total_pages": totalPages,
        "total_items": totalItems,
        "per_page": perPage,
        "next_page_url": nextPageUrl,
        "prev_page_url": prevPageUrl,
      };
}

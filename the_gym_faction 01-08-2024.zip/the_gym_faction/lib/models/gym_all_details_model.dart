import 'dart:convert';

class GymAllDetails {
  bool? success;
  GymDetails? gymDetails;
  List<Coach>? coach;
  List<Review>? review;
  String? message;

  GymAllDetails({
    this.success,
    this.gymDetails,
    this.coach,
    this.review,
    this.message,
  });

  factory GymAllDetails.fromRawJson(String str) =>
      GymAllDetails.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory GymAllDetails.fromJson(Map<String, dynamic> json) => GymAllDetails(
        success: json["success"],
        gymDetails: json["gym_details"] == null
            ? null
            : GymDetails.fromJson(json["gym_details"]),
        coach: json["coach"] == null
            ? []
            : List<Coach>.from(json["coach"]!.map((x) => Coach.fromJson(x))),
        review: json["review"] == null
            ? []
            : List<Review>.from(json["review"]!.map((x) => Review.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "gym_details": gymDetails?.toJson(),
        "coach": coach == null
            ? []
            : List<dynamic>.from(coach!.map((x) => x.toJson())),
        "review": review == null
            ? []
            : List<dynamic>.from(review!.map((x) => x.toJson())),
        "message": message,
      };
}

class Coach {
  int? id;
  int? gymOwnerId;
  String? name;
  String? image;
  String? email;
  String? phoneNumber;
  int? status;
  String? coachAbout;
  int? createdBy;
  DateTime? createdAt;
  DateTime? updatedAt;

  Coach({
    this.id,
    this.gymOwnerId,
    this.name,
    this.image,
    this.email,
    this.phoneNumber,
    this.status,
    this.coachAbout,
    this.createdBy,
    this.createdAt,
    this.updatedAt,
  });

  factory Coach.fromRawJson(String str) => Coach.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Coach.fromJson(Map<String, dynamic> json) => Coach(
        id: json["id"],
        gymOwnerId: json["gym_owner_id"],
        name: json["name"],
        image: json["image"],
        email: json["email"],
        phoneNumber: json["phone_number"],
        status: json["status"],
        coachAbout: json["coach_about"],
        createdBy: json["created_by"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "gym_owner_id": gymOwnerId,
        "name": name,
        "image": image,
        "email": email,
        "phone_number": phoneNumber,
        "status": status,
        "coach_about": coachAbout,
        "created_by": createdBy,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
      };
}

class GymDetails {
  int? id;
  String? gymName;
  String? ownerName;
  String? phoneNumber;
  String? logo;
  String? email;
  String? address;
  int? status;
  DateTime? createdAt;
  DateTime? updatedAt;

  GymDetails({
    this.id,
    this.gymName,
    this.ownerName,
    this.phoneNumber,
    this.logo,
    this.email,
    this.address,
    this.status,
    this.createdAt,
    this.updatedAt,
  });

  factory GymDetails.fromRawJson(String str) =>
      GymDetails.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory GymDetails.fromJson(Map<String, dynamic> json) => GymDetails(
        id: json["id"],
        gymName: json["gym_name"],
        ownerName: json["owner_name"],
        phoneNumber: json["phone_number"],
        logo: json["logo"],
        email: json["email"],
        address: json["address"],
        status: json["status"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "gym_name": gymName,
        "owner_name": ownerName,
        "phone_number": phoneNumber,
        "logo": logo,
        "email": email,
        "address": address,
        "status": status,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
      };
}

class Review {
  int? id;
  String? gymOwnerId;
  String? userId;
  String? rate;
  String? review;
  DateTime? createdAt;
  DateTime? updatedAt;
  String? name;
  String? image;

  Review({
    this.id,
    this.gymOwnerId,
    this.userId,
    this.rate,
    this.review,
    this.createdAt,
    this.updatedAt,
    this.name,
    this.image,
  });

  factory Review.fromRawJson(String str) => Review.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Review.fromJson(Map<String, dynamic> json) => Review(
        id: json["id"],
        gymOwnerId: json["gym_owner_id"],
        userId: json["user_id"],
        rate: json["rate"],
        review: json["review"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        name: json["name"],
        image: json["image"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "gym_owner_id": gymOwnerId,
        "user_id": userId,
        "rate": rate,
        "review": review,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "name": name,
        "image": image,
      };
}

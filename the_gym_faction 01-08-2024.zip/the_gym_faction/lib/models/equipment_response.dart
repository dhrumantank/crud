import 'dart:convert';

import '../../models/pagination_model.dart';

class EquipmentResponse {
  Pagination? pagination;
  List<EquipmentModel>? data;

  EquipmentResponse({this.pagination, this.data});

  EquipmentResponse.fromJson(Map<String, dynamic> json) {
    pagination = json['pagination'] != null
        ? Pagination.fromJson(json['pagination'])
        : null;
    if (json['data'] != null) {
      data = <EquipmentModel>[];
      json['data'].forEach((v) {
        data!.add(EquipmentModel.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (pagination != null) {
      data['pagination'] = pagination!.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class EquipmentModel {
  int? id;
  String? title;
  String? status;
  String? bodyPartsName;
  String? bodyPartsImage;
  String? description;
  String? equipmentImage;
  String? createdAt;
  String? updatedAt;
  bool? isSelected = false;

  EquipmentModel(
      {this.id,
      this.title,
      this.status,
      this.bodyPartsName,
      this.bodyPartsImage,
      this.description,
      this.equipmentImage,
      this.createdAt,
      this.updatedAt});

  EquipmentModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    status = json['status'] ?? "";
    bodyPartsName = json["body_parts_name"] ?? "";
    bodyPartsImage = json["body_parts_image"] ?? "";
    description = json['description'];
    equipmentImage = json['equipment_image'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['title'] = title;
    data['status'] = status;
    data["body_parts_name"] = bodyPartsName;
    data["body_parts_image"] = bodyPartsImage;
    data['description'] = description;
    data['equipment_image'] = equipmentImage;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    return data;
  }
}

class EquipmentResponse2 {
  Data? data;

  EquipmentResponse2({
    this.data,
  });

  factory EquipmentResponse2.fromRawJson(String str) =>
      EquipmentResponse2.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory EquipmentResponse2.fromJson(Map<String, dynamic> json) =>
      EquipmentResponse2(
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "data": data?.toJson(),
      };
}

class Data {
  int? currentPage;
  List<EquipmentResponse2Datum>? data;
  String? firstPageUrl;
  int? from;
  int? lastPage;
  String? lastPageUrl;
  List<Link>? links;
  String? nextPageUrl;
  String? path;
  int? perPage;
  dynamic prevPageUrl;
  int? to;
  int? total;

  Data({
    this.currentPage,
    this.data,
    this.firstPageUrl,
    this.from,
    this.lastPage,
    this.lastPageUrl,
    this.links,
    this.nextPageUrl,
    this.path,
    this.perPage,
    this.prevPageUrl,
    this.to,
    this.total,
  });

  factory Data.fromRawJson(String str) => Data.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        currentPage: json["current_page"],
        data: json["data"] == null
            ? []
            : List<EquipmentResponse2Datum>.from(
                json["data"]!.map((x) => EquipmentResponse2Datum.fromJson(x))),
        firstPageUrl: json["first_page_url"],
        from: json["from"],
        lastPage: json["last_page"],
        lastPageUrl: json["last_page_url"],
        links: json["links"] == null
            ? []
            : List<Link>.from(json["links"]!.map((x) => Link.fromJson(x))),
        nextPageUrl: json["next_page_url"],
        path: json["path"],
        perPage: json["per_page"],
        prevPageUrl: json["prev_page_url"],
        to: json["to"],
        total: json["total"],
      );

  Map<String, dynamic> toJson() => {
        "current_page": currentPage,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "first_page_url": firstPageUrl,
        "from": from,
        "last_page": lastPage,
        "last_page_url": lastPageUrl,
        "links": links == null
            ? []
            : List<dynamic>.from(links!.map((x) => x.toJson())),
        "next_page_url": nextPageUrl,
        "path": path,
        "per_page": perPage,
        "prev_page_url": prevPageUrl,
        "to": to,
        "total": total,
      };
}

class EquipmentResponse2Datum {
  int? id;
  String? title;
  dynamic status;
  String? bodyPartsId;
  String? bodyPartsName;
  String? equipmentImage;
  int? createdBy;
  DateTime? createdAt;
  DateTime? updatedAt;
  String? bodyPartsImage;

  EquipmentResponse2Datum({
    this.id,
    this.title,
    this.status,
    this.bodyPartsId,
    this.bodyPartsName,
    this.equipmentImage,
    this.createdBy,
    this.createdAt,
    this.updatedAt,
    this.bodyPartsImage,
  });

  factory EquipmentResponse2Datum.fromRawJson(String str) =>
      EquipmentResponse2Datum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory EquipmentResponse2Datum.fromJson(Map<String, dynamic> json) =>
      EquipmentResponse2Datum(
        id: json["id"],
        title: json["title"],
        status: json["status"],
        bodyPartsId: json["body_parts_id"],
        bodyPartsName: json["body_parts_name"],
        equipmentImage: json["equipment_image"],
        createdBy: json["created_by"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        bodyPartsImage: json["body_parts_image"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "status": status,
        "body_parts_id": bodyPartsId,
        "body_parts_name": bodyPartsName,
        "equipment_image": equipmentImage,
        "created_by": createdBy,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "body_parts_image": bodyPartsImage,
      };
}

class Link {
  String? url;
  String? label;
  bool? active;

  Link({
    this.url,
    this.label,
    this.active,
  });

  factory Link.fromRawJson(String str) => Link.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Link.fromJson(Map<String, dynamic> json) => Link(
        url: json["url"],
        label: json["label"],
        active: json["active"],
      );

  Map<String, dynamic> toJson() => {
        "url": url,
        "label": label,
        "active": active,
      };
}

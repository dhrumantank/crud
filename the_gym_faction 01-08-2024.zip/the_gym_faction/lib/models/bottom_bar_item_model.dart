class BottomBarItemModel{
  String? iconData;
  String? selectedIconData;
  String? labelText;

  BottomBarItemModel({this.iconData,this.selectedIconData, this.labelText});
}
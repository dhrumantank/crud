import 'dart:convert';

class UserTargetDetails {
  bool? success;
  UserProfile? userProfile;
  List<Allergy>? goal;
  List<Allergy>? eatType;
  List<Allergy>? foodCategory;
  List<Allergy>? allergy;
  String? message;

  UserTargetDetails({
    this.success,
    this.userProfile,
    this.goal,
    this.eatType,
    this.foodCategory,
    this.allergy,
    this.message,
  });

  factory UserTargetDetails.fromRawJson(String str) =>
      UserTargetDetails.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory UserTargetDetails.fromJson(Map<String, dynamic> json) =>
      UserTargetDetails(
        success: json["success"],
        userProfile: json["user_profile"] == null
            ? null
            : UserProfile.fromJson(json["user_profile"]),
        goal: json["goal"] == null
            ? []
            : List<Allergy>.from(json["goal"]!.map((x) => Allergy.fromJson(x))),
        eatType: json["eat_type"] == null
            ? []
            : List<Allergy>.from(
                json["eat_type"]!.map((x) => Allergy.fromJson(x))),
        foodCategory: json["food_category"] == null
            ? []
            : List<Allergy>.from(
                json["food_category"]!.map((x) => Allergy.fromJson(x))),
        allergy: json["allergy"] == null
            ? []
            : List<Allergy>.from(
                json["allergy"]!.map((x) => Allergy.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "user_profile": userProfile?.toJson(),
        "goal": goal == null
            ? []
            : List<dynamic>.from(goal!.map((x) => x.toJson())),
        "eat_type": eatType == null
            ? []
            : List<dynamic>.from(eatType!.map((x) => x.toJson())),
        "food_category": foodCategory == null
            ? []
            : List<dynamic>.from(foodCategory!.map((x) => x.toJson())),
        "allergy": allergy == null
            ? []
            : List<dynamic>.from(allergy!.map((x) => x.toJson())),
        "message": message,
      };
}

class Allergy {
  int? id;
  String? title;
  String? ignoreDiets;
  DateTime? createdAt;
  DateTime? updatedAt;

  Allergy({
    this.id,
    this.title,
    this.ignoreDiets,
    this.createdAt,
    this.updatedAt,
  });

  factory Allergy.fromRawJson(String str) => Allergy.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Allergy.fromJson(Map<String, dynamic> json) => Allergy(
        id: json["id"],
        title: json["title"],
        ignoreDiets: json["ignore_diets"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "ignore_diets": ignoreDiets,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
      };
}

class UserProfile {
  int? id;
  String? age;
  String? weight;
  String? weightUnit;
  String? height;
  String? heightUnit;
  dynamic address;
  int? userId;
  DateTime? createdAt;
  DateTime? updatedAt;

  UserProfile({
    this.id,
    this.age,
    this.weight,
    this.weightUnit,
    this.height,
    this.heightUnit,
    this.address,
    this.userId,
    this.createdAt,
    this.updatedAt,
  });

  factory UserProfile.fromRawJson(String str) =>
      UserProfile.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
        id: json["id"],
        age: json["age"],
        weight: json["weight"],
        weightUnit: json["weight_unit"],
        height: json["height"],
        heightUnit: json["height_unit"],
        address: json["address"],
        userId: json["user_id"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "age": age,
        "weight": weight,
        "weight_unit": weightUnit,
        "height": height,
        "height_unit": heightUnit,
        "address": address,
        "user_id": userId,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
      };
}

//
//
//
//
//
//

class UserDietTargetDetailsShow {
  bool? success;
  UserProfileData? userProfile;
  List<AllergyData>? goal;
  List<AllergyData>? eatType;
  List<AllergyData>? foodCategory;
  List<AllergyData>? allergy;
  String? message;

  UserDietTargetDetailsShow({
    this.success,
    this.userProfile,
    this.goal,
    this.eatType,
    this.foodCategory,
    this.allergy,
    this.message,
  });

  factory UserDietTargetDetailsShow.fromRawJson(String str) =>
      UserDietTargetDetailsShow.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory UserDietTargetDetailsShow.fromJson(Map<String, dynamic> json) =>
      UserDietTargetDetailsShow(
        success: json["success"],
        userProfile: json["user_profile"] == null
            ? null
            : UserProfileData.fromJson(json["user_profile"]),
        goal: json["goal"] == null
            ? []
            : List<AllergyData>.from(
                json["goal"]!.map((x) => AllergyData.fromJson(x))),
        eatType: json["eat_type"] == null
            ? []
            : List<AllergyData>.from(
                json["eat_type"]!.map((x) => AllergyData.fromJson(x))),
        foodCategory: json["food_category"] == null
            ? []
            : List<AllergyData>.from(
                json["food_category"]!.map((x) => AllergyData.fromJson(x))),
        allergy: json["allergy"] == null
            ? []
            : List<AllergyData>.from(
                json["allergy"]!.map((x) => AllergyData.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "user_profile": userProfile?.toJson(),
        "goal": goal == null
            ? []
            : List<dynamic>.from(goal!.map((x) => x.toJson())),
        "eat_type": eatType == null
            ? []
            : List<dynamic>.from(eatType!.map((x) => x.toJson())),
        "food_category": foodCategory == null
            ? []
            : List<dynamic>.from(foodCategory!.map((x) => x.toJson())),
        "allergy": allergy == null
            ? []
            : List<dynamic>.from(allergy!.map((x) => x.toJson())),
        "message": message,
      };
}

class AllergyData {
  int? id;
  String? title;
  String? ignoreDiets;
  DateTime? createdAt;
  DateTime? updatedAt;
  bool? status;

  AllergyData({
    this.id,
    this.title,
    this.ignoreDiets,
    this.createdAt,
    this.updatedAt,
    this.status,
  });

  factory AllergyData.fromRawJson(String str) =>
      AllergyData.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory AllergyData.fromJson(Map<String, dynamic> json) => AllergyData(
        id: json["id"],
        title: json["title"],
        ignoreDiets: json["ignore_diets"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        status: json["status"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "ignore_diets": ignoreDiets,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "status": status,
      };
}

class UserProfileData {
  int? id;
  String? age;
  String? weight;
  String? weightUnit;
  String? height;
  String? heightUnit;
  dynamic address;
  int? userId;
  DateTime? createdAt;
  DateTime? updatedAt;

  UserProfileData({
    this.id,
    this.age,
    this.weight,
    this.weightUnit,
    this.height,
    this.heightUnit,
    this.address,
    this.userId,
    this.createdAt,
    this.updatedAt,
  });

  factory UserProfileData.fromRawJson(String str) =>
      UserProfileData.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory UserProfileData.fromJson(Map<String, dynamic> json) =>
      UserProfileData(
        id: json["id"],
        age: json["age"],
        weight: json["weight"],
        weightUnit: json["weight_unit"],
        height: json["height"],
        heightUnit: json["height_unit"],
        address: json["address"],
        userId: json["user_id"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "age": age,
        "weight": weight,
        "weight_unit": weightUnit,
        "height": height,
        "height_unit": heightUnit,
        "address": address,
        "user_id": userId,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
      };
}

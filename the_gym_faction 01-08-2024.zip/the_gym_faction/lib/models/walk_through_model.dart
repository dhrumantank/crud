
class WalkThroughModel {
  String? image;
  String? title;

  WalkThroughModel({this.image, this.title});
}

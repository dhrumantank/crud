import 'dart:convert';

class WaterIntakeDataResponse {
  bool? status;
  double? percentage;
  String? waterData;
  Data? data;
  int? totalTarget;
  String? message;

  WaterIntakeDataResponse({
    this.status,
    this.percentage,
    this.waterData,
    this.data,
    this.totalTarget,
    this.message,
  });

  factory WaterIntakeDataResponse.fromRawJson(String str) =>
      WaterIntakeDataResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory WaterIntakeDataResponse.fromJson(Map<String, dynamic> json) =>
      WaterIntakeDataResponse(
        status: json["status"],
        percentage: json["percentage"]?.toDouble(),
        waterData: json["waterData"],
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
        totalTarget: json["totalTarget"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "status": status,
        "percentage": percentage,
        "waterData": waterData,
        "data": data?.toJson(),
        "totalTarget": totalTarget,
        "message": message,
      };
}

class Data {
  String? percentage;
  String? image;

  Data({
    this.percentage,
    this.image,
  });

  factory Data.fromRawJson(String str) => Data.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        percentage: json["percentage"],
        image: json["image"],
      );

  Map<String, dynamic> toJson() => {
        "percentage": percentage,
        "image": image,
      };
}

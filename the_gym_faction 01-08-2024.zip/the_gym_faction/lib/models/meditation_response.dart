import 'dart:convert';

class MeditationResponse {
  bool? success;
  List<MeditationDatum>? data;
  String? message;

  MeditationResponse({
    this.success,
    this.data,
    this.message,
  });

  factory MeditationResponse.fromRawJson(String str) =>
      MeditationResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory MeditationResponse.fromJson(Map<String, dynamic> json) =>
      MeditationResponse(
        success: json["success"],
        data: json["data"] == null
            ? []
            : List<MeditationDatum>.from(
                json["data"]!.map((x) => MeditationDatum.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "message": message,
      };
}

class MeditationDatum {
  int? id;
  String? title;
  String? time;
  DateTime? createdAt;
  DateTime? updatedAt;
  String? startTime;
  String? endTime;
  int? totalTime;
  String? status;
  int? pendingTime;
  int? pendingTimeSeconds;

  MeditationDatum({
    this.id,
    this.title,
    this.time,
    this.createdAt,
    this.updatedAt,
    this.startTime,
    this.endTime,
    this.totalTime,
    this.status,
    this.pendingTime,
    this.pendingTimeSeconds,
  });

  factory MeditationDatum.fromRawJson(String str) =>
      MeditationDatum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory MeditationDatum.fromJson(Map<String, dynamic> json) =>
      MeditationDatum(
        id: json["id"],
        title: json["title"],
        time: json["time"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        startTime: json["start_time"],
        endTime: json["end_time"],
        totalTime: json["total_time"],
        status: json["status"],
        pendingTime: json["pending_time"],
        pendingTimeSeconds: json["pending_time_seconds"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "time": time,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "start_time": startTime,
        "end_time": endTime,
        "total_time": totalTime,
        "status": status,
        "pending_time": pendingTime,
        "pending_time_seconds": pendingTimeSeconds,
      };
}

//
//
//
//
//
//

class MeditationHistory {
  bool? success;
  List<MeditationHistoryDatum>? data;
  int? inProgressCount;
  int? completeCount;
  int? pendingCount;
  int? totalMeditations;
  String? message;

  MeditationHistory({
    this.success,
    this.data,
    this.inProgressCount,
    this.completeCount,
    this.pendingCount,
    this.totalMeditations,
    this.message,
  });

  factory MeditationHistory.fromRawJson(String str) =>
      MeditationHistory.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory MeditationHistory.fromJson(Map<String, dynamic> json) =>
      MeditationHistory(
        success: json["success"],
        data: json["data"] == null
            ? []
            : List<MeditationHistoryDatum>.from(
                json["data"]!.map((x) => MeditationHistoryDatum.fromJson(x))),
        inProgressCount: json["inProgressCount"],
        completeCount: json["completeCount"],
        pendingCount: json["pendingCount"],
        totalMeditations: json["totalMeditations"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "inProgressCount": inProgressCount,
        "completeCount": completeCount,
        "pendingCount": pendingCount,
        "totalMeditations": totalMeditations,
        "message": message,
      };
}

class MeditationHistoryDatum {
  int? id;
  int? gymOwnerId;
  int? userId;
  int? meditationId;
  DateTime? startTime;
  DateTime? endTime;
  DateTime? date;
  String? status;
  DateTime? createdAt;
  DateTime? updatedAt;
  String? title;
  String? time;

  MeditationHistoryDatum({
    this.id,
    this.gymOwnerId,
    this.userId,
    this.meditationId,
    this.startTime,
    this.endTime,
    this.date,
    this.status,
    this.createdAt,
    this.updatedAt,
    this.title,
    this.time,
  });

  factory MeditationHistoryDatum.fromRawJson(String str) =>
      MeditationHistoryDatum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory MeditationHistoryDatum.fromJson(Map<String, dynamic> json) =>
      MeditationHistoryDatum(
        id: json["id"],
        gymOwnerId: json["gym_owner_id"],
        userId: json["user_id"],
        meditationId: json["meditation_id"],
        startTime: json["start_time"] == null
            ? null
            : DateTime.parse(json["start_time"]),
        endTime:
            json["end_time"] == null ? null : DateTime.parse(json["end_time"]),
        date: json["date"] == null ? null : DateTime.parse(json["date"]),
        status: json["status"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        title: json["title"],
        time: json["time"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "gym_owner_id": gymOwnerId,
        "user_id": userId,
        "meditation_id": meditationId,
        "start_time": startTime?.toIso8601String(),
        "end_time": endTime?.toIso8601String(),
        "date":
            "${date!.year.toString().padLeft(4, '0')}-${date!.month.toString().padLeft(2, '0')}-${date!.day.toString().padLeft(2, '0')}",
        "status": status,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "title": title,
        "time": time,
      };
}

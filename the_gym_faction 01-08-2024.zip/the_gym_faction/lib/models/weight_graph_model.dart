import 'dart:convert';

class WeightGraphResponse {
  bool? success;
  List<WeightGraphDatum>? data;
  String? message;

  WeightGraphResponse({
    this.success,
    this.data,
    this.message,
  });

  factory WeightGraphResponse.fromRawJson(String str) =>
      WeightGraphResponse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory WeightGraphResponse.fromJson(Map<String, dynamic> json) =>
      WeightGraphResponse(
        success: json["success"],
        data: json["data"] == null
            ? []
            : List<WeightGraphDatum>.from(
                json["data"]!.map((x) => WeightGraphDatum.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "message": message,
      };
}

class WeightGraphDatum {
  int? id;
  String? value;
  String? type;
  DateTime? date;
  String? unit;
  DateTime? createdAt;
  DateTime? updatedAt;

  WeightGraphDatum({
    this.id,
    this.value,
    this.type,
    this.date,
    this.unit,
    this.createdAt,
    this.updatedAt,
  });

  factory WeightGraphDatum.fromRawJson(String str) =>
      WeightGraphDatum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory WeightGraphDatum.fromJson(Map<String, dynamic> json) =>
      WeightGraphDatum(
        id: json["id"],
        value: json["value"],
        type: json["type"],
        date: json["date"] == null ? null : DateTime.parse(json["date"]),
        unit: json["unit"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "value": value,
        "type": type,
        "date":
            "${date!.year.toString().padLeft(4, '0')}-${date!.month.toString().padLeft(2, '0')}-${date!.day.toString().padLeft(2, '0')}",
        "unit": unit,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
      };
}

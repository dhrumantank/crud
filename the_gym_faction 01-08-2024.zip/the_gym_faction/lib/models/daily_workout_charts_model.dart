import 'dart:convert';

class DailyWorkoutCharts {
  bool? success;
  List<DailyWorkoutChartsDatum>? data;
  String? message;

  DailyWorkoutCharts({
    this.success,
    this.data,
    this.message,
  });

  factory DailyWorkoutCharts.fromRawJson(String str) =>
      DailyWorkoutCharts.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory DailyWorkoutCharts.fromJson(Map<String, dynamic> json) =>
      DailyWorkoutCharts(
        success: json["success"],
        data: json["data"] == null
            ? []
            : List<DailyWorkoutChartsDatum>.from(
                json["data"]!.map((x) => DailyWorkoutChartsDatum.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "message": message,
      };
}

class DailyWorkoutChartsDatum {
  DateTime? date;
  int? completionPercentage;

  DailyWorkoutChartsDatum({
    this.date,
    this.completionPercentage,
  });

  factory DailyWorkoutChartsDatum.fromRawJson(String str) =>
      DailyWorkoutChartsDatum.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory DailyWorkoutChartsDatum.fromJson(Map<String, dynamic> json) =>
      DailyWorkoutChartsDatum(
        date: json["date"] == null ? null : DateTime.parse(json["date"]),
        completionPercentage: json["completionPercentage"],
      );

  Map<String, dynamic> toJson() => {
        "date":
            "${date!.year.toString().padLeft(4, '0')}-${date!.month.toString().padLeft(2, '0')}-${date!.day.toString().padLeft(2, '0')}",
        "completionPercentage": completionPercentage,
      };
}

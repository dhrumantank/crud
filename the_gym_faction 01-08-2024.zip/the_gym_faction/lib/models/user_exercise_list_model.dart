import 'dart:convert';

class UserExerciseList {
  bool? success;
  List<int>? userSelectedDay;
  List<Part>? bodyparts;
  List<Part>? allBodyParts;
  String? message;

  UserExerciseList({
    this.success,
    this.userSelectedDay,
    this.bodyparts,
    this.allBodyParts,
    this.message,
  });

  factory UserExerciseList.fromRawJson(String str) =>
      UserExerciseList.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory UserExerciseList.fromJson(Map<String, dynamic> json) =>
      UserExerciseList(
        success: json["success"],
        userSelectedDay: json["userSelectedDay"] == null
            ? []
            : List<int>.from(json["userSelectedDay"]!.map((x) => x)),
        bodyparts: json["bodyparts"] == null
            ? []
            : List<Part>.from(json["bodyparts"]!.map((x) => Part.fromJson(x))),
        allBodyParts: json["allBodyParts"] == null
            ? []
            : List<Part>.from(
                json["allBodyParts"]!.map((x) => Part.fromJson(x))),
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "userSelectedDay": userSelectedDay == null
            ? []
            : List<dynamic>.from(userSelectedDay!.map((x) => x)),
        "bodyparts": bodyparts == null
            ? []
            : List<dynamic>.from(bodyparts!.map((x) => x.toJson())),
        "allBodyParts": allBodyParts == null
            ? []
            : List<dynamic>.from(allBodyParts!.map((x) => x.toJson())),
        "message": message,
      };
}

class Part {
  int? id;
  String? title;
  String? image;

  Part({
    this.id,
    this.title,
    this.image,
  });

  factory Part.fromRawJson(String str) => Part.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Part.fromJson(Map<String, dynamic> json) => Part(
        id: json["id"],
        title: json["title"],
        image: json["image"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "image": image,
      };
}

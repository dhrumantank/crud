import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

class FastAndMeditationShimmerEffect extends StatelessWidget {
  const FastAndMeditationShimmerEffect({super.key});

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SingleChildScrollView(
      child: Column(
        children: [
          Shimmer.fromColors(
            baseColor: Colors.grey.shade200,
            highlightColor: Colors.grey.shade400,
            child: Container(
              width: w * 0.88,
              height: h * 0.3,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: Colors.grey.shade200,
              ),
            ),
          ).center(),
          10.height,
          ListView.builder(
            shrinkWrap: true,
            itemCount: 10,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) {
              return SizedBox(
                width: w,
                height: h * 0.15,
                child: Stack(
                  children: [
                    Shimmer.fromColors(
                        baseColor: Colors.grey.shade200,
                        highlightColor: Colors.white54,
                        child: Container(
                          width: w,
                          height: h * 0.15,
                          decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                blurRadius: 10,
                                color: Colors.grey.shade200,
                                spreadRadius: 2,
                              )
                            ],
                            color: Colors.grey.shade200,
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ).paddingSymmetric(horizontal: 20, vertical: 10)),
                    Positioned(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          10.height,
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              40.width,
                              Shimmer.fromColors(
                                baseColor: Colors.grey.shade300,
                                highlightColor: Colors.white54,
                                child: CircleAvatar(
                                    radius: 30,
                                    backgroundColor: Colors.grey.shade300),
                              ),
                              20.width,
                              Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Shimmer.fromColors(
                                    baseColor: Colors.grey.shade300,
                                    highlightColor: Colors.white54,
                                    child: Container(
                                      width: w * 0.4,
                                      height: h * 0.02,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(5),
                                        color: Colors.grey.shade300,
                                      ),
                                    ),
                                  ),
                                  5.height,
                                  Shimmer.fromColors(
                                    baseColor: Colors.grey.shade300,
                                    highlightColor: Colors.white54,
                                    child: Container(
                                      width: w * 0.3,
                                      height: h * 0.02,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(5),
                                        color: Colors.grey.shade300,
                                      ),
                                    ),
                                  ),
                                ],
                              )
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Shimmer.fromColors(
                                baseColor: Colors.grey.shade300,
                                highlightColor: Colors.white54,
                                child: Container(
                                  width: w * 0.2,
                                  height: h * 0.02,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    color: Colors.grey.shade300,
                                  ),
                                ),
                              ),
                              30.width,
                            ],
                          ),
                          10.height,
                        ],
                      ),
                    )
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class FastAndMeditationHistoryShimmer extends StatelessWidget {
  const FastAndMeditationHistoryShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return SingleChildScrollView(
      child: Column(
        children: [
          ListView.builder(
            itemCount: 10,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) {
              return SizedBox(
                width: w,
                height: h * 0.12,
                child: Stack(
                  children: [
                    Shimmer.fromColors(
                        baseColor: Colors.grey.shade200,
                        highlightColor: Colors.white54,
                        child: Container(
                          width: w,
                          height: h * 0.12,
                          decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                blurRadius: 10,
                                color: Colors.grey.shade200,
                                spreadRadius: 2,
                              )
                            ],
                            color: Colors.grey.shade200,
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ).paddingSymmetric(horizontal: 20, vertical: 10)),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        40.width,
                        Shimmer.fromColors(
                          baseColor: Colors.grey.shade300,
                          highlightColor: Colors.white54,
                          child: CircleAvatar(
                              radius: 30,
                              backgroundColor: Colors.grey.shade300),
                        ),
                        20.width,
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Shimmer.fromColors(
                              baseColor: Colors.grey.shade300,
                              highlightColor: Colors.white54,
                              child: Container(
                                width: w * 0.4,
                                height: h * 0.02,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5),
                                  color: Colors.grey.shade300,
                                ),
                              ),
                            ),
                            5.height,
                            Shimmer.fromColors(
                              baseColor: Colors.grey.shade300,
                              highlightColor: Colors.white54,
                              child: Container(
                                width: w * 0.3,
                                height: h * 0.02,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5),
                                  color: Colors.grey.shade300,
                                ),
                              ),
                            ),
                            5.height,
                            Shimmer.fromColors(
                              baseColor: Colors.grey.shade300,
                              highlightColor: Colors.white54,
                              child: Container(
                                width: w * 0.2,
                                height: h * 0.02,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5),
                                  color: Colors.grey.shade300,
                                ),
                              ),
                            ),
                          ],
                        )
                      ],
                    )
                  ],
                ),
              );
            },
          )
        ],
      ),
    );
  }
}

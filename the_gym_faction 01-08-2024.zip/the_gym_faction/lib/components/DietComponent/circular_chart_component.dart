import 'package:TheGymFaction/extensions/colors.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../models/diet_list_model.dart';

class CircularChart extends StatelessWidget {
  const CircularChart(
      {super.key, required this.chartData, required this.calories});
  final List<DoughnutChart> chartData;
  final double calories;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return SizedBox(
      width: w * 0.6,
      height: h * 0.3,
      child: Stack(
        children: [
          SfCircularChart(
            tooltipBehavior: TooltipBehavior(enable: true),
            series: <CircularSeries<DoughnutChart, String>>[
              DoughnutSeries<DoughnutChart, String>(
                dataSource: chartData,
                xValueMapper: (DoughnutChart data, _) => data.x,
                yValueMapper: (DoughnutChart data, _) => data.y,
                pointColorMapper: (DoughnutChart data, _) => data.color,
                dataLabelMapper: (DoughnutChart data, _) => data.text,
                radius: '100%',
                innerRadius: '60%',
                dataLabelSettings: const DataLabelSettings(
                    isVisible: true, textStyle: TextStyle(color: whiteColor)
                    // labelPosition: ChartDataLabelPosition.inside,
                    ),
              ),
            ],
          ),
          Align(
            alignment: Alignment.center,
            child: Text(
              "${calories.toStringAsFixed(2)} Kcal \nConsumed",
              style: boldTextStyle(),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}

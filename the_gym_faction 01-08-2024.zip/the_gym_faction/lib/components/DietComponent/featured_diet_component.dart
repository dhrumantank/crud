import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../../extensions/colors.dart';
import '../../extensions/text_styles.dart';
import '../../models/diet_list_model.dart';
import '../../utils/app_common.dart';
import '../../utils/app_images.dart';

class DietsScreen extends StatelessWidget {
  const DietsScreen({
    super.key,
    required this.diets,
    this.onTap,
    required this.refreshData,
  });
  final DietListResponseDiet diets;
  final void Function()? onTap;
  final Widget refreshData;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Stack(
      children: [
        GestureDetector(
          onTap: onTap,
          child: Container(
            width: w,
            constraints: BoxConstraints(minHeight: h * 0.15),
            decoration: BoxDecoration(
              border: Border.all(
                color: diets.consumed == 1 ? Colors.green : Colors.transparent,
              ),
              boxShadow: [
                BoxShadow(
                  blurRadius: 10,
                  color: Colors.grey.shade200,
                  spreadRadius: 2,
                )
              ],
              color: whiteColor,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Stack(
              children: [
                Row(
                  children: [
                    20.width,
                    Container(
                      width: w * 0.21,
                      height: h * 0.1,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(80),
                      ),
                      child: cachedImage(fit: BoxFit.fill, diets.image)
                          .cornerRadiusWithClipRRect(80),
                    ),
                    20.width,
                    Container(
                      constraints: BoxConstraints(minHeight: h * 0.15),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            children: [
                              diets.consumed == 1 ? 30.height : 20.height,
                              Container(
                                constraints: BoxConstraints(maxWidth: w * 0.49),
                                child: Text(
                                  diets.title.toString(),
                                  style: boldTextStyle(),
                                ),
                              ),
                            ],
                          ),
                          // Spacer(),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  const ImageIcon(
                                    AssetImage(ic_calories),
                                    color: Colors.grey,
                                    size: 18,
                                  ),
                                  5.width,
                                  Text(
                                    "${diets.caloriesForOne!.toStringAsFixed(2)} (Calories/Per)",
                                    style: boldTextStyle(
                                        color: Colors.grey, size: 14),
                                  ),
                                ],
                              ),
                              Container(
                                constraints: BoxConstraints(maxWidth: w * 0.6),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      "${diets.totalTime} Min",
                                      style: boldTextStyle(
                                          color: Colors.grey, size: 14),
                                    ),
                                    Text(
                                      "  |  ",
                                      style: boldTextStyle(
                                          color: Colors.grey, size: 14),
                                    ),
                                    Text(
                                      "${diets.servings} Serving",
                                      style: boldTextStyle(
                                          color: Colors.grey, size: 14),
                                    ),
                                    const Spacer(),
                                    diets.consumed == 1
                                        ? const SizedBox()
                                        : Container(
                                            height: h * 0.04,
                                            width: w * 0.09,
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(80),
                                                color: black),
                                            child: const Icon(
                                              Icons.arrow_forward,
                                              size: 15,
                                              color: whiteColor,
                                            ),
                                          ).paddingSymmetric(horizontal: 10),
                                  ],
                                ),
                              ),
                              diets.consumed == 1 ? 10.height : 5.height,
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                if (diets.consumed == 0) refreshData
              ],
            ),
          ).paddingSymmetric(vertical: 10),
        ),
        Align(
          alignment: Alignment.topRight,
          child: diets.consumed == 0
              ? const SizedBox()
              : Container(
                  decoration: BoxDecoration(
                    color: Colors.green,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Text.rich(
                    TextSpan(text: "Consumed", children: [
                      WidgetSpan(
                        child: 5.width,
                      ),
                      const WidgetSpan(
                        child: CircleAvatar(
                          radius: 7,
                          backgroundColor: whiteColor,
                          child: Icon(
                            size: 12,
                            Icons.done,
                            color: Colors.green,
                          ),
                        ),
                      ),
                    ]),
                    style: boldTextStyle(color: whiteColor, size: 14),
                  ).paddingSymmetric(horizontal: 8, vertical: 4),
                ).paddingSymmetric(vertical: 15, horizontal: 5),
        )
      ],
    );
  }
}

class ShimmerEffectScreen extends StatelessWidget {
  const ShimmerEffectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Column(
      children: [
        10.height,
        Shimmer.fromColors(
          baseColor: Colors.grey.shade300,
          highlightColor: Colors.white54,
          child: CircleAvatar(
            radius: 120,
            backgroundColor: Colors.grey.shade300,
          ),
        ),
        25.height,
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: List.generate(
            5,
            (index) => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Shimmer.fromColors(
                    baseColor: Colors.grey.shade300,
                    highlightColor: Colors.white54,
                    child: Container(
                      width: w * 0.5,
                      height: h * 0.03,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        color: Colors.grey.shade200,
                      ),
                    )),
                SizedBox(
                  width: w,
                  height: h * 0.17,
                  child: Stack(
                    children: [
                      Shimmer.fromColors(
                        baseColor: Colors.grey.shade200,
                        highlightColor: whiteColor,
                        child: Container(
                          width: w,
                          height: h * 0.15,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.grey.shade200,
                          ),
                        ).paddingSymmetric(vertical: 10),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Row(
                          children: [
                            Shimmer.fromColors(
                              baseColor: Colors.grey.shade300,
                              highlightColor: whiteColor,
                              child: Container(
                                width: w * 0.21,
                                height: h * 0.1,
                                decoration: BoxDecoration(
                                  color: Colors.grey.shade300,
                                  borderRadius: BorderRadius.circular(80),
                                ),
                              ),
                            ).paddingSymmetric(horizontal: 20),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Shimmer.fromColors(
                                  baseColor: Colors.grey.shade300,
                                  highlightColor: Colors.white54,
                                  child: Container(
                                    width: w * 0.4,
                                    height: h * 0.02,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      color: Colors.grey.shade300,
                                    ),
                                  ),
                                ),
                                5.height,
                                Shimmer.fromColors(
                                  baseColor: Colors.grey.shade300,
                                  highlightColor: Colors.white54,
                                  child: Container(
                                    width: w * 0.3,
                                    height: h * 0.02,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      color: Colors.grey.shade300,
                                    ),
                                  ),
                                ),
                                5.height,
                                Shimmer.fromColors(
                                  baseColor: Colors.grey.shade300,
                                  highlightColor: Colors.white54,
                                  child: Container(
                                    width: w * 0.2,
                                    height: h * 0.02,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      color: Colors.grey.shade300,
                                    ),
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class NoDietFound extends StatelessWidget {
  const NoDietFound({super.key});

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    return Column(
      children: [
        10.height,
        Container(
          width: w,
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                blurRadius: 10,
                color: Colors.grey.shade200,
                spreadRadius: 2,
              )
            ],
            color: whiteColor,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text(
            "No Meal Found For Today",
            style: boldTextStyle(size: 14),
          ).paddingSymmetric(vertical: 20, horizontal: 10),
        ),
        10.height,
      ],
    );
  }
}

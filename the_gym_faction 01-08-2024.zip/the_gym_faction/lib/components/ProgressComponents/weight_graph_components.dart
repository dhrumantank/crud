import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../extensions/colors.dart';
import '../../models/weight_graph_model.dart';

class WeightGraphComponents extends StatefulWidget {
  const WeightGraphComponents({super.key, this.seriesList});
  final List<WeightGraphDatum>? seriesList;

  @override
  State<WeightGraphComponents> createState() => _WeightGraphComponentsState();
}

class _WeightGraphComponentsState extends State<WeightGraphComponents> {
  DateFormat dateFormat = DateFormat("dd-MM");
  @override
  Widget build(BuildContext context) {
    return SfCartesianChart(
      tooltipBehavior: TooltipBehavior(enable: true),
      plotAreaBorderWidth: 0,
      primaryXAxis: const CategoryAxis(
        majorGridLines: MajorGridLines(width: 0),
        labelStyle: TextStyle(),
      ),
      primaryYAxis: const NumericAxis(
        minimum: 0,
        maximum: 100,
        interval: 5,
        labelFormat: r'{value}',
        majorGridLines: MajorGridLines(color: Colors.transparent),
        labelStyle: TextStyle(),
      ),
      series: <SplineSeries<WeightGraphDatum, dynamic>>[
        SplineSeries<WeightGraphDatum, dynamic>(
          dataSource: widget.seriesList,
          xValueMapper: (WeightGraphDatum data, _) =>
              dateFormat.format(DateTime.parse(data.date.toString())),
          yValueMapper: (WeightGraphDatum data, _) =>
              double.parse(data.value.toString()),
          name: 'Weight',
          color: black,
          markerSettings: const MarkerSettings(
            isVisible: true,
          ),
        ),
      ],
    ).paddingSymmetric(vertical: 10).paddingSymmetric(horizontal: 15);
  }
}

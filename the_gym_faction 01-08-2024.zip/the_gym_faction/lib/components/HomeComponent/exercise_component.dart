import 'package:flutter/material.dart';

import '../../../extensions/decorations.dart';
import '../../../extensions/extension_util/int_extensions.dart';
import '../../../extensions/extension_util/string_extensions.dart';
import '../../../extensions/extension_util/widget_extensions.dart';
import '../../extensions/text_styles.dart';
import '../../main.dart';
import '../../models/exercise_response.dart';
import '../../screens/Home/Exercise/exercise_detail_screen.dart';
import '../../utils/app_common.dart';
import '../../utils/app_constants.dart';

class ExerciseComponent extends StatefulWidget {
  final ExerciseModel? mExerciseModel;
  final Function? onCall;

  const ExerciseComponent({super.key, this.mExerciseModel, this.onCall});

  @override
  State<ExerciseComponent> createState() => _ExerciseComponentState();
}

class _ExerciseComponentState extends State<ExerciseComponent> {
  List<String>? mSets = [];

  @override
  void initState() {
    if (widget.mExerciseModel!.type == SETS) {
      if (widget.mExerciseModel!.sets != null) {
        for (var element in widget.mExerciseModel!.sets!) {
          if (widget.mExerciseModel!.based.toString() == TIME) {
            mSets!.add("${element.time}s");
          } else {
            mSets!.add("${element.reps}x");
          }
          setState(() {});
        }
      }
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: appStore.isDarkMode
          ? boxDecorationWithRoundedCorners(borderRadius: radius(12))
          : boxDecorationRoundedWithShadow(12),
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 8),
      margin: const EdgeInsets.only(bottom: 8, top: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              cachedImage(widget.mExerciseModel!.exerciseImage.validate(),
                      width: 55, height: 55, fit: BoxFit.fill)
                  .cornerRadiusWithClipRRect(10),
              12.width,
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  6.height,
                  Text(widget.mExerciseModel!.title.validate(),
                      style: boldTextStyle(),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  6.height,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      if (widget.mExerciseModel!.type == DURATION)
                        Column(
                          children: List.generate(
                            widget.mExerciseModel!.duration!.length,
                            (index) => Text(
                                "${widget.mExerciseModel!.duration![index].duration!.validate()} ${languages.lblMinutes}",
                                style: secondaryTextStyle(size: 12)),
                          ),
                        ),
                      if (widget.mExerciseModel!.type == SETS)
                        Text(mSets!.join(" ").toString(),
                            style: secondaryTextStyle(size: 12)),
                    ],
                  ),
                ],
              ).expand()
            ],
          ).expand(),
        ],
      ),
    ).onTap(() {
      ExerciseDetailScreen(
              check: true,
              mExerciseName: widget.mExerciseModel!.title.validate(),
              mExerciseId: widget.mExerciseModel!.id.validate())
          .launch(context);
    });
  }
}

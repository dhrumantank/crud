import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/utils/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../../extensions/app_button.dart';
import '../../extensions/colors.dart';
import '../../extensions/text_styles.dart';
import '../../models/weight_graph_model.dart';
import '../horizontal_bar_chart.dart';

class WaterIntake extends StatelessWidget {
  const WaterIntake(
      {super.key, this.seriesList, this.onTap, required this.check});
  final List<WeightGraphDatum>? seriesList;
  final Function? onTap;
  final bool check;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return check == true
        ? const ChartShimmerEffect()
        : seriesList!.isEmpty
            ? Stack(
                children: [
                  WaterIntakeGraphCard(onTap: onTap, seriesList: const []),
                  Positioned(
                    left: w * 0.45,
                    top: h * 0.23,
                    child: Text(
                      "No Data",
                      style: boldTextStyle(size: 14),
                    ),
                  ),
                ],
              )
            : WaterIntakeGraphCard(onTap: onTap, seriesList: seriesList);
  }
}

class WaterIntakeGraphCard extends StatelessWidget {
  const WaterIntakeGraphCard({super.key, this.seriesList, this.onTap});
  final List<WeightGraphDatum>? seriesList;
  final Function? onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 1.0,
      color: whiteColor,
      shape: RoundedRectangleBorder(
        side: BorderSide(color: Colors.grey.shade300, width: 0.0),
        borderRadius: BorderRadius.circular(20),
      ),
      margin: EdgeInsets.zero,
      child: Column(
        children: [
          Row(
            children: [
              Text(
                "Water Intake",
                style: boldTextStyle(size: 18),
              ).paddingSymmetric(horizontal: 10, vertical: 10),
              const Spacer(),
              AppButton(
                onTap: onTap,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Text(
                  "Enter Today Water Intake",
                  style: boldTextStyle(size: 12, color: whiteColor),
                ),
              ),
              10.width,
            ],
          ),
          HorizontalBarChart(
            XAxisLineColor: Colors.transparent,
            YAxisLineColor: Colors.transparent,
            waterSeriesList: seriesList,
            type: "water",
            color: Colors.black,
            borderColor: Colors.transparent,
            axisLineBorderColor: Colors.transparent,
            MarkerBorderColor: appRedColor,
            name: "Water Intake",
          ),
          10.height,
          Text(
            "Drinking 3-4 liters of water per day will\nmaintain your body!",
            style: boldTextStyle(size: 16),
            textAlign: TextAlign.center,
          ),
          10.height,
        ],
      ),
    ).paddingSymmetric(horizontal: 10);
  }
}

class ChartShimmerEffect extends StatelessWidget {
  const ChartShimmerEffect({super.key});

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Shimmer.fromColors(
      baseColor: Colors.grey.shade200,
      highlightColor: Colors.grey.shade400,
      child: Container(
        width: w * 0.88,
        height: h * 0.4,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: Colors.grey.shade200,
        ),
      ),
    ).center();
  }
}

import 'package:TheGymFaction/extensions/app_button.dart';
import 'package:TheGymFaction/extensions/colors.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/string_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/extensions/system_utils.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:TheGymFaction/utils/app_common.dart';
import 'package:flutter/material.dart';

import '../../extensions/loader_widget.dart';
import '../../models/daily_workout_model.dart';
import '../../screens/Home/TodayExercises/today_workout.dart';

class StartExerciseDialog extends StatefulWidget {
  const StartExerciseDialog({super.key});

  @override
  State<StartExerciseDialog> createState() => _StartExerciseDialogState();
}

class _StartExerciseDialogState extends State<StartExerciseDialog> {
  bool getData = false;
  List<DailyWorkoutModel> dailyWorkout = [];
  @override
  void initState() {
    checkDashboardData();
    super.initState();
  }

  void checkDashboardData() {
    setState(() => getData = true);
    getDashboardApi().then((value) {
      dailyWorkout = value.dailyWorkout!;
      setState(() => getData = false);
      return;
    });
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Dialog(
      backgroundColor: Colors.transparent,
      child: getData
          ? Container(
              width: w,
              height: h * 0.42,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Stack(
                children: [
                  const Loader().center(),
                  Align(
                    alignment: Alignment.topRight,
                    child: IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.close),
                    ),
                  ),
                ],
              ),
            )
          : Container(
              width: w,
              height: h * 0.42,
              decoration: BoxDecoration(
                color: whiteColor,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Stack(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      (h * 0.025).toInt().height,
                      Container(
                        width: w * 0.3,
                        height: h * 0.15,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(150),
                          boxShadow: [
                            BoxShadow(
                                color: Colors.grey.shade200, spreadRadius: 1),
                          ],
                        ),
                        child: cachedImage(dailyWorkout.first.image.validate(),
                                fit: BoxFit.fill,
                                width: w * 0.3,
                                height: h * 0.15)
                            .cornerRadiusWithClipRRect(150),
                      ).center(),
                      (h * 0.04).toInt().height,
                      Text(
                        "Today Is ${dailyWorkout.first.bodyPartName.capitalizeFirstLetter()} Day, Start Exercising",
                        style: boldTextStyle(size: 14),
                        textAlign: TextAlign.center,
                      ).center(),
                      (h * 0.005).toInt().height,
                      Text(
                        "Total ${dailyWorkout.first.exerciseCount.toString()} Exercising",
                        style: boldTextStyle(size: 14),
                        textAlign: TextAlign.center,
                      ).center(),
                      (h * 0.06).toInt().height,
                      AppButton(
                        onTap: () {
                          const TodayWorkout()
                              .launch(context)
                              .then((value) => finish(context));
                        },
                        text: "Start Exercise",
                      ).center(),
                      (h * 0.025).toInt().height,
                    ],
                  ).paddingSymmetric(horizontal: 20),
                  Align(
                    alignment: Alignment.topRight,
                    child: IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.close),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

import 'package:TheGymFaction/components/HomeComponent/edit_sets_exercise_componet.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/main.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:TheGymFaction/utils/app_colors.dart';
import 'package:TheGymFaction/utils/app_common.dart';
import 'package:flutter/material.dart';

import '../../extensions/colors.dart';
import '../../extensions/decorations.dart';
import '../../extensions/text_styles.dart';
import '../../models/exercise_detail_response.dart';

class ViewSetsExercise extends StatefulWidget {
  const ViewSetsExercise(
      {super.key, required this.setsList, required this.exerciseId});
  final List<Sets> setsList;
  final int exerciseId;

  @override
  State<ViewSetsExercise> createState() => _ViewSetsExerciseState();
}

class _ViewSetsExerciseState extends State<ViewSetsExercise> {
  @override
  void initState() {
    if (widget.setsList.length < 3) {
      if (widget.setsList.length == 2) {
        widget.setsList.add(Sets(
          reps: "0",
          rest: "0",
          time: "0",
          weight: "0",
          type: "0",
        ));
      }
      if (widget.setsList.length == 1) {
        widget.setsList.add(Sets(
          reps: "0",
          rest: "0",
          time: "0",
          weight: "0",
          type: "0",
        ));
        widget.setsList.add(Sets(
          reps: "0",
          rest: "0",
          time: "0",
          weight: "0",
          type: "0",
        ));
      }
      if (widget.setsList.isEmpty) {
        widget.setsList.add(Sets(
          reps: "0",
          rest: "0",
          time: "0",
          weight: "0",
          type: "0",
        ));
        widget.setsList.add(Sets(
          reps: "0",
          rest: "0",
          time: "0",
          weight: "0",
          type: "0",
        ));
        widget.setsList.add(Sets(
          reps: "0",
          rest: "0",
          time: "0",
          weight: "0",
          type: "0",
        ));
      }
    }
    super.initState();
  }

  void deleteSets(List<Sets> sets) {
    List allSets = [];
    for (var element in sets) {
      allSets.add(element.toJson());
      setState(() {});
    }
    Map<String, dynamic> req = {
      "exercise_id": widget.exerciseId,
      "sets": allSets,
    };
    getEditExerciseSetsResponse(req).then((value) {
      toast("Delete Reps And Weight Successfully");
    });
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Column(
          children: [
            5.height,
            Container(
              width: w * 0.6,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey.shade300),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text(
                    languages.reps,
                    style: boldTextStyle(),
                  ).paddingSymmetric(vertical: 15, horizontal: 10),
                  Text(
                    languages.lblWeight,
                    style: boldTextStyle(),
                  ).paddingSymmetric(vertical: 15, horizontal: 10),
                ],
              ),
            ),
            5.height,
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: List.generate(widget.setsList.length, (index) {
                return Container(
                  width: w * 0.6,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.shade300),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text(
                        "${widget.setsList[index].reps!}x",
                        style: boldTextStyle(),
                      ).paddingSymmetric(vertical: 10, horizontal: 10),
                      Text(
                        "${widget.setsList[index].weight!} ${languages.kg}",
                        style: boldTextStyle(),
                      ).paddingSymmetric(vertical: 10, horizontal: 10),
                    ],
                  ).paddingSymmetric(vertical: 8),
                ).paddingSymmetric(vertical: 5);
              }),
            ),
          ],
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            5.height,
            SizedBox(height: h * 0.057),
            5.height,
            Column(
              children: List.generate(widget.setsList.length, (index) {
                if (index < 3) {
                  if (index == 1) {
                    return GestureDetector(
                      onTap: () async {
                        await showModalBottomSheet(
                            isScrollControlled: true,
                            context: context,
                            backgroundColor: appStore.isDarkMode
                                ? cardDarkColor
                                : cardLightColor,
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    radiusOnly(topRight: 18, topLeft: 18)),
                            builder: (context) {
                              return EditSetsExercise(
                                exerciseId: widget.exerciseId,
                                setsList: widget.setsList,
                                setsIndex: widget.setsList.length,
                              );
                            }).then((value) => setState(() {}));
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.blue,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.edit,
                              size: 20,
                              color: whiteColor,
                            ),
                            8.width,
                            Text(
                              languages.edit,
                              style: boldTextStyle(color: whiteColor),
                            ),
                          ],
                        ).paddingSymmetric(vertical: 10, horizontal: 10),
                      ).paddingSymmetric(vertical: 15),
                    );
                  } else {
                    return Container(
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.edit,
                            size: 20,
                            color: Colors.transparent,
                          ),
                          8.width,
                          Text(
                            languages.edit,
                            style: boldTextStyle(color: Colors.transparent),
                          ),
                        ],
                      ).paddingSymmetric(vertical: 10, horizontal: 10),
                    ).paddingSymmetric(vertical: 15);
                  }
                } else {
                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        widget.setsList.removeAt(index);
                        deleteSets(widget.setsList);
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: appRedColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Row(
                        children: [
                          Icon(
                            Icons.delete,
                            size: 20,
                            color: whiteColor,
                          ),
                        ],
                      ).paddingSymmetric(vertical: 10, horizontal: 10),
                    ).paddingSymmetric(vertical: 15),
                  );
                }
              }),
            ),
          ],
        ),
      ],
    ).paddingSymmetric(vertical: 10).center();
  }
}

//
// class ViewSetsExercise extends StatelessWidget {
//   const ViewSetsExercise(
//       {super.key, required this.setsList, required this.exerciseId});
//   final List<Sets> setsList;
//   final int exerciseId;
//
//   @override
//   Widget build(BuildContext context) {
//     if (setsList.length < 4) {
//       setsList.add(Sets(
//         reps: "0",
//         rest: "0",
//         time: "0",
//         weight: "0",
//         type: "0",
//       ));
//
//       if (setsList.length == 2) {
//         setsList.add(Sets(
//           reps: "0",
//           rest: "0",
//           time: "0",
//           weight: "0",
//           type: "0",
//         ));
//       }
//       if (setsList.length == 1) {
//         setsList.add(Sets(
//           reps: "0",
//           rest: "0",
//           time: "0",
//           weight: "0",
//           type: "0",
//         ));
//         setsList.add(Sets(
//           reps: "0",
//           rest: "0",
//           time: "0",
//           weight: "0",
//           type: "0",
//         ));
//       }
//       if (setsList.isEmpty) {
//         setsList.add(Sets(
//           reps: "0",
//           rest: "0",
//           time: "0",
//           weight: "0",
//           type: "0",
//         ));
//         setsList.add(Sets(
//           reps: "0",
//           rest: "0",
//           time: "0",
//           weight: "0",
//           type: "0",
//         ));
//         setsList.add(Sets(
//           reps: "0",
//           rest: "0",
//           time: "0",
//           weight: "0",
//           type: "0",
//         ));
//       }
//     }
//     final w = MediaQuery.of(context).size.width;
//     final h = MediaQuery.of(context).size.height;
//     return Row(
//       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//       children: [
//         Column(
//           children: [
//             5.height,
//             Container(
//               width: w * 0.6,
//               decoration: BoxDecoration(
//                 border: Border.all(color: Colors.grey.shade300),
//                 borderRadius: BorderRadius.circular(10),
//               ),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceAround,
//                 children: [
//                   Text(
//                     languages.reps,
//                     style: boldTextStyle(),
//                   ).paddingSymmetric(vertical: 15, horizontal: 10),
//                   Text(
//                     languages.lblWeight,
//                     style: boldTextStyle(),
//                   ).paddingSymmetric(vertical: 15, horizontal: 10),
//                 ],
//               ),
//             ),
//             5.height,
//             Column(
//               crossAxisAlignment: CrossAxisAlignment.center,
//               children: List.generate(setsList.length, (index) {
//                 return Container(
//                   width: w * 0.6,
//                   decoration: BoxDecoration(
//                     border: Border.all(color: Colors.grey.shade300),
//                     borderRadius: BorderRadius.circular(10),
//                   ),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceAround,
//                     children: [
//                       Text(
//                         "${setsList[index].reps!}x",
//                         style: boldTextStyle(),
//                       ).paddingSymmetric(vertical: 10, horizontal: 10),
//                       Text(
//                         "${setsList[index].weight!} ${languages.kg}",
//                         style: boldTextStyle(),
//                       ).paddingSymmetric(vertical: 10, horizontal: 10),
//                     ],
//                   ).paddingSymmetric(vertical: 8),
//                 ).paddingSymmetric(vertical: 5);
//               }),
//             ),
//           ],
//         ),
//         Column(
//           mainAxisAlignment: MainAxisAlignment.start,
//           children: [
//             5.height,
//             SizedBox(height: h * 0.057),
//             5.height,
//             Column(
//               children: List.generate(setsList.length, (index) {
//                 if (index < 3) {
//                   if (index == 1) {
//                     return GestureDetector(
//                       onTap: () async {
//                         await showModalBottomSheet(
//                             isScrollControlled: true,
//                             context: context,
//                             backgroundColor: appStore.isDarkMode
//                                 ? cardDarkColor
//                                 : cardLightColor,
//                             shape: RoundedRectangleBorder(
//                                 borderRadius:
//                                     radiusOnly(topRight: 18, topLeft: 18)),
//                             builder: (context) {
//                               return EditSetsExercise(
//                                 exerciseId: exerciseId,
//                                 setsList: setsList,
//                                 setsIndex: setsList.length,
//                               );
//                             });
//                       },
//                       child: Container(
//                         decoration: BoxDecoration(
//                           color: Colors.blue,
//                           borderRadius: BorderRadius.circular(10),
//                         ),
//                         child: Row(
//                           children: [
//                             const Icon(
//                               Icons.edit,
//                               size: 20,
//                               color: whiteColor,
//                             ),
//                             8.width,
//                             Text(
//                               languages.edit,
//                               style: boldTextStyle(color: whiteColor),
//                             ),
//                           ],
//                         ).paddingSymmetric(vertical: 10, horizontal: 10),
//                       ).paddingSymmetric(vertical: 15),
//                     );
//                   } else {
//                     return Container(
//                       decoration: BoxDecoration(
//                         color: Colors.transparent,
//                         borderRadius: BorderRadius.circular(10),
//                       ),
//                       child: Row(
//                         children: [
//                           const Icon(
//                             Icons.edit,
//                             size: 20,
//                             color: Colors.transparent,
//                           ),
//                           8.width,
//                           Text(
//                             languages.edit,
//                             style: boldTextStyle(color: Colors.transparent),
//                           ),
//                         ],
//                       ).paddingSymmetric(vertical: 10, horizontal: 10),
//                     ).paddingSymmetric(vertical: 15);
//                   }
//                 } else {
//                   return GestureDetector(
//                     onTap: () async {
//                       await showModalBottomSheet(
//                           isScrollControlled: true,
//                           context: context,
//                           backgroundColor: appStore.isDarkMode
//                               ? cardDarkColor
//                               : cardLightColor,
//                           shape: RoundedRectangleBorder(
//                               borderRadius:
//                                   radiusOnly(topRight: 18, topLeft: 18)),
//                           builder: (context) {
//                             return EditSetsExercise(
//                               exerciseId: exerciseId,
//                               setsList: setsList,
//                               setsIndex: setsList.length,
//                             );
//                           });
//                     },
//                     child: Container(
//                       decoration: BoxDecoration(
//                         color: appRedColor,
//                         borderRadius: BorderRadius.circular(10),
//                       ),
//                       child: Row(
//                         children: [
//                           const Icon(
//                             Icons.delete,
//                             size: 20,
//                             color: whiteColor,
//                           ),
//                           8.width,
//                           Text(
//                             languages.lblDelete,
//                             style: boldTextStyle(color: Colors.white),
//                           ),
//                         ],
//                       ).paddingSymmetric(vertical: 10, horizontal: 10),
//                     ).paddingSymmetric(vertical: 15),
//                   );
//                 }
//               }),
//             ),
//           ],
//         ),
//       ],
//     ).paddingSymmetric(vertical: 10).center();
//   }
// }

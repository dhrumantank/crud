import 'package:TheGymFaction/extensions/colors.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:TheGymFaction/screens/Home/books_reading_screen.dart';
import 'package:TheGymFaction/screens/Home/fast_intake_screen.dart';
import 'package:TheGymFaction/screens/Home/meditation_screen.dart';
import 'package:TheGymFaction/utils/app_images.dart';
import 'package:flutter/material.dart';

class FastingBooksReadingMeditation extends StatefulWidget {
  const FastingBooksReadingMeditation({super.key});

  @override
  State<FastingBooksReadingMeditation> createState() =>
      _FastingBooksReadingMeditationState();
}

class _FastingBooksReadingMeditationState
    extends State<FastingBooksReadingMeditation> {
  List<String> iconsName = [
    fasting,
    books,
    meditation,
  ];
  List<String> name = [
    "Fasting",
    "Books Reading",
    "Meditation",
  ];
  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Card(
      elevation: 1.0,
      color: whiteColor,
      shape: RoundedRectangleBorder(
        side: BorderSide(color: Colors.grey.shade300, width: 0.0),
        borderRadius: BorderRadius.circular(20),
      ),
      margin: EdgeInsets.zero,
      child: SizedBox(
        width: w,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Fasting,BooksReading And Meditation",
              style: boldTextStyle(size: 18),
            ).paddingSymmetric(horizontal: 10, vertical: 15),
            Wrap(
              children: List.generate(3, (index) {
                return GestureDetector(
                  onTap: () {
                    if (index == 0) {
                      const FastIntakeScreen().launch(context);
                    } else if (index == 1) {
                      const BooksReadingScreen().launch(context);
                    } else if (index == 2) {
                      const MeditationScreen().launch(context);
                    }
                  },
                  child: Container(
                    height: h * 0.11,
                    width: w * 0.22,
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.shade300,
                          spreadRadius: 1,
                          blurRadius: 5,
                        )
                      ],
                      color: whiteColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ImageIcon(
                          AssetImage(
                            iconsName[index],
                          ),
                        ),
                        5.height,
                        Text(
                          name[index],
                          style: boldTextStyle(size: 14),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ).paddingSymmetric(horizontal: 15, vertical: 10),
                );
              }),
            ).center(),
            20.height,
          ],
        ),
      ),
    ).paddingSymmetric(horizontal: 10);
  }
}

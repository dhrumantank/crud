import 'package:TheGymFaction/extensions/app_button.dart';
import 'package:TheGymFaction/extensions/colors.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:TheGymFaction/utils/app_common.dart';
import 'package:flutter/material.dart';

class CongratulationsDialog extends StatelessWidget {
  const CongratulationsDialog({super.key, required this.onTap});
  final Function onTap;

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        height: h * 0.5,
        width: w,
        decoration: BoxDecoration(
          color: whiteColor,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Container(
              width: w,
              height: h * 0.2,
              child: cachedImage(
                  "https://media.istockphoto.com/id/1451590744/vector/congratulations-beautiful-greeting-card-poster-banner.jpg?s=612x612&w=0&k=20&c=CD60HIUbZNFGDcVWOfBB90Zjp0weQaFBi5CjetIgRSw="),
            ),
            Text(
              "Congratulations",
              style: boldTextStyle(size: 22, color: Colors.green),
            ),
            Text(
              "You have successfully completed",
              style: boldTextStyle(size: 17, color: Colors.green),
              textAlign: TextAlign.center,
            ),
            AppButton(
              width: 100,
              text: "OK",
              onTap: onTap,
            ),
            10.height,
          ],
        ).paddingSymmetric(horizontal: 20),
      ),
    );
  }
}

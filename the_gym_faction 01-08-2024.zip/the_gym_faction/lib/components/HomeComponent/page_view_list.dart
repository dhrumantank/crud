import 'dart:math';

import 'package:TheGymFaction/extensions/colors.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:TheGymFaction/utils/app_images.dart';
import 'package:flutter/material.dart';

import '../../models/equipment_response.dart';
import '../../utils/app_common.dart';

class PageViewList extends StatefulWidget {
  const PageViewList({super.key, required this.equipmentModel});
  final List<EquipmentModel> equipmentModel;

  @override
  State<PageViewList> createState() => _PageViewListState();
}

class _PageViewListState extends State<PageViewList> {
  int colorIndex = 0;
  List<Color> color = [
    const Color(0xFFb8daff),
    const Color(0xFFc3e6cb),
    const Color(0xFFf5c6cb),
    const Color(0xFFffeeba),
    const Color(0xFFc6c8ca),
  ];
  Random random = new Random();
  void changeIndex() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      setState(() => colorIndex = random.nextInt(color.length));
    });
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Container(
      width: w,
      height: h * 0.25,
      child: PageView.builder(
        onPageChanged: (value) {
          changeIndex();
        },
        itemCount: widget.equipmentModel.length,
        itemBuilder: (context, index) {
          return Container(
            width: w * 0.9,
            height: h * 0.2,
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.shade200,
                  spreadRadius: 3,
                  blurRadius: 5,
                )
              ],
              borderRadius: BorderRadius.circular(20),
            ),
            child: Stack(
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      constraints: BoxConstraints(maxWidth: w * 0.35),
                      decoration: BoxDecoration(
                        color: black,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: Text(
                        "${widget.equipmentModel[index].title}",
                        style: boldTextStyle(color: whiteColor, size: 14),
                      ).paddingSymmetric(horizontal: 8, vertical: 4),
                    ),
                    5.height,
                    Row(
                      children: [
                        Container(
                          constraints: BoxConstraints(maxWidth: w * 0.35),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF3F3F5),
                            borderRadius: BorderRadius.circular(5),
                          ),
                          child: Text(
                            "${widget.equipmentModel[index].bodyPartsName}",
                            style: boldTextStyle(size: 14),
                          ).paddingSymmetric(vertical: 4, horizontal: 8),
                        ),
                        5.width,
                        Container(
                          height: 24,
                          width: 24,
                          child: cachedImage(
                            widget.equipmentModel[index].bodyPartsImage!,
                          ),
                        ),
                      ],
                    ),
                  ],
                ).paddingSymmetric(horizontal: 15),
                Align(
                  alignment: Alignment.topRight,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: cachedImage(
                      widget.equipmentModel[index].equipmentImage!,
                    ),
                  ),
                ),
                // Positioned(
                //   left: w * 0.4,
                //   bottom: -15,
                //   child: Container(
                //     decoration: BoxDecoration(
                //       borderRadius: BorderRadius.circular(20),
                //     ),
                //     child: Opacity(
                //       opacity: 0.3,
                //       child: CircleAvatar(
                //         radius: 150,
                //         backgroundColor:
                //             index % 2 == 0 ? appRedColor : Colors.blue,
                //       ),
                //     ),
                //   ),
                // ),
                Align(
                  alignment: Alignment.centerRight,
                  child: Container(
                    width: w * 0.5,
                    height: h * 0.23,
                    decoration: BoxDecoration(
                      color: color[colorIndex].withOpacity(0.3),
                      borderRadius: const BorderRadius.only(
                        bottomRight: Radius.circular(20),
                        topRight: Radius.circular(20),
                        topLeft: Radius.elliptical(5, 30),
                        bottomLeft: Radius.elliptical(110, 150),
                      ),
                    ),
                  ),
                ),
                const Row(
                  children: [
                    Image(
                      height: 25,
                      width: 25,
                      image: AssetImage(fireIcons),
                    ),
                    Image(
                      height: 25,
                      width: 25,
                      image: AssetImage(fireIcons),
                    ),
                    Image(
                      height: 25,
                      width: 25,
                      image: AssetImage(fireIcons),
                    ),
                  ],
                ).paddingSymmetric(horizontal: 10, vertical: 10),
              ],
            ),
          ).paddingSymmetric(horizontal: 20, vertical: 15);
        },
      ),
    );
  }
}

import 'package:TheGymFaction/extensions/colors.dart';
import 'package:TheGymFaction/extensions/extension_util/date_time_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/string_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../utils/app_colors.dart';
import '../../utils/app_images.dart';

class WorkoutDaysComponent extends StatefulWidget {
  const WorkoutDaysComponent({
    super.key,
    required this.workoutStates,
    required this.dayName,
    required this.id,
    required this.title,
    required this.indexId,
    this.todayDate,
    required this.onTap,
  });
  final String workoutStates;
  final String dayName;
  final String title;
  final int id;
  final int indexId;
  final DateTime? todayDate;
  final void Function() onTap;

  @override
  State<WorkoutDaysComponent> createState() => _WorkoutDaysComponentState();
}

class _WorkoutDaysComponentState extends State<WorkoutDaysComponent> {
  DateFormat format = DateFormat("dd-MM-yyyy");
  @override
  void initState() {
    print(widget.id);
    super.initState();
  }

  //0xFF4183FD
  @override
  Widget build(BuildContext context) {
    // final w = MediaQuery.of(context).size.width;
    // final h = MediaQuery.of(context).size.height;
    return CircleAvatar(
      radius: 32,
      backgroundColor: widget.todayDate!.isToday
          ? const Color(0xFF4183FD)
          : widget.workoutStates.isComplete
              ? const Color(0xFF8AD26C)
              : widget.workoutStates.isNotComplete
                  ? appRedColor
                  : widget.workoutStates.isPending
                      ? const Color(0xffEC7E4A)
                      : Colors.grey.shade300,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          5.height,
          Text(
            widget.dayName,
            style: TextStyle(
                color: !widget.workoutStates.isUpcoming
                    ? Colors.white
                    : Colors.black,
                fontWeight: FontWeight.w600),
          ),
          widget.workoutStates.isUpcoming ? 8.height : 10.height,
          CircleAvatar(
            radius: 8,
            backgroundColor: Colors.white,
            child: widget.todayDate!.isToday
                ? const Icon(
                    Icons.access_time,
                    size: 11,
                    weight: 4,
                    color: Color(0xFF4183FD),
                  )
                : widget.workoutStates.isComplete ||
                        widget.workoutStates.isNotComplete
                    ? ImageIcon(
                        widget.workoutStates.isNotComplete
                            ? const AssetImage(close)
                            : const AssetImage(check),
                        size: widget.workoutStates.isNotComplete ? 8 : 10,
                        color: widget.workoutStates.isNotComplete
                            ? appRedColor
                            : const Color(0xFF8AD26C),
                      )
                    : widget.workoutStates.isUpcoming
                        ? const ImageIcon(
                            AssetImage(upcoming),
                            size: 10,
                            color: black,
                          )
                        : const Icon(
                            Icons.access_time,
                            size: 11,
                            weight: 4,
                            color: Color(0xffEC7E4A),
                          ),
          ),
        ],
      ),
    ).onTap(widget.onTap);
  }
}

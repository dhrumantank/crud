import 'package:TheGymFaction/components/HomeComponent/show_one_time_dialog.dart';
import 'package:TheGymFaction/extensions/app_loading_button.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/list_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/models/today_exercises_model.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:TheGymFaction/utils/app_colors.dart';
import 'package:TheGymFaction/utils/app_common.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_card_swiper/flutter_card_swiper.dart';

import '../../extensions/app_text_field.dart';
import '../../extensions/colors.dart';
import '../../extensions/decorations.dart';
import '../../extensions/loader_widget.dart';
import '../../extensions/text_styles.dart';
import '../../main.dart';
import '../../utils/app_images.dart';

class CardDialogBox extends StatefulWidget {
  const CardDialogBox({super.key, required this.checkLength});
  final bool checkLength;

  @override
  State<CardDialogBox> createState() => _CardDialogBoxState();
}

class _CardDialogBoxState extends State<CardDialogBox> {
  CardSwiperController cardSwiperController = CardSwiperController();
  TodayExercises todayExercises = TodayExercises();
  List<Map<dynamic, dynamic>> setsController = [];
  bool exerciseEdit = false;
  bool check = false;
  int newSets = 3;
  int durationLength = 1;
  int selectValue = 0;
  Map durationController = {};
  Map durationFocusNode = {};

  @override
  void initState() {
    setsController.add({});
    setsController.add({});
    setsController.add({});
    fetchRemainingExercise();
    super.initState();
  }

  void fetchRemainingExercise() {
    setState(() {
      check = true;
    });
    getRemainingExerciseApi().then((value) {
      todayExercises = value;
      if (value.data![0].type == "duration") {
        fillDurationController(0);
      } else {
        fillController(0);
      }
      setState(() {
        check = false;
      });
      return null;
    });
  }

  void fillController(int index) {
    if (todayExercises.data![index].sets!.length < 3) {
      if (todayExercises.data![index].sets!.length == 2) {
        todayExercises.data![index].sets!.add(TodayExercisesSet(
          reps: "0",
          rest: "0",
          time: "0",
          weight: "0",
          type: "0",
        ));
      }
      if (todayExercises.data![index].sets!.length == 1) {
        todayExercises.data![index].sets!.add(TodayExercisesSet(
          reps: "0",
          rest: "0",
          time: "0",
          weight: "0",
          type: "0",
        ));
        todayExercises.data![index].sets!.add(TodayExercisesSet(
          reps: "0",
          rest: "0",
          time: "0",
          weight: "0",
          type: "0",
        ));
      }
      if (todayExercises.data![index].sets!.isEmpty) {
        todayExercises.data![index].sets!.add(TodayExercisesSet(
          reps: "0",
          rest: "0",
          time: "0",
          weight: "0",
          type: "0",
        ));
        todayExercises.data![index].sets!.add(TodayExercisesSet(
          reps: "0",
          rest: "0",
          time: "0",
          weight: "0",
          type: "0",
        ));
        todayExercises.data![index].sets!.add(TodayExercisesSet(
          reps: "0",
          rest: "0",
          time: "0",
          weight: "0",
          type: "0",
        ));
      }
    }
    setsController.clear();
    setState(() => newSets = todayExercises.data![index].sets!.length);
    todayExercises.data![index].sets!.forEachIndexed((element, index1) {
      setsController.add({});
      for (int i = 0; i < 5; i++) {
        setsController[index1].putIfAbsent(i, () => TextEditingController());
        if (i == 0) setsController[index1][i].text = element.reps.toString();
        if (i == 1) setsController[index1][i].text = element.weight.toString();
      }
      setState(() {});
    });
  }

  void fillDurationController(int index) {
    durationLength = todayExercises.data![index].duration!.length;
    durationController.clear();
    int index1 = 0;
    for (var element in todayExercises.data![index].duration!) {
      durationController.putIfAbsent(index1, () => TextEditingController());
      durationController[index1].text = element.duration.toString();
      setState(() => index1++);
    }
  }

  void getCompleteWorkout(int exerciseId, String status, bool newValue) {
    Map<String, dynamic> req = {
      "exercise_id": exerciseId,
      "status": status,
    };
    getCompleteWorkoutApi(req).then((value) {
      if (newValue == true) {
        cardSwiperController.swipe(CardSwiperDirection.right);
      } else {
        Navigator.pop(context);
        if (appStore.isShowOneTimeDialog) {
          showDialog(
              context: context,
              builder: (context) => const ShowOneTimeDialog());
        }
      }
      return;
    });
  }

  void save(int exerciseId, int index) {
    setState(() => exerciseEdit = false);
    List<Map<String, dynamic>> sets = [];
    setsController.forEachIndexed((element, index1) {
      sets.add({
        "reps": element[0].text,
        "rest": todayExercises.data![index].sets![index1].rest,
        "time": todayExercises.data![index].sets![index1].time,
        "weight": element[1].text,
        "type": todayExercises.data![index].sets![index1].type,
      });
      setState(() {});
    });
    Map<String, dynamic> req = {
      "exercise_id": exerciseId,
      "sets": sets,
    };
    getEditExerciseSetsResponse(req);
  }

  void saveDurationData(int exerciseId, int index) {
    setState(() => exerciseEdit = false);
    List durationList = [];
    int newIndex = 0;
    durationController.forEach((key, value) {
      durationList.add({
        "duration": value.text.toString(),
        "type": todayExercises.data![index].duration![newIndex].type.toString(),
      });
      setState(() => newIndex++);
    });
    Map<String, dynamic> req = {
      "exercise_id": exerciseId,
      "duration": durationList,
    };
    try {
      setEditExercisesDurationResponse(req).then((value) {
        toast(value["message"]);
      });
    } catch (e) {
      toast("Try Again");
    }
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Dialog(
      insetPadding: EdgeInsets.zero,
      backgroundColor: Colors.transparent,
      child: SizedBox(
        width: check
            ? w * 0.85
            : widget.checkLength
                ? w * 0.95
                : w * 0.85,
        height: check
            ? h * 0.6
            : widget.checkLength
                ? h * 0.7
                : h * 0.65,
        child: check == true
            ? Container(
                width: w * 0.85,
                height: h * 0.6,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Loader().center(),
              )
            : widget.checkLength
                ? CardSwiper(
                    scale: 0.5,
                    onSwipe: (previousIndex, currentIndex, direction) {
                      if ((todayExercises.data!.length - 1) > previousIndex) {
                        if (todayExercises.data![previousIndex + 1].type ==
                            "duration") {
                          fillDurationController(previousIndex + 1);
                        } else {
                          fillController(previousIndex + 1);
                        }
                      }
                      return true;
                    },
                    onEnd: () {
                      Navigator.pop(context);
                      if (appStore.isShowOneTimeDialog) {
                        showDialog(
                            context: context,
                            builder: (context) => const ShowOneTimeDialog());
                      }
                    },
                    controller: cardSwiperController,
                    isLoop: false,
                    cardsCount: todayExercises.data!.length,
                    cardBuilder:
                        (context, index, percentThresholdX, percentThresholdY) {
                      return Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Column(
                          children: [
                            Container(
                              height: h * 0.25,
                              decoration: BoxDecoration(
                                color: whiteColor,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Stack(
                                children: [
                                  Align(
                                    alignment: Alignment.topRight,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20),
                                      child: Image(
                                        width: w * 0.5,
                                        image: NetworkImage(todayExercises
                                            .data![index].exerciseImage!),
                                      ),
                                    ),
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      45.height,
                                      Row(
                                        children: [
                                          Container(
                                            constraints: BoxConstraints(
                                                maxWidth: w * 0.35),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFFF3F3F5),
                                              borderRadius:
                                                  BorderRadius.circular(5),
                                            ),
                                            child: Text(
                                              "${todayExercises.data![index].status}",
                                              style: boldTextStyle(size: 14),
                                            ).paddingSymmetric(
                                                vertical: 4, horizontal: 8),
                                          ),
                                          5.width,
                                        ],
                                      ),
                                      const Spacer(),
                                      Container(
                                        constraints:
                                            BoxConstraints(maxWidth: w * 0.35),
                                        decoration: BoxDecoration(
                                          color: black,
                                          borderRadius:
                                              BorderRadius.circular(5),
                                        ),
                                        child: Text(
                                          "${todayExercises.data![index].title}",
                                          style: boldTextStyle(
                                              color: whiteColor, size: 14),
                                        ).paddingSymmetric(
                                            horizontal: 8, vertical: 4),
                                      ),
                                      20.height,
                                    ],
                                  ).paddingSymmetric(horizontal: 15),
                                  Align(
                                    alignment: Alignment.centerRight,
                                    child: Container(
                                      width: w * 0.5,
                                      height: h * 0.25,
                                      decoration: BoxDecoration(
                                        color: index % 2 == 0
                                            ? appRedColor.withOpacity(0.3)
                                            : Colors.blue.withOpacity(0.3),
                                        borderRadius: const BorderRadius.only(
                                          // bottomRight: Radius.circular(20),
                                          topRight: Radius.circular(20),
                                          topLeft: Radius.elliptical(5, 30),
                                          bottomLeft:
                                              Radius.elliptical(110, 150),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const Row(
                                    children: [
                                      Image(
                                        height: 25,
                                        width: 25,
                                        image: AssetImage(fireIcons),
                                      ),
                                      Image(
                                        height: 25,
                                        width: 25,
                                        image: AssetImage(fireIcons),
                                      ),
                                      Image(
                                        height: 25,
                                        width: 25,
                                        image: AssetImage(fireIcons),
                                      ),
                                    ],
                                  ).paddingSymmetric(
                                      horizontal: 20, vertical: 15),
                                ],
                              ),
                            ),
                            // (h * 0.015).toInt().height,
                            todayExercises.data![index].type == "duration"
                                ? SizedBox(
                                    height: h * 0.3,
                                    child: SingleChildScrollView(
                                      child: Column(
                                        children: [
                                          ListView.builder(
                                            itemCount: durationLength,
                                            shrinkWrap: true,
                                            physics:
                                                const NeverScrollableScrollPhysics(),
                                            itemBuilder: (context, index) {
                                              durationController.putIfAbsent(
                                                  index,
                                                  () =>
                                                      TextEditingController());
                                              durationFocusNode.putIfAbsent(
                                                  index, () => FocusNode());
                                              return AppTextField(
                                                onTap: () {
                                                  setState(() =>
                                                      exerciseEdit = true);
                                                  durationFocusNode[index]
                                                      .unfocus();
                                                  showDialog(
                                                    context: context,
                                                    builder: (context) {
                                                      return Dialog(
                                                        backgroundColor:
                                                            Colors.transparent,
                                                        child: Container(
                                                          width: w * 0.6,
                                                          height: h * 0.3,
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Colors.white,
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        20),
                                                          ),
                                                          child: Column(
                                                            children: [
                                                              SizedBox(
                                                                height: h * 0.2,
                                                                child:
                                                                    CupertinoPicker(
                                                                  itemExtent:
                                                                      60,
                                                                  onSelectedItemChanged:
                                                                      (int
                                                                          value) {
                                                                    selectValue =
                                                                        value;
                                                                    setState(
                                                                        () {});
                                                                  },
                                                                  children: List
                                                                      .generate(
                                                                          60,
                                                                          (index) {
                                                                    return Center(
                                                                      child:
                                                                          Text(
                                                                        "${index + 1} Minute",
                                                                        style:
                                                                            boldTextStyle(),
                                                                      ),
                                                                    );
                                                                  }),
                                                                ),
                                                              ),
                                                              (h * 0.02)
                                                                  .toInt()
                                                                  .height,
                                                              AppLoadingButton(
                                                                isLoading:
                                                                    false,
                                                                onTap: () {
                                                                  durationController[
                                                                              index]
                                                                          .text =
                                                                      "${selectValue + 1}";
                                                                  setState(
                                                                      () {});
                                                                  Navigator.pop(
                                                                      context);
                                                                },
                                                                text: "OK",
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      );
                                                    },
                                                  );
                                                },
                                                focus: durationFocusNode[index],
                                                controller:
                                                    durationController[index],
                                                textFieldType:
                                                    TextFieldType.NUMBER,
                                                suffix: const Text(
                                                  "Minute",
                                                  textAlign: TextAlign.center,
                                                ).paddingSymmetric(
                                                    vertical: 16,
                                                    horizontal: 10),
                                                decoration:
                                                    defaultInputDecoration(
                                                        context,
                                                        label: "Minute"),
                                                autoFocus: false,
                                                isValidationRequired: true,
                                              ).paddingSymmetric(
                                                  vertical: 5, horizontal: 20);
                                            },
                                          ),
                                        ],
                                      ),
                                    ),
                                  )
                                : Container(
                                    height: h * 0.3,
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          color: Colors.grey.shade300),
                                    ),
                                    child: SingleChildScrollView(
                                      child: Column(
                                        children: [
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceAround,
                                            children: [
                                              Text(
                                                "${languages.reps} (x) ",
                                                style: boldTextStyle(),
                                              ),
                                              Text(
                                                "${languages.lblWeight} (Kg)",
                                                style: boldTextStyle(),
                                              ),
                                            ],
                                          ),
                                          ListView.builder(
                                            itemCount: newSets,
                                            shrinkWrap: true,
                                            physics:
                                                const NeverScrollableScrollPhysics(),
                                            itemBuilder: (context, index1) {
                                              return GridView.builder(
                                                itemCount: 2,
                                                shrinkWrap: true,
                                                physics:
                                                    const NeverScrollableScrollPhysics(),
                                                gridDelegate:
                                                    const SliverGridDelegateWithFixedCrossAxisCount(
                                                  crossAxisCount: 2,
                                                  mainAxisExtent: 55,
                                                ),
                                                itemBuilder: (context, index) {
                                                  setsController[index1]
                                                      .putIfAbsent(
                                                          index,
                                                          () =>
                                                              TextEditingController());
                                                  return SizedBox(
                                                    width: w * 0.3,
                                                    child: AppTextField(
                                                      onChanged: (p0) {
                                                        setState(() =>
                                                            exerciseEdit =
                                                                true);
                                                      },
                                                      controller:
                                                          setsController[index1]
                                                              [index],
                                                      textFieldType:
                                                          TextFieldType.NUMBER,
                                                      suffix: Text(
                                                        index % 2 == 0
                                                            ? "X"
                                                            : "Kg",
                                                        textAlign:
                                                            TextAlign.center,
                                                      ).paddingSymmetric(
                                                          vertical: 16),
                                                      decoration:
                                                          defaultInputDecoration(
                                                              context,
                                                              label: index %
                                                                          2 ==
                                                                      0
                                                                  ? "Reps"
                                                                  : "Weight"),
                                                      autoFocus: false,
                                                      isValidationRequired:
                                                          true,
                                                    ),
                                                  ).paddingSymmetric(
                                                      horizontal: 10);
                                                },
                                              );
                                            },
                                          )
                                        ],
                                      ).paddingSymmetric(vertical: 10),
                                    ),
                                  ),
                            (h * 0.01).toInt().height,
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                MaterialButton(
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  color: appRedColor,
                                  onPressed: () {
                                    cardSwiperController
                                        .swipe(CardSwiperDirection.left);
                                  },
                                  child: Text(
                                    "Not Done",
                                    style: boldTextStyle(color: whiteColor),
                                  ),
                                ),
                                MaterialButton(
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  color: black,
                                  onPressed: () {
                                    getCompleteWorkout(
                                      todayExercises.data![index].id!,
                                      "complete",
                                      true,
                                    );
                                    if (exerciseEdit) {
                                      if (todayExercises.data![index].type ==
                                          "duration") {
                                        saveDurationData(
                                          todayExercises.data![index].id!,
                                          index,
                                        );
                                      } else {
                                        save(
                                          todayExercises.data![index].id!,
                                          index,
                                        );
                                      }
                                    }
                                  },
                                  child: Text(
                                    "Completed",
                                    style: boldTextStyle(color: whiteColor),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  )
                : Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      children: [
                        Container(
                          height: h * 0.25,
                          decoration: BoxDecoration(
                            color: whiteColor,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Stack(
                            children: [
                              Align(
                                alignment: Alignment.topRight,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: Image(
                                    width: w * 0.5,
                                    image: NetworkImage(
                                        todayExercises.data![0].exerciseImage!),
                                  ),
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  45.height,
                                  Row(
                                    children: [
                                      Container(
                                        constraints:
                                            BoxConstraints(maxWidth: w * 0.35),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFF3F3F5),
                                          borderRadius:
                                              BorderRadius.circular(5),
                                        ),
                                        child: Text(
                                          "${todayExercises.data![0].status}",
                                          style: boldTextStyle(size: 14),
                                        ).paddingSymmetric(
                                            vertical: 4, horizontal: 8),
                                      ),
                                      5.width,
                                      // Container(
                                      //   height: 26,
                                      //   width: 26,
                                      //   child: Image(
                                      //     image: NetworkImage(
                                      //         todayExercises.data![index].bodyPartsImage!),
                                      //   ),
                                      // ),
                                    ],
                                  ),
                                  const Spacer(),
                                  Container(
                                    constraints:
                                        BoxConstraints(maxWidth: w * 0.35),
                                    decoration: BoxDecoration(
                                      color: black,
                                      borderRadius: BorderRadius.circular(5),
                                    ),
                                    child: Text(
                                      "${todayExercises.data![0].title}",
                                      style: boldTextStyle(
                                          color: whiteColor, size: 14),
                                    ).paddingSymmetric(
                                        horizontal: 8, vertical: 4),
                                  ),
                                  20.height,
                                ],
                              ).paddingSymmetric(horizontal: 15),
                              Align(
                                alignment: Alignment.centerRight,
                                child: Container(
                                  width: w * 0.5,
                                  height: h * 0.25,
                                  decoration: BoxDecoration(
                                    color: Colors.blue.withOpacity(0.3),
                                    borderRadius: const BorderRadius.only(
                                      // bottomRight: Radius.circular(20),
                                      topRight: Radius.circular(20),
                                      topLeft: Radius.elliptical(5, 30),
                                      bottomLeft: Radius.elliptical(110, 150),
                                    ),
                                  ),
                                ),
                              ),
                              const Row(
                                children: [
                                  Image(
                                    height: 25,
                                    width: 25,
                                    image: AssetImage(fireIcons),
                                  ),
                                  Image(
                                    height: 25,
                                    width: 25,
                                    image: AssetImage(fireIcons),
                                  ),
                                  Image(
                                    height: 25,
                                    width: 25,
                                    image: AssetImage(fireIcons),
                                  ),
                                ],
                              ).paddingSymmetric(horizontal: 20, vertical: 15),
                            ],
                          ),
                        ),
                        // (h * 0.015).toInt().height,
                        todayExercises.data!.first.type == "duration"
                            ? SizedBox(
                                height: h * 0.3,
                                child: SingleChildScrollView(
                                  child: Column(
                                    children: [
                                      ListView.builder(
                                        itemCount: durationLength,
                                        shrinkWrap: true,
                                        physics:
                                            const NeverScrollableScrollPhysics(),
                                        itemBuilder: (context, index) {
                                          durationController.putIfAbsent(index,
                                              () => TextEditingController());
                                          durationFocusNode.putIfAbsent(
                                              index, () => FocusNode());
                                          return AppTextField(
                                            onTap: () {
                                              setState(
                                                  () => exerciseEdit = true);
                                              durationFocusNode[index]
                                                  .unfocus();
                                              showDialog(
                                                context: context,
                                                builder: (context) {
                                                  return Dialog(
                                                    backgroundColor:
                                                        Colors.transparent,
                                                    child: Container(
                                                      width: w * 0.6,
                                                      height: h * 0.3,
                                                      decoration: BoxDecoration(
                                                        color: Colors.white,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(20),
                                                      ),
                                                      child: Column(
                                                        children: [
                                                          SizedBox(
                                                            height: h * 0.2,
                                                            child:
                                                                CupertinoPicker(
                                                              itemExtent: 60,
                                                              onSelectedItemChanged:
                                                                  (int value) {
                                                                selectValue =
                                                                    value;
                                                                setState(() {});
                                                              },
                                                              children:
                                                                  List.generate(
                                                                      60,
                                                                      (index) {
                                                                return Center(
                                                                  child: Text(
                                                                    "${index + 1} Minute",
                                                                    style:
                                                                        boldTextStyle(),
                                                                  ),
                                                                );
                                                              }),
                                                            ),
                                                          ),
                                                          (h * 0.02)
                                                              .toInt()
                                                              .height,
                                                          AppLoadingButton(
                                                            isLoading: false,
                                                            onTap: () {
                                                              durationController[
                                                                          index]
                                                                      .text =
                                                                  "${selectValue + 1}";
                                                              setState(() {});
                                                              Navigator.pop(
                                                                  context);
                                                            },
                                                            text: "OK",
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  );
                                                },
                                              );
                                            },
                                            focus: durationFocusNode[index],
                                            controller:
                                                durationController[index],
                                            textFieldType: TextFieldType.NUMBER,
                                            suffix: const Text(
                                              "Minute",
                                              textAlign: TextAlign.center,
                                            ).paddingSymmetric(
                                                vertical: 16, horizontal: 10),
                                            decoration: defaultInputDecoration(
                                                context,
                                                label: "Minute"),
                                            autoFocus: false,
                                            isValidationRequired: true,
                                          ).paddingSymmetric(
                                              vertical: 5, horizontal: 20);
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              )
                            : Container(
                                height: h * 0.3,
                                decoration: BoxDecoration(
                                  border:
                                      Border.all(color: Colors.grey.shade300),
                                ),
                                child: SingleChildScrollView(
                                  child: Column(
                                    children: [
                                      // Row(
                                      //   mainAxisAlignment:
                                      //       MainAxisAlignment.spaceEvenly,
                                      //   children: [
                                      //     Text(
                                      //       "${languages.reps} (x) ",
                                      //       style: boldTextStyle(),
                                      //     ).paddingSymmetric(horizontal: 10),
                                      //     CustomTextField(
                                      //         onChanged: (value) {
                                      //           setState(() => exerciseEdit = true);
                                      //         },
                                      //         controller: reps1Controller),
                                      //     CustomTextField(
                                      //         onChanged: (value) {
                                      //           setState(() => exerciseEdit = true);
                                      //         },
                                      //         controller: reps2Controller),
                                      //     CustomTextField(
                                      //         onChanged: (value) {
                                      //           setState(() => exerciseEdit = true);
                                      //         },
                                      //         controller: reps3Controller),
                                      //   ],
                                      // ),
                                      // 4.height,
                                      // Divider(color: Colors.grey.shade500),
                                      // 4.height,
                                      // Row(
                                      //   mainAxisAlignment:
                                      //       MainAxisAlignment.spaceEvenly,
                                      //   children: [
                                      //     Text(
                                      //       "${languages.lblWeight} (Kg)",
                                      //       style: boldTextStyle(),
                                      //     ),
                                      //     CustomTextField(
                                      //         onChanged: (value) {
                                      //           setState(() => exerciseEdit = true);
                                      //         },
                                      //         controller: weight1Controller),
                                      //     CustomTextField(
                                      //         onChanged: (value) {
                                      //           setState(() => exerciseEdit = true);
                                      //         },
                                      //         controller: weight2Controller),
                                      //     CustomTextField(
                                      //         onChanged: (value) {
                                      //           setState(() => exerciseEdit = true);
                                      //         },
                                      //         controller: weight3Controller),
                                      //   ],
                                      // ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: [
                                          Text(
                                            "${languages.reps} (x) ",
                                            style: boldTextStyle(),
                                          ),
                                          Text(
                                            "${languages.lblWeight} (Kg)",
                                            style: boldTextStyle(),
                                          ),
                                        ],
                                      ),
                                      ListView.builder(
                                        itemCount: newSets,
                                        shrinkWrap: true,
                                        physics:
                                            const NeverScrollableScrollPhysics(),
                                        itemBuilder: (context, index1) {
                                          return GridView.builder(
                                            itemCount: 2,
                                            shrinkWrap: true,
                                            physics:
                                                const NeverScrollableScrollPhysics(),
                                            gridDelegate:
                                                const SliverGridDelegateWithFixedCrossAxisCount(
                                              crossAxisCount: 2,
                                              mainAxisExtent: 55,
                                            ),
                                            itemBuilder: (context, index) {
                                              setsController[index1].putIfAbsent(
                                                  index,
                                                  () =>
                                                      TextEditingController());
                                              return SizedBox(
                                                width: w * 0.3,
                                                child: AppTextField(
                                                  controller:
                                                      setsController[index1]
                                                          [index],
                                                  textFieldType:
                                                      TextFieldType.NUMBER,
                                                  suffix: Text(
                                                    index % 2 == 0 ? "X" : "Kg",
                                                    textAlign: TextAlign.center,
                                                  ).paddingSymmetric(
                                                      vertical: 16),
                                                  decoration:
                                                      defaultInputDecoration(
                                                          context,
                                                          label: index % 2 == 0
                                                              ? "Reps"
                                                              : "Weight"),
                                                  autoFocus: false,
                                                  isValidationRequired: true,
                                                ),
                                              ).paddingSymmetric(
                                                  horizontal: 10);
                                            },
                                          );
                                        },
                                      )
                                    ],
                                  ).paddingSymmetric(vertical: 10),
                                ),
                              ),
                        (h * 0.01).toInt().height,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            MaterialButton(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              color: appRedColor,
                              onPressed: () {
                                Navigator.pop(context);
                                if (appStore.isShowOneTimeDialog) {
                                  showDialog(
                                      context: context,
                                      builder: (context) =>
                                          const ShowOneTimeDialog());
                                }
                              },
                              child: Text(
                                "Not Done",
                                style: boldTextStyle(color: whiteColor),
                              ),
                            ),
                            MaterialButton(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              color: black,
                              onPressed: () {
                                getCompleteWorkout(
                                  todayExercises.data![0].id!,
                                  "complete",
                                  false,
                                );
                                if (exerciseEdit) {
                                  if (todayExercises.data!.first.type ==
                                      "duration") {
                                    saveDurationData(
                                      todayExercises.data![0].id!,
                                      0,
                                    );
                                  } else {
                                    save(
                                      todayExercises.data![0].id!,
                                      0,
                                    );
                                  }
                                }
                              },
                              child: Text(
                                "Completed",
                                style: boldTextStyle(color: whiteColor),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
      ),
    );
  }
}

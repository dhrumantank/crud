import 'package:TheGymFaction/extensions/app_loading_button.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:flutter/material.dart';

import '../../extensions/app_text_field.dart';
import '../../extensions/colors.dart';
import '../../extensions/decorations.dart';
import '../../extensions/text_styles.dart';
import '../../main.dart';
import '../../models/exercise_detail_response.dart';
import '../../utils/app_colors.dart';

class EditSetsExercise extends StatefulWidget {
  const EditSetsExercise(
      {super.key,
      required this.setsIndex,
      required this.setsList,
      required this.exerciseId});
  final int setsIndex;
  final List<Sets> setsList;
  final int exerciseId;

  @override
  State<EditSetsExercise> createState() => _EditSetsExerciseState();
}

class _EditSetsExerciseState extends State<EditSetsExercise> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  List<Map<dynamic, dynamic>> setsController = [];
  bool addData = false;
  double height = 0.5;
  int newSets = 3;
  @override
  void initState() {
    if (widget.setsList.length <= 2) {
      setsController.add({});
      setsController.add({});
      setsController.add({});
    } else {
      setState(() => newSets = widget.setsList.length);
    }
    getSets();
    super.initState();
  }

  void getSets() {
    int index = 0;
    for (var element in widget.setsList) {
      setsController.add({});
      for (int i = 0; i < 5; i++) {
        setsController[index].putIfAbsent(i, () => TextEditingController());
        if (i == 0) setsController[index][i].text = element.reps.toString();
        if (i == 1) setsController[index][i].text = element.weight.toString();
      }
      if (index >= 3) {
        height += 0.08;
      }
      setState(() => index++);
    }
  }

  void save() {
    setState(() => addData = true);
    int index = 0;
    List<Map<String, dynamic>> sets = [];
    for (var element in setsController) {
      late Map<String, dynamic> repsData;
      if (index < widget.setsList.length) {
        repsData = {
          "reps": element[0].text,
          "weight": element[1].text,
          "time": widget.setsList[index].time.toString(),
          "rest": widget.setsList[index].rest.toString(),
          "type": widget.setsList[index].type.toString(),
        };
      } else {
        repsData = {
          "reps": element[0].text,
          "weight": element[1].text,
          "time": "30",
          "rest": "30",
          "type": "1",
        };
      }
      sets.add(repsData);
      setState(() => index++);
    }
    Map<String, dynamic> req = {
      "exercise_id": widget.exerciseId,
      "sets": sets,
    };
    try {
      getEditExerciseSetsResponse(req).then((value) {
        Navigator.pop(context);
        setState(() => addData = false);
      });
    } catch (e) {
      setState(() => addData = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        width: w,
        height: h * height,
        child: SingleChildScrollView(
          child: Column(
            children: [
              (h * 0.02).toInt().height,
              Row(
                children: [
                  if (newSets > 3)
                    (w * 0.1).toInt().width
                  else
                    (w * 0.16).toInt().width,
                  Container(
                    alignment: Alignment.center,
                    width: w * 0.25,
                    decoration: BoxDecoration(
                      color: appStore.isDarkMode
                          ? cardDarkColor
                          : GreyLightColor.withOpacity(0.4),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      languages.reps,
                      style: boldTextStyle(),
                    ).paddingSymmetric(vertical: 15, horizontal: 10),
                  ),
                  if (newSets > 3)
                    (w * 0.15).toInt().width
                  else
                    (w * 0.2).toInt().width,
                  Container(
                    alignment: Alignment.center,
                    width: w * 0.25,
                    decoration: BoxDecoration(
                      color: appStore.isDarkMode
                          ? cardDarkColor
                          : GreyLightColor.withOpacity(0.4),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      languages.lblWeight,
                      style: boldTextStyle(),
                    ).paddingSymmetric(vertical: 15, horizontal: 10),
                  ),
                  if (newSets > 3) (w * 0.06).toInt().width,
                  if (newSets > 3)
                    Container(
                      alignment: Alignment.center,
                      width: w * 0.16,
                      decoration: BoxDecoration(
                        color: appStore.isDarkMode
                            ? cardDarkColor
                            : GreyLightColor.withOpacity(0.4),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.delete)
                          .paddingSymmetric(vertical: 15),
                    ),
                ],
              ),
              (h * 0.02).toInt().height,
              Form(
                key: formKey,
                child: ListView.builder(
                  itemCount: newSets,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index1) {
                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: newSets > 3
                          ? MainAxisAlignment.spaceAround
                          : MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: newSets > 3 ? w * 0.8 : w * 0.9,
                          child: GridView.builder(
                            itemCount: 2,
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              mainAxisExtent: 70,
                            ),
                            itemBuilder: (context, index) {
                              setsController[index1].putIfAbsent(
                                  index, () => TextEditingController());
                              return SizedBox(
                                width: w * 0.3,
                                child: AppTextField(
                                  controller: setsController[index1][index],
                                  textFieldType: TextFieldType.NUMBER,
                                  suffix: Text(
                                    index % 2 == 0 ? "X" : "Kg",
                                    textAlign: TextAlign.center,
                                  ).paddingSymmetric(vertical: 16),
                                  decoration: defaultInputDecoration(context,
                                      label:
                                          index % 2 == 0 ? "Reps" : "Weight"),
                                  autoFocus: false,
                                  isValidationRequired: true,
                                ),
                              ).paddingSymmetric(horizontal: 10);
                            },
                          ),
                        ),
                        if (index1 < 3)
                          SizedBox(width: newSets > 3 ? w * 0.1 : 0)
                        else
                          GestureDetector(
                            onTap: () {
                              setState(() {
                                height -= 0.08;
                                newSets--;
                                setsController.removeAt(index1);
                              });
                            },
                            child: Container(
                              width: w * 0.1,
                              height: h * 0.04,
                              decoration: BoxDecoration(
                                color: Colors.red,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Icon(
                                Icons.delete,
                                color: Colors.white,
                              ),
                            ),
                          )
                      ],
                    );
                  },
                ),
              ),
              if (newSets <= 10)
                Align(
                  alignment: Alignment.topRight,
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        height += 0.08;
                        newSets++;
                        setsController.add({});
                      });
                    },
                    child: Container(
                      width: w * 0.1,
                      height: h * 0.04,
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(
                        Icons.add,
                        color: Colors.white,
                      ),
                    ),
                  ).paddingSymmetric(horizontal: 10),
                ),
              (h * 0.03).toInt().height,
              AppLoadingButton(
                isLoading: addData,
                width: w * 0.5,
                onTap: () {
                  if (formKey.currentState!.validate()) {
                    save();
                  }
                },
                child: Text(
                  "Edit",
                  style: boldTextStyle(color: whiteColor),
                ),
              ).center(),
            ],
          ),
        ),
      ),
    );
  }
}

import 'dart:ui';

import 'package:TheGymFaction/utils/app_common.dart';
import 'package:flutter/material.dart';

import '../../../extensions/decorations.dart';
import '../../../extensions/extension_util/context_extensions.dart';
import '../../../extensions/extension_util/int_extensions.dart';
import '../../../extensions/extension_util/string_extensions.dart';
import '../../../extensions/extension_util/widget_extensions.dart';
import '../../extensions/colors.dart';
import '../../extensions/text_styles.dart';
import '../../main.dart';
import '../../models/equipment_response.dart';
import '../../screens/Home/Exercise/exercise_list_screen.dart';
import '../../screens/no_data_screen.dart';
import '../../utils/app_images.dart';

class EquipmentComponent extends StatefulWidget {
  final bool isGrid;
  final bool isSearch;
  final int? isEquId;
  final Function? onCall;
  final EquipmentModel? mEquipmentModel;
  final EquipmentResponse2Datum? mEquipmentModel2;
  final Color? randomColor;

  const EquipmentComponent({
    super.key,
    this.mEquipmentModel,
    this.isGrid = false,
    this.isSearch = false,
    this.isEquId,
    this.onCall,
    this.mEquipmentModel2,
    this.randomColor,
  });

  @override
  State<EquipmentComponent> createState() => _EquipmentComponentState();
}

class _EquipmentComponentState extends State<EquipmentComponent> {
  bool isEquipment = false;
  List<int>? mId = [];
  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    double width = widget.isGrid == true
        ? (context.width() - 48) / 3.2
        : context.width() * 0.285;
    double height = widget.isGrid == true ? 140 : 130;
    if (widget.mEquipmentModel != null) {
      return Column(
        children: [
          Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(color: Colors.grey.shade200, spreadRadius: 1)
                ]),
            child: Stack(
              alignment: Alignment.bottomCenter,
              children: [
                cachedImage(
                  widget.mEquipmentModel!.equipmentImage.validate(),
                  height: height,
                  width: width,
                  fit: BoxFit.cover,
                ).cornerRadiusWithClipRRect(16),
                ClipRRect(
                  borderRadius: radius(12),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                    child: Container(
                      width: width,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 12),
                      decoration: boxDecorationWithRoundedCorners(
                          backgroundColor:
                              Colors.grey.shade100.withOpacity(0.5)),
                      child: Text(widget.mEquipmentModel!.title.validate(),
                              style:
                                  boldTextStyle(color: Colors.black, size: 13))
                          .center(),
                    ),
                  ),
                )
              ],
            ).onTap(() {
              ExerciseListScreen(
                      mTitle: widget.mEquipmentModel!.title.validate(),
                      isEquipment: true,
                      id: widget.mEquipmentModel!.id.validate())
                  .launch(context);
            }),
          ),
        ],
      );
    } else if (widget.mEquipmentModel2 != null) {
      return Column(
        children: [
          Container(
            width: w * 0.9,
            height: h * 0.2,
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.shade200,
                  spreadRadius: 3,
                  blurRadius: 5,
                )
              ],
              borderRadius: BorderRadius.circular(20),
            ),
            child: Stack(
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      constraints: BoxConstraints(maxWidth: w * 0.35),
                      decoration: BoxDecoration(
                        color: black,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: Text(
                        widget.mEquipmentModel2!.title.toString(),
                        style: boldTextStyle(color: whiteColor, size: 14),
                      ).paddingSymmetric(horizontal: 8, vertical: 4),
                    ),
                    5.height,
                    Row(
                      children: [
                        Container(
                          constraints: BoxConstraints(maxWidth: w * 0.35),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF3F3F5),
                            borderRadius: BorderRadius.circular(5),
                          ),
                          child: Text(
                            widget.mEquipmentModel2!.bodyPartsName ??
                                "".toString(),
                            style: boldTextStyle(size: 14),
                          ).paddingSymmetric(vertical: 4, horizontal: 8),
                        ),
                        5.width,
                        SizedBox(
                          height: 26,
                          width: 26,
                          child: cachedImage(
                            widget.mEquipmentModel2!.bodyPartsImage ?? "",
                          ),
                        ),
                      ],
                    ),
                  ],
                ).paddingSymmetric(horizontal: 15),
                Align(
                  alignment: Alignment.topRight,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: cachedImage(
                      widget.mEquipmentModel2!.equipmentImage!,
                    ),
                  ),
                ),
                // Positioned(
                //   left: w * 0.4,
                //   bottom: -15,
                //   child: Container(
                //     decoration: BoxDecoration(
                //       borderRadius: BorderRadius.circular(20),
                //     ),
                //     child: Opacity(
                //       opacity: 0.3,
                //       child: CircleAvatar(
                //         radius: 150,
                //         backgroundColor: Colors.blue,
                //       ),
                //     ),
                //   ),
                // ),
                Align(
                  alignment: Alignment.centerRight,
                  child: Container(
                    width: w * 0.5,
                    height: h * 0.2,
                    decoration: BoxDecoration(
                      color: widget.randomColor!.withOpacity(0.3),
                      borderRadius: const BorderRadius.only(
                        bottomRight: Radius.circular(20),
                        topRight: Radius.circular(20),
                        topLeft: Radius.elliptical(5, 30),
                        bottomLeft: Radius.elliptical(110, 150),
                      ),
                    ),
                  ),
                ),
                const Row(
                  children: [
                    Image(
                      height: 25,
                      width: 25,
                      image: AssetImage(fireIcons),
                    ),
                    Image(
                      height: 25,
                      width: 25,
                      image: AssetImage(fireIcons),
                    ),
                    Image(
                      height: 25,
                      width: 25,
                      image: AssetImage(fireIcons),
                    ),
                  ],
                ).paddingSymmetric(horizontal: 10, vertical: 10),
              ],
            ),
          ).onTap(() {
            // ExerciseListScreen(
            //         mTitle: widget.mEquipmentModel2!.title.validate(),
            //         isEquipment: true,
            //         id: widget.mEquipmentModel2!.id.validate())
            //     .launch(context);
          }).paddingSymmetric(vertical: 8),
        ],
      );
    } else {
      return NoDataScreen(mTitle: languages.lblExerciseNoFound)
          .visible(!appStore.isLoading);
    }
  }
}

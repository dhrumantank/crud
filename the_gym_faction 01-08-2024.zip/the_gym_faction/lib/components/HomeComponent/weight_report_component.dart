import 'package:TheGymFaction/extensions/app_button.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shimmer/shimmer.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../extensions/colors.dart';
import '../../extensions/text_styles.dart';
import '../../models/weight_graph_model.dart';

class WeightReport extends StatelessWidget {
  const WeightReport(
      {super.key, required this.chartData, this.onTap, required this.check});
  final List<WeightGraphDatum> chartData;
  final Function? onTap;
  final bool check;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return check
        ? const ChartShimmerEffect()
        : chartData.isEmpty
            ? Stack(
                children: [
                  WeightGraphCard(chartData: const [], onTap: onTap),
                  Positioned(
                    left: w * 0.45,
                    top: h * 0.23,
                    child: Text(
                      "No Data",
                      style: boldTextStyle(size: 14),
                    ),
                  ),
                ],
              )
            : WeightGraphCard(chartData: chartData, onTap: onTap);
  }
}

class WeightGraphCard extends StatelessWidget {
  const WeightGraphCard({super.key, required this.chartData, this.onTap});
  final List<WeightGraphDatum> chartData;
  final Function? onTap;

  @override
  Widget build(BuildContext context) {
    DateFormat dateFormat = DateFormat("dd-MM");
    return Card(
      elevation: 1.0,
      color: whiteColor,
      shape: RoundedRectangleBorder(
        side: BorderSide(color: Colors.grey.shade200, width: 0.0),
        borderRadius: BorderRadius.circular(20),
      ),
      margin: EdgeInsets.zero,
      child: Column(
        children: [
          Row(
            children: [
              Text(
                "Weight Report",
                style: boldTextStyle(size: 18),
              ).paddingSymmetric(horizontal: 20, vertical: 10),
              const Spacer(),
              AppButton(
                onTap: onTap,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Text(
                  "Enter Your Weight",
                  style: boldTextStyle(size: 12, color: whiteColor),
                ),
              ),
              10.width,
            ],
          ),
          SfCartesianChart(
            tooltipBehavior: TooltipBehavior(enable: true),
            plotAreaBorderWidth: 0,
            primaryXAxis: const CategoryAxis(
              majorGridLines: MajorGridLines(width: 0),
              labelStyle: TextStyle(),
            ),
            primaryYAxis: const NumericAxis(
              minimum: 0,
              maximum: 100,
              interval: 5,
              labelFormat: r'{value} Kg',
              majorGridLines: MajorGridLines(color: Colors.transparent),
              labelStyle: TextStyle(),
            ),
            series: <SplineSeries<WeightGraphDatum, dynamic>>[
              SplineSeries<WeightGraphDatum, dynamic>(
                dataSource: chartData,
                xValueMapper: (WeightGraphDatum data, _) =>
                    dateFormat.format(DateTime.parse(data.date.toString())),
                yValueMapper: (WeightGraphDatum data, _) =>
                    double.parse(data.value.toString()),
                name: 'Weight',
                color: black,
                markerSettings: const MarkerSettings(
                  isVisible: true,
                ),
              ),
            ],
          ).paddingSymmetric(vertical: 10),
          10.height,
          Text(
            "Put Your Weight",
            style: boldTextStyle(size: 18),
          ),
          10.height,
        ],
      ),
    ).paddingSymmetric(horizontal: 15);
  }
}

class ChartShimmerEffect extends StatelessWidget {
  const ChartShimmerEffect({super.key});

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Shimmer.fromColors(
      baseColor: Colors.grey.shade200,
      highlightColor: Colors.grey.shade400,
      child: Container(
        width: w * 0.88,
        height: h * 0.4,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: Colors.grey.shade200,
        ),
      ),
    ).center();
  }
}

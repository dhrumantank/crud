import 'package:TheGymFaction/extensions/app_loading_button.dart';
import 'package:TheGymFaction/extensions/decorations.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/network/rest_api.dart';
import 'package:TheGymFaction/utils/app_colors.dart';
import 'package:TheGymFaction/utils/app_common.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../extensions/app_text_field.dart';
import '../../extensions/text_styles.dart';

class EditExercisesDuration extends StatefulWidget {
  const EditExercisesDuration(
      {super.key, required this.exerciseId, required this.durationData});
  final int exerciseId;
  final List durationData;

  @override
  State<EditExercisesDuration> createState() => _EditExercisesDurationState();
}

class _EditExercisesDurationState extends State<EditExercisesDuration> {
  int selectValue = 0;
  int durationLength = 1;
  bool isLoading = false;
  bool addData = false;
  double height = 0.4;
  Map durationController = {};
  Map durationFocusNode = {};
  int controllerLength = 0;
  List controllerKey = [];

  @override
  void initState() {
    getData();
    setState(() => durationLength = widget.durationData.length);
    super.initState();
  }

  void getData() {
    int index = 0;
    for (var element in widget.durationData) {
      controllerKey.add(controllerLength);
      durationController.putIfAbsent(
          controllerKey[index], () => TextEditingController());
      durationController[controllerKey[index]].text =
          element.duration.toString();
      setState(() => index++);
    }
  }

  void setEditExercisesDurationData() {
    int index = 0;
    List durationList = [];
    durationController.forEach((key, value) {
      if (index < widget.durationData.length) {
        durationList.add({
          "duration": value.text.toString(),
          "type": widget.durationData[index].type.toString(),
        });
      } else {
        durationList.add({
          "duration": value.text.toString(),
          "type": index == 0 ? "0" : "1",
        });
      }
      setState(() => index++);
    });

    setState(() => isLoading = true);
    Map<String, dynamic> req = {
      "exercise_id": widget.exerciseId,
      "duration": durationList,
    };
    try {
      setEditExercisesDurationResponse(req).then((value) {
        if (value["success"] == true) {
          toast(value["message"]);
          Navigator.pop(context, true);
          setState(() => isLoading = false);
        } else {
          setState(() => isLoading = false);
          toast(value["message"]);
        }
      });
    } catch (e) {
      toast("Try Again");
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        height: h * height,
        width: w,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
        ),
        child: SingleChildScrollView(
          child: Column(
            children: [
              ListTile(
                title: Text(
                  "Edit Minutes",
                  style: boldTextStyle(size: 14),
                ),
              ),
              ListView.builder(
                itemCount: durationLength,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  durationController.putIfAbsent(
                      controllerKey[index], () => TextEditingController());
                  durationFocusNode.putIfAbsent(index, () => FocusNode());
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: index > 0 ? w * 0.5 : w * 0.7,
                        child: AppTextField(
                          onTap: () {
                            durationFocusNode[index].unfocus();
                            showDialog(
                              context: context,
                              builder: (context) {
                                return Dialog(
                                  backgroundColor: Colors.transparent,
                                  child: Container(
                                    width: w * 0.6,
                                    height: h * 0.3,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Column(
                                      children: [
                                        SizedBox(
                                          height: h * 0.2,
                                          child: CupertinoPicker(
                                            itemExtent: 60,
                                            onSelectedItemChanged: (int value) {
                                              selectValue = value;
                                              setState(() {});
                                            },
                                            children:
                                                List.generate(60, (index) {
                                              return Center(
                                                child: Text(
                                                  "${index + 1} Minute",
                                                  style: boldTextStyle(),
                                                ),
                                              );
                                            }),
                                          ),
                                        ),
                                        (h * 0.02).toInt().height,
                                        AppLoadingButton(
                                          isLoading: false,
                                          onTap: () {
                                            durationController[index].text =
                                                "${selectValue + 1}";
                                            setState(() {});
                                            Navigator.pop(context);
                                          },
                                          text: "OK",
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                          focus: durationFocusNode[index],
                          controller: durationController[controllerKey[index]],
                          textFieldType: TextFieldType.NUMBER,
                          suffix: const Text(
                            "Minute",
                            textAlign: TextAlign.center,
                          ).paddingSymmetric(vertical: 16, horizontal: 10),
                          decoration:
                              defaultInputDecoration(context, label: "Minute"),
                          autoFocus: false,
                          isValidationRequired: true,
                        ).paddingSymmetric(vertical: 10),
                      ),
                      if (index > 0) (w * 0.08).toInt().width,
                      if (index > 0)
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              durationController.remove(controllerKey[index]);
                              controllerKey.removeAt(index);
                              if (durationLength > 2) {
                                height -= 0.08;
                              }
                              durationLength--;
                            });
                          },
                          child: Container(
                            width: w * 0.1,
                            height: h * 0.04,
                            decoration: BoxDecoration(
                              color: appRedColor,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Icon(
                              Icons.delete,
                              color: Colors.white,
                            ),
                          ),
                        )
                    ],
                  );
                },
              ),
              if (durationLength <= 10)
                Align(
                  alignment: Alignment.topRight,
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        if (durationLength >= 2) {
                          height += 0.08;
                        }
                        durationLength++;
                        controllerKey.add(controllerLength);
                        controllerLength++;
                      });
                    },
                    child: Container(
                      width: w * 0.1,
                      height: h * 0.04,
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(
                        Icons.add,
                        color: Colors.white,
                      ),
                    ),
                  ).paddingSymmetric(horizontal: 22),
                ),
              if (durationLength == 1)
                (h * 0.1).toInt().height
              else
                (h * 0.02).toInt().height,
              AppLoadingButton(
                isLoading: isLoading,
                onTap: () {
                  setEditExercisesDurationData();
                },
                text: "Edit",
              ),
              (h * 0.02).toInt().height,
            ],
          ),
        ),
      ),
    );
  }
}

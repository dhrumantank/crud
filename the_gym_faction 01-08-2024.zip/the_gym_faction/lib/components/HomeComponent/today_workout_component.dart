import 'package:TheGymFaction/extensions/extension_util/bool_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:flutter/material.dart';

import '../../extensions/colors.dart';
import '../../extensions/constants.dart';
import '../../extensions/text_styles.dart';
import '../../screens/Home/TodayExercises/today_workout.dart';
import '../../utils/app_colors.dart';

class TodayWorkoutComponent extends StatefulWidget {
  const TodayWorkoutComponent(
      {super.key,
      required this.image,
      required this.total,
      required this.complete,
      required this.name});
  final String image;
  final int total;
  final int complete;
  final String name;

  @override
  State<TodayWorkoutComponent> createState() => _TodayWorkoutComponentState();
}

class _TodayWorkoutComponentState extends State<TodayWorkoutComponent> {
  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    return Container(
      width: w,
      height: 200,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: NetworkImage(widget.image),
          fit: BoxFit.fill,
        ),
        borderRadius: BorderRadius.circular(20),
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade200,
            spreadRadius: 1,
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          15.height,
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: appRedColor,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      "Exercise ${widget.complete}/${widget.total}",
                      style: boldTextStyle(
                        size: 16,
                        color: whiteColor,
                      ),
                    ).paddingSymmetric(horizontal: 10, vertical: 4),
                  ),
                  5.height,
                  Container(
                    decoration: BoxDecoration(
                      color: black,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      widget.name,
                      style: boldTextStyle(
                        size: 12,
                        color: whiteColor,
                      ),
                    ).paddingSymmetric(horizontal: 10, vertical: 4),
                  ),
                ],
              ),
              const Spacer(),
              Button(
                onPressed: () {
                  const TodayWorkout().launch(context);
                },
                child: Row(
                  children: [
                    Text(
                      "Start Workout",
                      style: boldTextStyle(size: 14, color: Colors.white),
                    ),
                    5.width,
                    const Icon(
                      Icons.arrow_forward_outlined,
                      size: 18,
                      color: Colors.white,
                    )
                  ],
                ),
              ),
            ],
          ),
        ],
      ).paddingSymmetric(horizontal: 16),
    ).paddingSymmetric(horizontal: 8);
  }
}

class Button extends StatefulWidget {
  const Button({super.key, required this.onPressed, required this.child});
  final void Function() onPressed;
  final Widget child;

  @override
  State<Button> createState() => _ButtonState();
}

class _ButtonState extends State<Button> with SingleTickerProviderStateMixin {
  double _scale = 1.0;
  AnimationController? _controller;

  @override
  void initState() {
    if (true.validate(value: enableAppButtonScaleAnimationGlobal)) {
      _controller = AnimationController(
        vsync: this,
        duration: Duration(
          milliseconds: appButtonScaleAnimationDurationGlobal ?? 50,
        ),
        lowerBound: 0.0,
        upperBound: 0.1,
      )..addListener(() {
          setState(() {});
        });
    }
    super.initState();
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;

    if (_controller != null && true.validate(value: true)) {
      _scale = 1 - _controller!.value;
    }

    if (true.validate(value: enableAppButtonScaleAnimationGlobal)) {
      return Listener(
        onPointerDown: (details) {
          _controller?.forward();
        },
        onPointerUp: (details) {
          _controller?.reverse();
        },
        child: Transform.scale(
          scale: _scale,
          child: buildButton(w),
        ),
      );
    } else {
      return buildButton(w);
    }
  }

  Widget buildButton(double w) {
    return GestureDetector(
      onTap: widget.onPressed,
      child: Container(
        height: 30,
        decoration: BoxDecoration(
            color: appRedColor, borderRadius: BorderRadius.circular(20)),
        child: widget.child.paddingSymmetric(horizontal: 10),
      ),
    );
    // return MaterialButton(
    //   padding: EdgeInsets.zero,
    //   height: 30,
    //   animationDuration: Duration(milliseconds: 300),
    //   shape: RoundedRectangleBorder(
    //     borderRadius: BorderRadius.circular(20),
    //   ),
    //   color: appRedColor,
    //   onPressed: widget.onPressed,
    //   child: widget.child.paddingSymmetric(horizontal: 10),
    // );
  }
}

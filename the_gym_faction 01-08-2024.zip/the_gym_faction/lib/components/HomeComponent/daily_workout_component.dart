import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_vector_icons/flutter_vector_icons.dart';
import 'package:intl/intl.dart';
import 'package:shimmer/shimmer.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../extensions/colors.dart';
import '../../extensions/text_styles.dart';
import '../../models/daily_workout_charts_model.dart';
import '../../screens/ProfileScreen/History/view_workout_history_screen.dart';
import '../../utils/app_colors.dart';

class DailyWorkout extends StatefulWidget {
  const DailyWorkout(
      {super.key,
      required this.chartList,
      this.cardView,
      required this.checkGetData});
  final List<DailyWorkoutChartsDatum> chartList;
  final bool checkGetData;
  final bool? cardView;

  @override
  State<DailyWorkout> createState() => _DailyWorkoutState();
}

class _DailyWorkoutState extends State<DailyWorkout> {
  List<DailyWorkoutChartsDatum> dailyWorkoutChartsDatum = [];

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return widget.checkGetData == true
        ? const ChartShimmerEffect()
        : widget.cardView == false
            ? widget.chartList.isEmpty
                ? Stack(
                    children: [
                      DailyWorkoutGraph(
                        chartList: dailyWorkoutChartsDatum,
                      ),
                      Positioned(
                        left: w * 0.45,
                        top: h * 0.18,
                        child: Text(
                          "No Data",
                          style: boldTextStyle(size: 14),
                        ),
                      ),
                    ],
                  )
                : DailyWorkoutGraph(chartList: widget.chartList)
            : widget.chartList.isEmpty
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("Daily Workout", style: boldTextStyle(size: 18))
                              .paddingSymmetric(horizontal: 16),
                          IconButton(
                              splashColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              icon: const Icon(Feather.chevron_right,
                                  color: primaryColor),
                              onPressed: () {
                                const ViewWorkoutHistoryScreen()
                                    .launch(context);
                              }).paddingRight(2),
                        ],
                      ),
                      Card(
                        elevation: 1.0,
                        color: whiteColor,
                        shape: RoundedRectangleBorder(
                          side: BorderSide(
                              color: Colors.grey.shade300, width: 0.0),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        margin: EdgeInsets.zero,
                        child: Stack(
                          children: [
                            DailyWorkoutGraph(
                              chartList: dailyWorkoutChartsDatum,
                            ),
                            Positioned(
                              left: w * 0.45,
                              top: h * 0.18,
                              child: Text(
                                "No Data",
                                style: boldTextStyle(size: 14),
                              ),
                            ),
                          ],
                        ),
                      ).paddingSymmetric(horizontal: 10),
                    ],
                  )
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text("Daily Workout", style: boldTextStyle(size: 18))
                              .paddingSymmetric(horizontal: 16),
                          IconButton(
                              splashColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              icon: const Icon(Feather.chevron_right,
                                  color: primaryColor),
                              onPressed: () {
                                const ViewWorkoutHistoryScreen()
                                    .launch(context);
                              }).paddingRight(2),
                        ],
                      ),
                      Card(
                        elevation: 1.0,
                        color: whiteColor,
                        shape: RoundedRectangleBorder(
                          side: BorderSide(
                              color: Colors.grey.shade300, width: 0.0),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        margin: EdgeInsets.zero,
                        child: DailyWorkoutGraph(
                          chartList: widget.chartList,
                        ),
                      ).paddingSymmetric(horizontal: 10),
                    ],
                  );
  }
}

class DailyWorkoutGraph extends StatelessWidget {
  const DailyWorkoutGraph({super.key, required this.chartList});
  final List<DailyWorkoutChartsDatum> chartList;

  @override
  Widget build(BuildContext context) {
    DateFormat dateFormat = DateFormat("dd-MM");
    return SfCartesianChart(
      primaryXAxis: const CategoryAxis(
        majorGridLines: MajorGridLines(color: Colors.transparent),
        isVisible: true,
      ),
      primaryYAxis: const NumericAxis(
        minimum: 0,
        maximum: 100,
        interval: 10,
        labelFormat: r'{value}%',
        majorGridLines: MajorGridLines(color: Colors.transparent),
      ),
      tooltipBehavior: TooltipBehavior(enable: true),
      series: <CartesianSeries<DailyWorkoutChartsDatum, String>>[
        ColumnSeries<DailyWorkoutChartsDatum, String>(
          dataSource: chartList,
          xValueMapper: (DailyWorkoutChartsDatum data, _) =>
              dateFormat.format(DateTime.parse(data.date.toString())),
          yValueMapper: (DailyWorkoutChartsDatum data, _) =>
              double.parse(data.completionPercentage.toString()),
          color: black,
          name: 'Workout',
          width: 0.4,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(20.0),
            topRight: Radius.circular(20.0),
          ),
        ),
      ],
    ).paddingSymmetric(vertical: 20, horizontal: 20);
  }
}

class ChartShimmerEffect extends StatelessWidget {
  const ChartShimmerEffect({super.key});

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Shimmer.fromColors(
      baseColor: Colors.grey.shade200,
      highlightColor: Colors.grey.shade400,
      child: Container(
        width: w * 0.88,
        height: h * 0.4,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: Colors.grey.shade200,
        ),
      ),
    ).center();
  }
}

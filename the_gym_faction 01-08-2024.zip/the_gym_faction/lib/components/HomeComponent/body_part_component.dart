import 'package:flutter/material.dart';

import '../../../extensions/extension_util/context_extensions.dart';
import '../../../extensions/extension_util/int_extensions.dart';
import '../../../extensions/extension_util/string_extensions.dart';
import '../../../extensions/extension_util/widget_extensions.dart';
import '../../../models/body_part_response.dart';
import '../../extensions/text_styles.dart';
import '../../main.dart';
import '../../screens/Home/Exercise/exercise_list_screen.dart';
import '../../utils/app_colors.dart';
import '../../utils/app_common.dart';

class BodyPartComponent extends StatefulWidget {
  const BodyPartComponent(
      {super.key,
      this.bodyPartModel,
      this.isGrid = false,
      this.isFilter = false});
  final bool isGrid;
  final bool isFilter;
  final BodyPartModel? bodyPartModel;

  @override
  State<BodyPartComponent> createState() => _BodyPartComponentState();
}

class _BodyPartComponentState extends State<BodyPartComponent> {
  bool isBody = false;

  @override
  Widget build(BuildContext context) {
    double width = widget.isGrid == true
        ? (context.width() - 64) / 3.1
        : context.width() * 0.20;
    double height = widget.isGrid == true
        ? (context.width() - 64) / 3.1
        : context.width() * 0.20;

    return SizedBox(
      width: width,
      child: Column(
        children: [
          Container(
            width: width,
            height: height,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(150),
              boxShadow: [
                BoxShadow(color: Colors.grey.shade200, spreadRadius: 1),
              ],
            ),
            child: cachedImage(widget.bodyPartModel!.image.validate(),
                    fit: BoxFit.fill, width: width, height: height)
                .cornerRadiusWithClipRRect(150),
          ),
          6.height,
          Text(widget.bodyPartModel!.title.validate(),
              style: primaryTextStyle(
                  size: 14,
                  color: isBody == true
                      ? primaryColor
                      : appStore.isDarkMode
                          ? Colors.white
                          : Colors.black),
              textAlign: TextAlign.center,
              maxLines: 2),
        ],
      ),
    ).onTap(() {
      ExerciseListScreen(
              mTitle: widget.bodyPartModel!.title.validate(),
              isBodyPart: true,
              id: widget.bodyPartModel!.id.validate())
          .launch(context);
    });
  }
}

import 'package:TheGymFaction/components/HomeComponent/start_exercise_dialog.dart';
import 'package:TheGymFaction/extensions/app_button.dart';
import 'package:TheGymFaction/extensions/colors.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:animated_weight_picker/animated_weight_picker.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../extensions/system_utils.dart';
import '../../main.dart';
import '../../network/rest_api.dart';
import '../../utils/app_common.dart';

class ShowOneTimeDialog extends StatefulWidget {
  const ShowOneTimeDialog({super.key, this.showStartExercise});
  final bool? showStartExercise;

  @override
  State<ShowOneTimeDialog> createState() => _ShowOneTimeDialogState();
}

class _ShowOneTimeDialogState extends State<ShowOneTimeDialog> {
  // WeightSliderController weightController = WeightSliderController();
  DateFormat dateFormat = DateFormat("yyyy-MM-dd");
  double weight = 0;
  String selectedValue = '';
  @override
  void initState() {
    appStore.setShowOneTimeDialog(false);
    super.initState();
  }

  Future<void> save() async {
    Map req = {
      "value": selectedValue,
      "type": "weight",
      "unit": "Kg",
      "date": dateFormat.format(DateTime.now())
    };
    await setProgressApi(req).then((value) {
      toast(value.message);
      finish(context);
      appStore.setTodayWeightDataGet(true);
      if (widget.showStartExercise == true) {
        showDialog(
            context: context,
            builder: (context) => const StartExerciseDialog());
      }
      setState(() {});
    }).catchError((e) {
      print(e.toString());
    });
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        width: w,
        height: h * 0.5,
        decoration: BoxDecoration(
          color: whiteColor,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Stack(
          children: [
            Column(
              children: [
                const Spacer(),
                Text(
                  "Choose Your Weight For Today",
                  style: boldTextStyle(size: 14),
                ).center(),
                (h * 0.025).toInt().height,
                AnimatedWeightPicker(
                  min: 0,
                  max: 200,
                  onChange: (newValue) {
                    setState(() {
                      selectedValue = newValue;
                    });
                  },
                ),
                (h * 0.05).toInt().height,
                AppButton(
                  onTap: () {
                    if (selectedValue != "") {
                      save();
                    } else {
                      toast("Please Select Your Weight");
                    }
                  },
                  text: "Add Weight",
                ),
                (h * 0.025).toInt().height,
                Text(
                  "Your Weight Is $selectedValue",
                  style: boldTextStyle(size: 14),
                ).center(),
                (h * 0.025).toInt().height,
              ],
            ),
            Align(
              alignment: Alignment.topRight,
              child: IconButton(
                onPressed: () {
                  Navigator.pop(context);
                  if (widget.showStartExercise == true) {
                    showDialog(
                      context: context,
                      builder: (context) => const StartExerciseDialog(),
                    );
                  }
                },
                icon: const Icon(Icons.close),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';

import '../../extensions/app_button.dart';
import '../../extensions/colors.dart';
import '../../extensions/text_styles.dart';
import '../../models/graph_response.dart';

class FillTodayDetails extends StatefulWidget {
  const FillTodayDetails({
    super.key,
    this.title,
    required this.buttonText,
    required this.onTap,
    this.data,
  });
  final String? title;
  final String buttonText;
  final Function? onTap;
  final List<GraphResponse>? data;

  @override
  State<FillTodayDetails> createState() => _FillTodayDetailsState();
}

class _FillTodayDetailsState extends State<FillTodayDetails> {
  List<DateTime> newList = [];
  dynamic valueData;

  @override
  void initState() {
    if (widget.data != null) {
      for (var i = 0; i < widget.data![0].data!.length; i++) {
        newList
            .add(DateTime.parse(widget.data![0].data![i].createdAt.toString()));
      }
      newList.sort(((a, b) => b.compareTo(a)));
      print(newList);
      for (var value in widget.data![0].data!) {
        DateTime date = DateTime.parse(value.createdAt.toString());
        if (date == newList.first) {
          valueData = value.value;
        }
      }
    }
    setState(() {});
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    return Container(
      height: 100,
      width: w * 0.9,
      decoration: BoxDecoration(
        color: whiteColor,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade200,
            spreadRadius: 1,
          )
        ],
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          10.height,
          Text(
            "Your Weight Is $valueData Kg" ?? widget.title!,
            style: boldTextStyle(size: 18),
          ),
          10.height,
          AppButton(
            onTap: widget.onTap,
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Text(
              widget.buttonText,
              style: boldTextStyle(size: 12, color: whiteColor),
            ),
          )
        ],
      ),
    ).center();
  }
}

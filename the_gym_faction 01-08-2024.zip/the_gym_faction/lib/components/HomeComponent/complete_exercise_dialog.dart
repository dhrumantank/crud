import 'package:TheGymFaction/extensions/app_button.dart';
import 'package:TheGymFaction/extensions/colors.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:TheGymFaction/utils/app_colors.dart';
import 'package:flutter/material.dart';

import '../../network/rest_api.dart';
import 'congratulations_dialog.dart';

class CompleteExerciseDialog extends StatefulWidget {
  const CompleteExerciseDialog({
    super.key,
    required this.id,
  });
  final int id;

  @override
  State<CompleteExerciseDialog> createState() => _CompleteExerciseDialogState();
}

class _CompleteExerciseDialogState extends State<CompleteExerciseDialog> {
  void getCompleteWorkout() {
    Map<String, dynamic> req = {
      "exercise_id": widget.id,
      "status": "complete",
    };
    getCompleteWorkoutApi(req).then((value) {
      showDialog(
        context: context,
        builder: (context) {
          return CongratulationsDialog(
            onTap: () {
              Navigator.pop(context, true);
            },
          );
        },
      ).then((value) {
        Navigator.pop(context, true);
        return;
      });
      return;
    });
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        height: h * 0.3,
        width: w,
        decoration: BoxDecoration(
          color: whiteColor,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            20.height,
            Text(
              "Are you sure you want to complete your Exercise without timer",
              style: boldTextStyle(),
              textAlign: TextAlign.center,
            ).paddingSymmetric(horizontal: 10),
            20.height,
            Text(
              "if you want you can change sets and weight for this exercise",
              style: boldTextStyle(size: 14),
              textAlign: TextAlign.center,
            ).paddingSymmetric(horizontal: 10),
            20.height,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                AppButton(
                  color: appRedColor,
                  onTap: () {
                    Navigator.pop(context);
                  },
                  text: "No",
                ),
                AppButton(
                  color: Colors.green,
                  onTap: () {
                    getCompleteWorkout();
                    // Navigator.pop(context, true);
                  },
                  text: "Yes",
                ),
              ],
            ),
          ],
        ).paddingSymmetric(horizontal: 20),
      ),
    );
  }
}

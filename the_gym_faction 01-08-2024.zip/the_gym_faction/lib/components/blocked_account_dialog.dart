import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:TheGymFaction/utils/app_common.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../main.dart';

class BlockAccountDialog extends StatefulWidget {
  const BlockAccountDialog(
      {super.key, required this.title, required this.number});
  final String title;
  final String number;

  @override
  State<BlockAccountDialog> createState() => _BlockAccountDialogState();
}

class _BlockAccountDialogState extends State<BlockAccountDialog> {
  Timer? timer;
  bool back = false;
  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return PopScope(
      canPop: back,
      onPopInvoked: (didPop) {
        if (back) {
          SystemNavigator.pop();
        } else {
          toast(languages.lblTapBackAgainToLeave);
          setState(() {
            back = true;
          });
          timer = Timer.periodic(const Duration(seconds: 5), (timer) {
            back = false;
            setState(() {});
            timer.cancel();
          });
        }
      },
      child: Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          width: w * 0.9,
          height: h * 0.3,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            children: [
              const CircleAvatar(
                backgroundColor: Colors.transparent,
                radius: 70,
                backgroundImage: AssetImage('assets/app_icons.png'),
              ),
              Text(
                widget.title,
                style: boldTextStyle(),
                textAlign: TextAlign.center,
              ),
              12.height,
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Contact Us",
                    style: boldTextStyle(size: 14),
                    textAlign: TextAlign.center,
                  ),
                  TextButton(
                    onPressed: () async {
                      await launchUrl(Uri.parse("tel:${widget.number}"));
                    },
                    child: Text(
                      widget.number,
                      style: boldTextStyle(
                        size: 14,
                        color: Colors.blue,
                      ),
                    ),
                  )
                ],
              )
            ],
          ).paddingSymmetric(horizontal: 30),
        ),
      ),
    );
  }
}

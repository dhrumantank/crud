import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../extensions/extension_util/context_extensions.dart';
import '../main.dart';
import '../models/graph_response.dart';
import '../models/weight_graph_model.dart';
import '../utils/app_colors.dart';

class HorizontalBarChart extends StatelessWidget {
  final List<GraphModel>? seriesList;
  final List<WeightGraphDatum>? waterSeriesList;
  final Color? color;
  final String? name;
  final Color? borderColor;
  final Color? MarkerBorderColor;
  final Color? axisLineBorderColor;
  final Color? YAxisLineColor;
  final Color? XAxisLineColor;
  final String? type;

  HorizontalBarChart({
    super.key,
    this.seriesList,
    this.color,
    this.borderColor,
    this.MarkerBorderColor,
    this.axisLineBorderColor,
    this.name,
    this.YAxisLineColor,
    this.XAxisLineColor,
    this.type,
    this.waterSeriesList,
  });

  final List<GraphModel> data = [];

  @override
  Widget build(BuildContext context) {
    return SfCartesianChart(
      legend: const Legend(isVisible: true),
      series: type == "water" ? getDefaultData2() : getDefaultData3(),
      backgroundColor: context.cardColor,
      primaryYAxis: NumericAxis(
        majorGridLines:
            MajorGridLines(color: YAxisLineColor ?? Colors.grey.shade300),
      ),
      zoomPanBehavior: ZoomPanBehavior(
        enablePinching: true,
        maximumZoomLevel: 0.85,
      ),
      selectionType: SelectionType.series,
      primaryXAxis: CategoryAxis(
        interval: 1,
        isInversed: true,
        axisLine: AxisLine(color: axisLineBorderColor ?? primaryColor),
        majorGridLines:
            MajorGridLines(color: XAxisLineColor ?? Colors.grey.shade300),
      ),
      enableAxisAnimation: true,
      tooltipBehavior: TooltipBehavior(
        enable: true,
      ),
    );
  }

  List<CartesianSeries> getDefaultData3() {
    DateFormat dateFormat = DateFormat("dd-MM");
    return <CartesianSeries<dynamic, String>>[
      SplineAreaSeries<GraphModel, String>(
          dataSource: seriesList,
          enableTooltip: true,
          isVisibleInLegend: false,
          borderWidth: 2,
          gradient: LinearGradient(
            colors: <Color>[
              appStore.isDarkMode == true
                  ? scaffoldBackgroundColor
                  : Colors.white,
              color ?? appRedColor
            ],
            stops: const <double>[0.03, 0.9],
            end: Alignment.topCenter,
            begin: Alignment.bottomCenter,
          ),
          borderColor: borderColor ?? appRedColor,
          borderDrawMode: BorderDrawMode.excludeBottom,
          animationDuration: 1000,
          dataLabelSettings: const DataLabelSettings(
              isVisible: true, labelPosition: ChartDataLabelPosition.outside),
          markerSettings: MarkerSettings(
              isVisible: true,
              height: 4,
              width: 4,
              shape: DataMarkerType.circle,
              borderWidth: 2,
              borderColor: MarkerBorderColor ?? primaryColor),
          xValueMapper: (GraphModel data, _) =>
              dateFormat.format(DateTime.parse(data.date.toString())),
          yValueMapper: (GraphModel data, _) =>
              double.parse(data.value.toString()),
          name: name ?? '',
          emptyPointSettings:
              const EmptyPointSettings(mode: EmptyPointMode.average))
    ];
  }

  List<CartesianSeries> getDefaultData2() {
    DateFormat dateFormat = DateFormat("dd-MM");
    return <CartesianSeries<dynamic, String>>[
      SplineRangeAreaSeries<WeightGraphDatum, String>(
        dataSource: waterSeriesList,
        enableTooltip: true,
        isVisibleInLegend: false,
        borderWidth: 2,
        gradient: LinearGradient(
          colors: <Color>[
            appStore.isDarkMode == true
                ? scaffoldBackgroundColor
                : Colors.white,
            color ?? appRedColor
          ],
          stops: const <double>[0.03, 0.9],
          end: Alignment.topCenter,
          begin: Alignment.bottomCenter,
        ),
        borderColor: borderColor ?? appRedColor,
        // borderDrawMode: BorderDrawMode.excludeBottom,
        animationDuration: 1000,
        dataLabelSettings: const DataLabelSettings(
            isVisible: true, labelPosition: ChartDataLabelPosition.outside),
        markerSettings: MarkerSettings(
            isVisible: true,
            height: 4,
            width: 4,
            shape: DataMarkerType.circle,
            borderWidth: 2,
            borderColor: MarkerBorderColor ?? primaryColor),
        xValueMapper: (WeightGraphDatum data, _) =>
            dateFormat.format(DateTime.parse(data.date.toString())),
        highValueMapper: (WeightGraphDatum data, _) => 3000,
        lowValueMapper: (WeightGraphDatum data, _) =>
            double.parse(data.value.toString()),
        name: name ?? '',
        emptyPointSettings:
            const EmptyPointSettings(mode: EmptyPointMode.average),

        // yAxisName: "NeedIntake",
      )
    ];
  }
}

// class SalesOrderChart {
//   SalesOrderChart(this.x, this.y, this.z);
//
//   final int x;
//   final int y;
//   final int z;
// }

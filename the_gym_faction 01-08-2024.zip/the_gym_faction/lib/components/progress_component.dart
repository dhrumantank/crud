import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

import '../../../main.dart';
import '../../extensions/app_button.dart';
import '../../extensions/decorations.dart';
import '../../extensions/extension_util/context_extensions.dart';
import '../../extensions/extension_util/int_extensions.dart';
import '../../extensions/extension_util/string_extensions.dart';
import '../../extensions/extension_util/widget_extensions.dart';
import '../extensions/app_text_field.dart';
import '../extensions/colors.dart';
import '../extensions/confirmation_dialog.dart';
import '../extensions/constants.dart';
import '../extensions/system_utils.dart';
import '../extensions/text_styles.dart';
import '../models/graph_response.dart';
import '../network/rest_api.dart';
import '../utils/app_colors.dart';
import '../utils/app_common.dart';
import '../utils/app_constants.dart';
import '../utils/app_images.dart';

class ProgressComponent extends StatefulWidget {
  const ProgressComponent(
      {super.key, this.mGraphModel, this.mType, this.mUnit, this.onCall});
  static String tag = '/UserAddMeasurementDialog';
  final GraphModel? mGraphModel;
  final String? mType;
  final String? mUnit;
  final Function? onCall;

  @override
  ProgressComponentState createState() => ProgressComponentState();
}

class ProgressComponentState extends State<ProgressComponent> {
  var formKey = GlobalKey<FormState>();

  TextEditingController mValueCont = TextEditingController();
  TextEditingController countDownCont = TextEditingController();
  bool mIsUpdate = false;
  String image = '';
  String intakeWater = '';
  String targetWater = '';
  String waterPr = '';
  List<ChartData> chartData = [];
  List<ChartData> chartData2 = [
    ChartData(
        x: "Consumed Water", y: 0, color: Colors.blue, text: "Consumed Water"),
    ChartData(
        x: "Target Water",
        y: 100,
        color: Colors.grey.shade300,
        text: "Target Water"),
  ];
  bool getData = false;

  DateTime? pickedDate;
  String? formattedDate;

  @override
  void initState() {
    fetchWaterIntakeDataData();
    super.initState();
    init();
  }

  void fetchWaterIntakeDataData() {
    setState(() => getData = true);
    getWaterIntakeDataApi().then((value) {
      image = value.data!.image!;
      intakeWater = value.waterData!;
      waterPr = value.percentage!.toStringAsFixed(1).toString();
      targetWater = value.totalTarget!.toString();
      double consumed = double.parse(value.data!.percentage!) - 100;
      chartData = [
        ChartData(
            x: "Consumed Water",
            y: double.parse(value.data!.percentage!),
            color: Colors.blue,
            text: "Consumed Water"),
        ChartData(
            x: "Target Water",
            y: consumed,
            color: Colors.grey.shade300,
            text: "Target Water"),
      ];
      setState(() => getData = false);
    });
  }

  Future<void> init() async {
    mIsUpdate = widget.mGraphModel != null;

    if (mIsUpdate) {
      mValueCont.text = widget.mGraphModel!.value!;
      formattedDate =
          progressDateStringWidget(widget.mGraphModel!.date.toString());
      countDownCont.text = formattedDate.validate();
    } else {
      formattedDate = progressDateStringWidget(
        DateTime.now().toString(),
      );
      countDownCont.text = formattedDate.validate();
    }
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  Future<void> save({String? id}) async {
    if (formKey.currentState!.validate()) {
      Map req;
      if (mIsUpdate) {
        req = {
          "id": id,
          "value": mValueCont.text,
          "type": widget.mType,
          "unit": widget.mUnit,
          "date": countDownCont.text
        };
      } else {
        req = {
          "value": mValueCont.text,
          "type": widget.mType,
          "unit": widget.mUnit,
          "date": countDownCont.text
        };
      }
      await setProgressApi(req).then((value) {
        toast(value.message);
        widget.onCall!.call();
        finish(context);
        setState(() {});
      }).catchError((e) {
        print(e.toString());
      });
    }
  }

  Future<void> delete() async {
    Map req = {
      "id": widget.mGraphModel!.id,
    };
    await deleteProgressApi(req).then((value) {
      toast(value.message);
      widget.onCall!.call();
      finish(context);
      setState(() {});
    }).catchError((e) {
      print(e.toString());
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxHeight: 1000),
        child: Container(
          decoration: boxDecorationWithRoundedCorners(
            borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(18), topRight: Radius.circular(18)),
            backgroundColor:
                appStore.isDarkMode ? cardDarkColor : cardLightColor,
          ),
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (widget.mType == METRICS_WATER)
                    getData
                        ? WaterData(
                            waterPr: "00.0",
                            intakeWater: "0",
                            targetWater: "0",
                            image: image,
                            chartData: chartData2,
                          )
                        : WaterData(
                            waterPr: waterPr,
                            intakeWater: intakeWater,
                            targetWater: targetWater,
                            image: image,
                            chartData: chartData,
                          ),
                  if (widget.mType == METRICS_WATER) 20.height,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                          mIsUpdate
                              ? '${languages.lblUpdate} ${widget.mType.capitalizeFirstLetter()}'
                              : '${languages.lblAdd} ${widget.mType.capitalizeFirstLetter()}',
                          style: boldTextStyle()),
                      4.height,
                      InkWell(
                        onTap: () {
                          finish(context);
                        },
                        child: Container(
                          decoration: boxDecorationWithRoundedCorners(
                              boxShape: BoxShape.circle,
                              backgroundColor: appStore.isDarkMode
                                  ? cardDarkColor
                                  : context.cardColor),
                          padding: const EdgeInsets.all(2),
                          child: Icon(Icons.close,
                              color: appStore.isDarkMode
                                  ? cardLightColor
                                  : cardDarkColor),
                        ),
                      )
                    ],
                  ),
                  20.height,
                  AppTextField(
                    controller: mValueCont,
                    textFieldType: TextFieldType.PHONE,
                    decoration: defaultInputDecoration(context,
                        label: "Enter Your ${widget.mType}"),
                    suffix: Text(widget.mUnit.toString(),
                            style: secondaryTextStyle())
                        .paddingSymmetric(vertical: 16, horizontal: 0),
                    autoFocus: false,
                    isValidationRequired: true,
                    validator: (s) {
                      if (s!.trim().isEmpty) return errorThisFieldRequired;
                      return null;
                    },
                  ),
                  16.height,
                  AppTextField(
                    controller: countDownCont,
                    textFieldType: TextFieldType.NAME,
                    onChanged: (s) {
                      setState(() {});
                    },
                    onTap: () async {
                      FocusScope.of(context).requestFocus(FocusNode());
                      // pickedDate = await showDatePicker(
                      //     context: context,
                      //     initialDate: DateTime.now(),
                      //     firstDate: DateTime(2000),
                      //     lastDate: DateTime.now());
                      // if (pickedDate != null) {
                      //   print(pickedDate);
                      //   formattedDate =
                      //       DateFormat('yyyy-MM-dd').format(pickedDate!);
                      //   print(formattedDate);
                      //   setState(() {
                      //     countDownCont.text = formattedDate!;
                      //   });
                      // } else {}
                    },
                    readOnly: true,
                    suffix: const Icon(Icons.calendar_today),
                    decoration: defaultInputDecoration(context,
                        label: languages.lblDate),
                    validator: (s) {
                      if (s!.trim().isEmpty) return errorThisFieldRequired;
                      return null;
                    },
                  ),
                  25.height,
                  mIsUpdate == true
                      ? Row(
                          children: [
                            AppButton(
                              color: primaryColor,
                              onTap: () {
                                showConfirmDialogCustom(context,
                                    dialogType: DialogType.CONFIRMATION,
                                    iconColor: primaryColor,
                                    primaryColor: primaryColor,
                                    title:
                                        "${languages.lblDelete} ${widget.mType.capitalizeFirstLetter()}",
                                    image: ic_delete,
                                    subTitle:
                                        "${languages.lblDeleteAccountMSg} ${widget.mType.capitalizeFirstLetter()}?",
                                    onAccept: (context) {
                                  delete();
                                });
                              },
                              text: languages.lblDelete,
                            ).expand(),
                            16.width,
                            AppButton(
                              color: primaryColor,
                              text: languages.lblUpdate,
                              onTap: () {
                                save(id: widget.mGraphModel!.id.toString());
                              },
                            ).expand()
                          ],
                        )
                      : AppButton(
                          color: primaryColor,
                          width: context.width(),
                          text: languages.lblSave,
                          onTap: () {
                            save();
                          },
                        ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class WaterData extends StatelessWidget {
  const WaterData(
      {super.key,
      required this.image,
      required this.chartData,
      required this.intakeWater,
      required this.targetWater,
      required this.waterPr});
  final String image;
  final List<ChartData> chartData;
  final String intakeWater;
  final String targetWater;
  final String waterPr;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      color: black,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      margin: EdgeInsets.zero,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          image.validate().isEmpty
              ? Shimmer.fromColors(
                  baseColor: Colors.grey.shade200,
                  highlightColor: Colors.white54,
                  child: Container(
                    height: 200,
                    width: 150,
                    color: Colors.grey.shade200,
                  ),
                )
              : CachedNetworkImage(
                  imageUrl: image,
                  height: 200,
                  width: 150,
                  alignment: Alignment.center,
                ),
          // cachedImage(image, height: 200, width: 150),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                  height: 130,
                  width: 130,
                  child: SfCircularChart(annotations: <CircularChartAnnotation>[
                    CircularChartAnnotation(
                      widget: Text(
                        "$waterPr%",
                        style: const TextStyle(color: whiteColor),
                      ),
                    )
                  ], series: <CircularSeries>[
                    DoughnutSeries<ChartData, String>(
                      dataSource: chartData,
                      xValueMapper: (ChartData data, _) => data.x,
                      yValueMapper: (ChartData data, _) => data.y,
                      pointColorMapper: (ChartData data, _) => data.color,
                      dataLabelMapper: (ChartData data, _) => data.text,
                      radius: '100%',
                      innerRadius: '70%',
                      // Corner style of radial bar segment
                      // cornerStyle: CornerStyle.bothCurve,
                    )
                  ])),
              15.height,
              Text("Consumed Water",
                  style: boldTextStyle(size: 12, color: whiteColor)),
              Text("$intakeWater ml",
                  style: boldTextStyle(size: 12, color: whiteColor)),
              Text("To Targeted Water",
                  style: boldTextStyle(size: 12, color: whiteColor)),
              Text("$targetWater ml",
                  style: boldTextStyle(size: 12, color: whiteColor)),
            ],
          )
        ],
      ).paddingSymmetric(vertical: 10),
    );
  }
}

class ChartData {
  String? x;
  double? y;
  Color? color;
  String? text;
  ChartData({
    this.x,
    this.y,
    this.color,
    this.text,
  });
}

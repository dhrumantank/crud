import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../extensions/animatedList/animated_wrap.dart';
import '../extensions/horizontal_list.dart';

class HomeShimmerEffectScreen extends StatelessWidget {
  const HomeShimmerEffectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Shimmer.fromColors(
            baseColor: Colors.grey.shade200,
            highlightColor: Colors.grey.shade400,
            child: Container(
              width: w * 0.4,
              height: h * 0.025,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: Colors.grey.shade200,
              ),
            ),
          ).paddingSymmetric(horizontal: 15),
          4.height,
          HorizontalList(
            physics: const BouncingScrollPhysics(),
            itemCount: 7,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            spacing: 14,
            itemBuilder: (context, index) {
              return Shimmer.fromColors(
                baseColor: Colors.grey.shade200,
                highlightColor: Colors.grey.shade400,
                child: CircleAvatar(
                  radius: 32,
                  backgroundColor: Colors.grey.shade200,
                ),
              );
            },
          ).center(),
          10.height,
          Shimmer.fromColors(
            baseColor: Colors.grey.shade200,
            highlightColor: Colors.grey.shade400,
            child: Container(
              width: w * 0.4,
              height: h * 0.025,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: Colors.grey.shade200,
              ),
            ),
          ).paddingSymmetric(horizontal: 15),
          10.height,
          Shimmer.fromColors(
            baseColor: Colors.grey.shade200,
            highlightColor: Colors.grey.shade400,
            child: Container(
              width: w,
              height: 200,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.grey.shade200,
              ),
            ),
          ).paddingSymmetric(horizontal: 8),
          10.height,
          Shimmer.fromColors(
            baseColor: Colors.grey.shade200,
            highlightColor: Colors.grey.shade400,
            child: Container(
              width: w * 0.4,
              height: h * 0.025,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: Colors.grey.shade200,
              ),
            ),
          ).paddingSymmetric(horizontal: 15),
          10.height,
          SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: AnimatedWrap(
              runSpacing: 18,
              spacing: 16,
              children: List.generate(8, (index) {
                return SizedBox(
                  width: w * 0.20,
                  child: Column(
                    children: [
                      Shimmer.fromColors(
                        baseColor: Colors.grey.shade200,
                        highlightColor: Colors.grey.shade400,
                        child: Container(
                          width: w * 0.20,
                          height: w * 0.20,
                          decoration: BoxDecoration(
                            color: Colors.grey.shade200,
                            borderRadius: BorderRadius.circular(80),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.grey.shade200, spreadRadius: 1),
                            ],
                          ),
                        ),
                      ),
                      6.height,
                      Shimmer.fromColors(
                          baseColor: Colors.grey.shade200,
                          highlightColor: Colors.grey.shade400,
                          child: Container(
                            width: w * 0.19,
                            height: h * 0.015,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                              color: Colors.grey.shade200,
                            ),
                          )),
                    ],
                  ),
                );
              }),
            ),
          ),
          16.height,
          Shimmer.fromColors(
            baseColor: Colors.grey.shade200,
            highlightColor: Colors.grey.shade400,
            child: Container(
              width: w * 0.4,
              height: h * 0.025,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: Colors.grey.shade200,
              ),
            ),
          ).paddingSymmetric(horizontal: 15),
          16.height,
          Shimmer.fromColors(
            baseColor: Colors.grey.shade200,
            highlightColor: Colors.grey.shade400,
            child: Container(
              width: w * 0.88,
              height: h * 0.4,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: Colors.grey.shade200,
              ),
            ),
          ).center(),
          16.height,
          Shimmer.fromColors(
            baseColor: Colors.grey.shade200,
            highlightColor: Colors.grey.shade400,
            child: Container(
              width: w * 0.88,
              height: h * 0.4,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: Colors.grey.shade200,
              ),
            ),
          ).center(),
          16.height,
          Shimmer.fromColors(
            baseColor: Colors.grey.shade200,
            highlightColor: Colors.grey.shade400,
            child: Container(
              width: w * 0.88,
              height: h * 0.4,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: Colors.grey.shade200,
              ),
            ),
          ).center(),
          10.height,
          Shimmer.fromColors(
            baseColor: Colors.grey.shade200,
            highlightColor: Colors.grey.shade400,
            child: Container(
              width: w * 0.4,
              height: h * 0.025,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: Colors.grey.shade200,
              ),
            ),
          ).paddingSymmetric(horizontal: 15),
          10.height,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Shimmer.fromColors(
                baseColor: Colors.grey.shade200,
                highlightColor: Colors.grey.shade400,
                child: Container(
                  height: h * 0.11,
                  width: w * 0.22,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
              Shimmer.fromColors(
                baseColor: Colors.grey.shade200,
                highlightColor: Colors.grey.shade400,
                child: Container(
                  height: h * 0.11,
                  width: w * 0.22,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
              Shimmer.fromColors(
                baseColor: Colors.grey.shade200,
                highlightColor: Colors.grey.shade400,
                child: Container(
                  height: h * 0.11,
                  width: w * 0.22,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
            ],
          ),
          10.height,
          Shimmer.fromColors(
            baseColor: Colors.grey.shade200,
            highlightColor: Colors.grey.shade400,
            child: Container(
              width: w * 0.4,
              height: h * 0.025,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: Colors.grey.shade200,
              ),
            ),
          ).paddingSymmetric(horizontal: 15),
          10.height,
          SizedBox(
            width: w,
            height: h * 0.25,
            child: PageView.builder(
              itemCount: 5,
              itemBuilder: (context, index) {
                return Shimmer.fromColors(
                  baseColor: Colors.grey.shade200,
                  highlightColor: Colors.grey.shade400,
                  child: Container(
                    width: w * 0.9,
                    height: h * 0.2,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade200,
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                ).paddingSymmetric(horizontal: 15);
              },
            ),
          ),
          10.height,
        ],
      ),
    );
  }
}

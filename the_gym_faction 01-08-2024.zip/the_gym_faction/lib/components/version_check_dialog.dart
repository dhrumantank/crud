import 'package:TheGymFaction/extensions/app_button.dart';
import 'package:TheGymFaction/extensions/colors.dart';
import 'package:TheGymFaction/extensions/extension_util/int_extensions.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:TheGymFaction/utils/app_images.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class VersionCheckDialog extends StatelessWidget {
  const VersionCheckDialog({super.key, required this.appUrl});
  final String appUrl;

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            height: h * 0.34,
            width: w,
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                (h * 0.1).toInt().height,
                Text(
                  "You Have Old Version",
                  style: boldTextStyle(),
                ),
                20.height,
                Text(
                  "Please Update",
                  style: boldTextStyle(),
                ),
                const Spacer(),
                AppButton(
                  text: "Update",
                  width: w * 0.3,
                  onTap: () {
                    final url = Uri.parse(appUrl);
                    launchUrl(
                      url,
                      mode: LaunchMode.externalApplication,
                    );
                  },
                ),
                30.height,
              ],
            ),
          ),
          Positioned(
            top: -60,
            left: w * 0.24,
            child: Container(
              width: w * 0.3,
              height: h * 0.14,
              decoration: BoxDecoration(
                color: whiteColor,
                image: const DecorationImage(
                  image: AssetImage(ic_logo),
                ),
                borderRadius: BorderRadius.circular(200),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

import 'dart:convert';
import 'dart:developer';

import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/screens/Home/TodayExercises/today_workout.dart';
import 'package:TheGymFaction/screens/Home/fast_intake_screen.dart';
import 'package:TheGymFaction/screens/Home/meditation_screen.dart';
import 'package:TheGymFaction/screens/dashboard_screen.dart';
import 'package:TheGymFaction/utils/app_constants.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;

import 'components/HomeComponent/show_one_time_dialog.dart';
import 'components/progress_component.dart';
import 'extensions/colors.dart';
import 'extensions/decorations.dart';
import 'main.dart';

class NotificationService {
  static FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  static AndroidNotificationChannel channel = const AndroidNotificationChannel(
    'high_importance_channel',
    'High Importance Notifications',
    importance: Importance.high,
  );
  FirebaseMessaging messaging = FirebaseMessaging.instance;
  getFCMToken() async {
    try {
      await messaging.requestPermission();
      String? token = await messaging.getToken();
      return token;
    } catch (e) {
      log('ERROR:::WHILE:::GETTING:::FCM::::::>>>> $e');
    }
  }

  /// handle notification when app in fore ground..///close app
  static void getInitialMsg() {
    FirebaseMessaging.instance
        .getInitialMessage()
        .then((RemoteMessage? message) async {
      if (message!.notification != null) {
        if (message.data["type"] == "fast") {
          const FastIntakeScreen().launch(navigatorKey.currentContext!);
        } else if (message.data["type"] == "exercise") {
          const TodayWorkout().launch(navigatorKey.currentContext!);
        } else if (message.data["type"] == "diet") {
          const DashboardScreen(mCurrentIndex: 2)
              .launch(navigatorKey.currentContext!);
        } else if (message.data["type"] == "meditation") {
          const MeditationScreen().launch(navigatorKey.currentContext!);
        } else if (message.data["type"] == "water_intake") {
          await showModalBottomSheet(
              isScrollControlled: true,
              context: navigatorKey.currentContext!,
              backgroundColor:
                  appStore.isDarkMode ? cardDarkColor : cardLightColor,
              shape: RoundedRectangleBorder(
                  borderRadius: radiusOnly(topRight: 18, topLeft: 18)),
              builder: (context) {
                return ProgressComponent(
                  mType: METRICS_WATER,
                  mUnit: METRICS_WATER_UNIT,
                  onCall: () {},
                );
              });
        } else if (message.data["type"] == "weight") {
          showDialog(
            context: navigatorKey.currentContext!,
            builder: (context) =>
                const ShowOneTimeDialog(showStartExercise: true),
          );
        }
      }
    });
  }

  ///show notification msg
  static void showMsg(RemoteMessage message) {
    flutterLocalNotificationsPlugin.show(
      message.hashCode,
      '${message.notification?.title}',
      '${message.notification?.body}',
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'high_importance_channel', // id
          'High Importance Notifications', // title
          importance: Importance.high,
          icon: '@mipmap/launcher_icon',
        ),
        iOS: DarwinNotificationDetails(presentSound: true, presentAlert: true),
      ),
      payload: jsonEncode(message.data),
    );
  }

  ///background notification handler..
  static Future<void> backgroundHandler(RemoteMessage message) async {}

  ///call when click on notification back
  static void onBackgroundMsg() {
    FirebaseMessaging.onBackgroundMessage(backgroundHandler);
  }

  ///call when click on notification back
  static void onMsgOpen() {
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) async {
      if (message.notification != null) {
        if (message.data["type"] == "fast") {
          const FastIntakeScreen().launch(navigatorKey.currentContext!);
        } else if (message.data["type"] == "exercise") {
          const TodayWorkout().launch(navigatorKey.currentContext!);
        } else if (message.data["type"] == "diet") {
          const DashboardScreen(mCurrentIndex: 2)
              .launch(navigatorKey.currentContext!);
        } else if (message.data["type"] == "meditation") {
          const MeditationScreen().launch(navigatorKey.currentContext!);
        } else if (message.data["type"] == "water_intake") {
          await showModalBottomSheet(
              isScrollControlled: true,
              context: navigatorKey.currentContext!,
              backgroundColor:
                  appStore.isDarkMode ? cardDarkColor : cardLightColor,
              shape: RoundedRectangleBorder(
                  borderRadius: radiusOnly(topRight: 18, topLeft: 18)),
              builder: (context) {
                return ProgressComponent(
                  mType: METRICS_WATER,
                  mUnit: METRICS_WATER_UNIT,
                  onCall: () {},
                );
              });
        } else if (message.data["type"] == "weight") {
          showDialog(
            context: navigatorKey.currentContext!,
            builder: (context) =>
                const ShowOneTimeDialog(showStartExercise: true),
          );
        }
      }
    });
  }

  ///call when click on notification back
  static void onMsg() {
    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      var initializationSettingsAndroid =
          const AndroidInitializationSettings('@mipmap/launcher_icon');
      var initializationSettings =
          InitializationSettings(android: initializationSettingsAndroid);
      try {
        await flutterLocalNotificationsPlugin.initialize(
          initializationSettings,
          onDidReceiveNotificationResponse: (details) async {
            if (message.data["type"] == "fast") {
              const FastIntakeScreen().launch(navigatorKey.currentContext!);
            } else if (message.data["type"] == "exercise") {
              const TodayWorkout().launch(navigatorKey.currentContext!);
            } else if (message.data["type"] == "diet") {
              const DashboardScreen(mCurrentIndex: 2)
                  .launch(navigatorKey.currentContext!);
            } else if (message.data["type"] == "meditation") {
              const MeditationScreen().launch(navigatorKey.currentContext!);
            } else if (message.data["type"] == "water_intake") {
              await showModalBottomSheet(
                  isScrollControlled: true,
                  context: navigatorKey.currentContext!,
                  backgroundColor:
                      appStore.isDarkMode ? cardDarkColor : cardLightColor,
                  shape: RoundedRectangleBorder(
                      borderRadius: radiusOnly(topRight: 18, topLeft: 18)),
                  builder: (context) {
                    return ProgressComponent(
                      mType: METRICS_WATER,
                      mUnit: METRICS_WATER_UNIT,
                      onCall: () {},
                    );
                  });
            } else if (message.data["type"] == "weight") {
              showDialog(
                  context: navigatorKey.currentContext!,
                  builder: (context) =>
                      const ShowOneTimeDialog(showStartExercise: true));
            }
          },
        );
      } catch (e) {
        print(e);
      }
      showMsg(message);
    });
  }

  /// send notification device to device
  static Future<bool?> sendMessage({
    String? receiverFcmToken,
    String? msg,
    String? title,
  }) async {
    var serverKey =
        "AAAAjl2CRZk:APA91bEc1qUBYHB4TUBeZqSbyXE5fUtv7i8GidYIyeQ3QONX7FkHbhDUizwujAmJgIAoymMOIUKrNixugq95wjLcyPLri8TLhPHocpcVmjRow-nzvlFZ-r8v5qLRAh4APyptrIVM_mSH";
    try {
      await http.post(
        Uri.parse(
            'https://fcm.googleapis.com/v1/projects/myproject-b5ae1/messages:send'),
        headers: <String, String>{
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $serverKey',
        },
        body: jsonEncode(<String, dynamic>{
          "message": {
            "token": receiverFcmToken,
            "notification": {"title": title ?? '', "body": msg ?? 'msg'},
            "data": {}
          }
        }),
      );
    } catch (e) {
      if (kDebugMode) {
        print("error push notification");
      }
    }
    return null;
  }
}

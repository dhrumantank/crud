// Shared Pref
const IS_FIRST_TIME = 'IS_FIRST_TIME';
const IS_REMEMBER = 'IS_REMEMBER';
const FIRSTNAME = "FIRSTNAME";
const LASTNAME = "LASTNAME";
const EMAIL = "EMAIL";
const PASSWORD = "PASSWORD";
const IS_LOGIN = "IS_LOGIN";
const USER_ID = "USER_ID";
const USER_PROFILE_IMG = "USER_PROFILE_IMG";
const TOKEN = "TOKEN";
const TodayDateTime = "TodayDateTime";
const DISPLAY_NAME = "DISPLAY_NAME";
const PHONE_NUMBER = "PHONE_NUMBER";
const USERNAME = "USERNAME";
const GENDER = "GENDER";
const AGE = "AGE";
const HEIGHT = "HEIGHT";
const HEIGHT_UNIT = "HEIGHT_UNIT";
const WEIGHT = "WEIGHT";
const WEIGHT_UNIT = "WEIGHT_UNIT";
const IS_SOCIAL = "IS_SOCIAL";
const IS_OTP = "IS_OTP";
const NOTIFICATION_DETAIL = 'NOTIFICATION_DETAIL';
const PROGRESS_SETTINGS_DETAIL = 'PROGRESS_SETTINGS_DETAIL';

const COUNTRY_CODE = 'COUNTRY_CODE';

/* Theme Mode Type */
const ThemeModeLight = 0;
const ThemeModeDark = 1;
const ThemeModeSystem = 2;

/* METRICS */
const METRICS_WEIGHT = 'weight';
const METRICS_WEIGHT_UNIT = 'kg';
const METRICS_WATER = 'water';
const METRICS_WATER_UNIT = 'ml';
const METRICS_HEART_RATE = 'heart-rate';
const PUSH_UP_MIN = 'push-up-min';
const METRICS_HEART_UNIT = 'bpm';
const PUSH_UP_MIN_UNIT = 'Reps';
const METRICS_CM = 'cm';

/* Live Stream */
const PROGRESS = 'PROGRESS';
const TIMER = 'TIMER';
const PROGRESS_SETTING = 'PROGRESS_SETTING';
const PAYMENT = 'PAYMENT';

const LBS = 'lbs';
const FEET = 'feet';
const DURATION = 'duration';
const SETS = 'sets';
const TIME = 'time';

const IdealWeight = "idealweight";

const FONT_SIZE_PREF = 'FONT_SIZE_PREF';

class DefaultValues {
  final String defaultLanguage = 'en';
}

DefaultValues defaultValues = DefaultValues();

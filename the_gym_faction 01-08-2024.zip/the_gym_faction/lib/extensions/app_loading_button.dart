import 'package:TheGymFaction/extensions/colors.dart';
import 'package:TheGymFaction/extensions/constants.dart';
import 'package:TheGymFaction/extensions/extension_util/bool_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/string_extensions.dart';
import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/extensions/text_styles.dart';
import 'package:flutter/material.dart';

class AppLoadingButton extends StatefulWidget {
  const AppLoadingButton(
      {super.key,
      required this.isLoading,
      required this.onTap,
      this.child,
      this.text,
      this.textStyle,
      this.textColor,
      this.width,
      this.height,
      this.color});
  final bool isLoading;
  final void Function() onTap;
  final Widget? child;
  final String? text;
  final double? width;
  final double? height;
  final Color? color;
  final TextStyle? textStyle;
  final Color? textColor;

  @override
  State<AppLoadingButton> createState() => _AppLoadingButtonState();
}

class _AppLoadingButtonState extends State<AppLoadingButton>
    with SingleTickerProviderStateMixin {
  double _scale = 1.0;
  AnimationController? _controller;

  @override
  void initState() {
    if (true.validate(value: enableAppButtonScaleAnimationGlobal)) {
      _controller = AnimationController(
        vsync: this,
        duration: Duration(
          milliseconds: appButtonScaleAnimationDurationGlobal ?? 50,
        ),
        lowerBound: 0.0,
        upperBound: 0.1,
      )..addListener(() {
          setState(() {});
        });
    }
    super.initState();
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_controller != null && true.validate(value: true)) {
      _scale = 1 - _controller!.value;
    }

    if (true.validate(value: enableAppButtonScaleAnimationGlobal)) {
      return Listener(
        onPointerDown: (details) {
          _controller?.forward();
        },
        onPointerUp: (details) {
          _controller?.reverse();
        },
        child: Transform.scale(
          scale: _scale,
          child: buildButton(),
        ),
      );
    } else {
      return buildButton();
    }
  }

  Widget buildButton() {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: widget.isLoading ? () {} : widget.onTap,
      child: AnimatedContainer(
        alignment: Alignment.center,
        width: widget.isLoading ? 50 : widget.width ?? w * 0.4,
        height: widget.isLoading ? 50 : widget.height ?? h * 0.065,
        curve: Curves.easeInOutCubic,
        decoration: BoxDecoration(
          color: widget.color ?? black,
          borderRadius: widget.isLoading
              ? BorderRadius.circular(80)
              : BorderRadius.circular(10),
        ),
        duration: const Duration(milliseconds: 800),
        child: widget.isLoading
            ? SizedBox(
                height: 50,
                width: 50,
                child: const CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ).paddingSymmetric(horizontal: 10, vertical: 10),
              ).center()
            : widget.child ??
                (widget.text != null
                    ? Text(
                        widget.text!.validate(),
                        style: widget.textStyle ??
                            boldTextStyle(
                              color: widget.textColor ??
                                  defaultAppButtonTextColorGlobal,
                            ),
                      )
                    : const Text("")),
      ),
    );
  }
}

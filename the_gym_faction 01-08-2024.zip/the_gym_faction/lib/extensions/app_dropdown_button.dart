import 'package:TheGymFaction/extensions/extension_util/widget_extensions.dart';
import 'package:TheGymFaction/utils/app_colors.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';

class AppDropdownButton extends StatefulWidget {
  final List<dynamic> items;
  final void Function(dynamic)? onChanged;
  final dynamic selectedItem;
  final String? searchHintText;
  final String? hintText;
  AppDropdownButton({
    Key? key,
    required this.items,
    required this.onChanged,
    required this.selectedItem,
    this.searchHintText,
    this.hintText,
  }) : super(key: key);

  @override
  _AppDropdownButtonState createState() => _AppDropdownButtonState();
}

class _AppDropdownButtonState extends State<AppDropdownButton> {
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return DropdownSearch(
      items: widget.items,
      filterFn: (data, filerValue) {
        return data.toLowerCase().contains(filerValue.toLowerCase());
      },
      popupProps: PopupProps.menu(
        showSearchBox: true,
        searchFieldProps: TextFieldProps(
          decoration: InputDecoration(
            hintText: widget.searchHintText ?? "Search Gym Name",
            contentPadding: const EdgeInsets.only(left: 12, right: 12),
            constraints: BoxConstraints(maxHeight: h * 0.06, maxWidth: w),
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(
                width: 0.9,
                color: primaryColor,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(12),
            ),
            border: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey.shade200),
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
        itemBuilder: (context, item, isSelected) {
          return DropdownMenuItem(
            value: item,
            child: Text(item.toString()).paddingSymmetric(horizontal: 20),
          );
        },
      ),
      dropdownBuilder: (context, item) {
        return DropdownMenuItem(
          value: item,
          child: Text(
            item.toString(),
          ),
        );
      },
      dropdownButtonProps: DropdownButtonProps(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        constraints: BoxConstraints(maxHeight: h * 0.06, maxWidth: w),
        alignment: Alignment.center,
      ),
      dropdownDecoratorProps: DropDownDecoratorProps(
        textAlignVertical: TextAlignVertical.center,
        dropdownSearchDecoration: InputDecoration(
          hintText: widget.hintText ?? "Enter Your Gym Name",
          contentPadding: const EdgeInsets.only(left: 12, right: 12),
          constraints: BoxConstraints(maxHeight: h * 0.06, maxWidth: w),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(
              width: 0.9,
              color: primaryColor,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(12),
          ),
          border: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.grey.shade200),
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      selectedItem: widget.selectedItem,
      onChanged: widget.onChanged,
    );
  }
}

// num Extensions
import 'package:TheGymFaction/extensions/widgets.dart';
import 'package:TheGymFaction/main.dart';
import 'package:flutter/material.dart';

import '../../models/exercise_detail_response.dart';

extension NumExt on num? {
  /// Validate given double is not null and returns given value if null.
  num validate({num value = 0}) => this ?? value;
}

class UpdateButton extends StatefulWidget {
  const UpdateButton({super.key, required this.snapshot});
  final AsyncSnapshot<ExerciseDetailResponse> snapshot;

  @override
  State<UpdateButton> createState() => _UpdateButtonState();
}

class _UpdateButtonState extends State<UpdateButton> {
  @override
  void initState() {
    updateValue(true);
    print("6666666666666666666666666666666666666666666666");
    super.initState();
  }

  void updateValue(bool value) {
    if (mounted) setState(() => appStore.setLoading(value));
  }

  @override
  void setState(VoidCallback fn) {
    if (mounted) {
      super.setState(fn);
    }
  }

  @override
  void dispose() {
    updateValue(false);
    print("555555555555555555555555555555555555555555555");
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return snapWidgetHelper(widget.snapshot);
  }
}

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../../extensions/extension_util/string_extensions.dart';
import '../../extensions/extension_util/widget_extensions.dart';
import '../extensions/extension_util/int_extensions.dart';
import '../extensions/shared_pref.dart';
import '../main.dart';
import '../network/rest_api.dart';
import '../screens/dashboard_screen.dart';
import '../utils/app_common.dart';
import '../utils/app_constants.dart';

void socialLogin(req, BuildContext context) async {
  appStore.setLoading(true);
  return await socialLogInApi(req).then((res) async {
    appStore.setLoading(false);
    await userStore.setUserID(res.data!.id.validate());
    await userStore.setFirstName(res.data!.firstName.validate());
    await userStore.setLastName(res.data!.lastName.validate());
    await userStore.setGender(res.data!.gender.validate());
    await userStore.setToken(res.data!.apiToken.validate());
    await userStore.setLogin(true);
    await userStore.setUserEmail(res.data!.email.validate());
    await userStore.setUsername(res.data!.email.validate());
    await userStore.setUserImage(res.data!.profileImage.validate());
    await userStore.setDisplayName(res.data!.displayName.validate());
    await userStore.setPhoneNo(res.data!.phoneNumber.validate());
    getUSerDetail(context, res.data!.id.validate()).then((value) {
      const DashboardScreen().launch(context, isNewTask: true);
    }).catchError((e) {
      if (kDebugMode) {
        print("error=>$e");
      }
    });
  }).catchError((error) {
    appStore.setLoading(false);
    toast(error.toString());
  });
}

Future<void> logout(BuildContext context, {Function? onLogout}) async {
  await removeKey(IS_LOGIN);
  await removeKey(USER_ID);
  await removeKey(FIRSTNAME);
  await removeKey(LASTNAME);
  await removeKey(USER_PROFILE_IMG);
  await removeKey(DISPLAY_NAME);
  await removeKey(PHONE_NUMBER);
  await removeKey(GENDER);
  await removeKey(AGE);
  await removeKey(HEIGHT);
  await removeKey(HEIGHT_UNIT);
  await removeKey(IS_OTP);
  await removeKey(IS_SOCIAL);
  await removeKey(WEIGHT);
  await removeKey(WEIGHT_UNIT);
  await userStore.setAge('');
  await userStore.setHeight('');
  await userStore.setWeight('');
  await userStore.clearUserData();
  if (getBoolAsync(IS_SOCIAL) ||
      !getBoolAsync(IS_REMEMBER) ||
      getBoolAsync(IS_OTP) == true) {
    await removeKey(PASSWORD);
    await removeKey(EMAIL);
  }
  userStore.setLogin(false);
  onLogout?.call();
}

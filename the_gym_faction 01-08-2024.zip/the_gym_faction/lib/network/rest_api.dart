import 'dart:convert';

import 'package:TheGymFaction/models/user_account_blocked_check_model.dart';
import 'package:http/http.dart';

import '../../extensions/extension_util/int_extensions.dart';
import '../../extensions/extension_util/string_extensions.dart';
import '../../models/category_diet_response.dart';
import '../../models/exercise_response.dart';
import '../../models/graph_response.dart';
import '../../models/level_response.dart';
import '../extensions/shared_pref.dart';
import '../main.dart';
import '../models/app_configuration_response.dart';
import '../models/app_setting_response.dart';
import '../models/base_response.dart';
import '../models/blog_detail_response.dart';
import '../models/blog_response.dart';
import '../models/body_part_response.dart';
import '../models/book_reading_response.dart';
import '../models/daily_workout_charts_model.dart';
import '../models/dashboard_response.dart';
import '../models/day_exercise_response.dart';
import '../models/diet_history_response.dart';
import '../models/diet_list_model.dart';
import '../models/diet_response.dart';
import '../models/equipment_response.dart';
import '../models/exercise_detail_response.dart';
import '../models/exercise_history_model.dart';
import '../models/fast_intake_response.dart';
import '../models/get_setting_response.dart';
import '../models/gym_all_details_model.dart';
import '../models/gym_owner_list_response.dart';
import '../models/login_response.dart';
import '../models/login_user_response.dart';
import '../models/meditation_response.dart';
import '../models/notification_response.dart';
import '../models/notification_setting_model.dart';
import '../models/payment_list_model.dart';
import '../models/product_category_response.dart';
import '../models/product_response.dart';
import '../models/social_login_response.dart';
import '../models/splash_screen_response.dart';
import '../models/subscribe_package_response.dart';
import '../models/subscription_response.dart';
import '../models/today_exercises_model.dart';
import '../models/user_app_version_check_response.dart';
import '../models/user_exercise_list_model.dart';
import '../models/user_gym_details.dart';
import '../models/user_response.dart';
import '../models/user_target_details_model.dart';
import '../models/water_intake_data_response.dart';
import '../models/weight_graph_model.dart';
import '../models/workout_days_history_model.dart';
import '../models/workout_detail_response.dart';
import '../models/workout_response.dart';
import '../models/workout_type_response.dart';
import '../utils/app_common.dart';
import '../utils/app_config.dart';
import '../utils/app_constants.dart';
import 'network_utils.dart';

Future<void> saveUserData(LoginUserData? userModel) async {
  if (userModel!.token.validate().isNotEmpty) {
    await userStore.setToken(userModel.token.validate());
  }
  setValue(IS_SOCIAL, false);

  await userStore.setToken(userModel.token.validate());
  await userStore.setUserID(userModel.data!.id.validate());
  await userStore.setUserEmail(userModel.data!.email.validate());
  await userStore.setFirstName(userModel.data!.firstName.validate());
  await userStore.setLastName(userModel.data!.lastName.validate());
  await userStore.setUsername(userModel.data!.username.validate());
  await userStore.setUserImage(userModel.data!.profileImage.validate());
  await userStore.setDisplayName(userModel.data!.displayName.validate());
  await userStore.setPhoneNo(userModel.data!.phoneNumber.validate());
  await userStore.setGender(userModel.data!.gender.validate());
  await userStore.setAge(userModel.data!.age.validate());
  await userStore.setHeight(userModel.data!.height.validate());
  await userStore.setHeightUnit(userModel.data!.heightUnit.validate());
  await userStore.setWeight(userModel.data!.weight.validate());
  await userStore.setWeightUnit(userModel.data!.weightUnit.validate());
  setLogInValue();
}

Future<SocialLoginResponse> socialLogInApi(Map req) async {
  return SocialLoginResponse.fromJson(await handleResponse(
      await buildHttpResponse('social-mail-login',
          request: req, method: HttpMethod.POST)));
}

Future<LoginUserData> loginWithPhoneNumber(request) async {
  Response response = await buildHttpResponse('loginUser',
      request: request, method: HttpMethod.POST);
  if (response.statusCode == 200) {
    var json = jsonDecode(response.body);
    if (json["success"] == false) {
      toast(json["message"]);
    } else {
      // Map<String, dynamic> request = {
      //   "username": json["data"]["username"],
      //   "email": json["data"]["email"]
      // };
      // getUserAllData(request, json["token"]);
    }
  } else {
    toast("Incorrect Credentials!");
  }

  return await handleResponse(response).then((value) async {
    LoginUserData loginResponse = LoginUserData.fromJson(value);
    saveUserData(loginResponse);
    await userStore.setLogin(true);
    return loginResponse;
  });
}

Future<UserResponse?> getUserAllData(request, String token) async {
  UserResponse? userResponse;

  Response response = await userGetResponse(request, token);
  if (response.statusCode == 200) {
    var json = jsonDecode(response.body);
    userResponse = UserResponse.fromJson(json);
  } else {
    toast("Incorrect Credentials!");
  }

  if (userResponse != null) {
    await userStore.setAge(userResponse.data!.userProfile!.age.validate());
    await userStore
        .setHeight(userResponse.data!.userProfile!.height.validate());
    await userStore
        .setHeightUnit(userResponse.data!.userProfile!.heightUnit.validate());
    await userStore
        .setWeight(userResponse.data!.userProfile!.weight.validate());
    await userStore
        .setWeightUnit(userResponse.data!.userProfile!.weightUnit.validate());
  }
  return userResponse;
}

Future<SocialLoginResponse> socialOtpLogInApi(Map req) async {
  return SocialLoginResponse.fromJson(await handleResponse(
      await buildHttpResponse('social-otp-login',
          request: req, method: HttpMethod.POST)));
}

Future<SplashScreenResponse> getSplashScreenApi() async {
  return SplashScreenResponse.fromJson(
    await handleResponse(
      await buildHttpResponse('splash_screen', method: HttpMethod.GET),
    ),
  );
}

Future<FitnessBaseResponse> changePwdApi(Map req) async {
  return FitnessBaseResponse.fromJson(await handleResponse(
      await buildHttpResponse('change-password',
          request: req, method: HttpMethod.POST)));
}

Future<FitnessBaseResponse> forgotPwdApi(Map req) async {
  return FitnessBaseResponse.fromJson(await handleResponse(
      await buildHttpResponse('forget-password',
          request: req, method: HttpMethod.POST)));
}

Future deleteUserAccountApi() async {
  return await handleResponse(
    await buildHttpResponse('delete_user', method: HttpMethod.POST),
  );
}

Future<LoginResponse> registerApi(Map req) async {
  return LoginResponse.fromJson(await handleResponse(await buildHttpResponse(
      'register',
      request: req,
      method: HttpMethod.POST)));
}

Future<LoginResponse> updateProfileApi(Map req) async {
  return LoginResponse.fromJson(await handleResponse(await buildHttpResponse(
      'update-profile',
      request: req,
      method: HttpMethod.POST)));
}

Future<BodyPartResponse> getBodyPartApi(int? page) async {
  return BodyPartResponse.fromJson(await (handleResponse(
      await buildHttpResponse("bodypart-list?page=$page",
          method: HttpMethod.GET))));
}

Future<UserExerciseList> getUserExerciseListApi() async {
  return UserExerciseList.fromJson(await (handleResponse(
    await buildHttpResponse("user_exercise_list", method: HttpMethod.GET),
  )));
}

Future<TodayExercises> getTodayExercisesApi(Map req) async {
  return TodayExercises.fromJson(
    await (handleResponse(
      await buildHttpResponse(
        "today_workout_new",
        request: req,
        method: HttpMethod.POST,
      ),
    )),
  );
  return TodayExercises.fromJson(
    await (handleResponse(
      await buildHttpResponse(
        "today_workout",
        request: req,
        method: HttpMethod.POST,
      ),
    )),
  );
}

Future<TodayExercises> getRemainingExerciseApi() async {
  return TodayExercises.fromJson(
    await (handleResponse(
      await buildHttpResponse(
        "remaining_exercise_new",
        method: HttpMethod.GET,
      ),
    )),
  );
  return TodayExercises.fromJson(
    await (handleResponse(
      await buildHttpResponse(
        "remaining_exercise",
        method: HttpMethod.GET,
      ),
    )),
  );
}

Future<DietHistoryResponse> getDietHistoryApi(int page) async {
  return DietHistoryResponse.fromJson(
    await (handleResponse(
      await buildHttpResponse(
        "diet_history_new?page=$page",
        method: HttpMethod.GET,
      ),
    )),
  );
  return DietHistoryResponse.fromJson(
    await (handleResponse(
      await buildHttpResponse(
        "diet_history",
        method: HttpMethod.GET,
      ),
    )),
  );
}

Future getUpdateUserExerciseApi(Map req) async {
  return await (handleResponse(
    await buildHttpResponse(
      "update_user_workout",
      request: req,
      method: HttpMethod.POST,
    ),
  ));
}

Future<TodayExercises> getCompleteWorkoutApi(Map req) async {
  return TodayExercises.fromJson(
    await (handleResponse(
      await buildHttpResponse(
        "complete_workout",
        request: req,
        method: HttpMethod.POST,
      ),
    )),
  );
}

Future<WorkoutDaysHistory> getWorkoutDaysHistoryApi(Map req) async {
  return WorkoutDaysHistory.fromJson(
    await (handleResponse(
      await buildHttpResponse(
        "workout_days_history_new",
        request: req,
        method: HttpMethod.POST,
      ),
    )),
  );
  return WorkoutDaysHistory.fromJson(
    await (handleResponse(
      await buildHttpResponse(
        "workout_days_history",
        request: req,
        method: HttpMethod.POST,
      ),
    )),
  );
}

Future<EquipmentResponse2> getEquipmentListApi(
    {required int page, int? mPerPage = EQUIPMENT_PER_PAGE}) async {
  return EquipmentResponse2.fromJson(await (handleResponse(
      await buildHttpResponse("user_equipment_list?page=$page",
          method: HttpMethod.GET))));

  //"equipment-list?page=$page"
}

Future<WorkoutResponse> getWorkoutListApi(bool? isFav, bool? isAssign,
    {int? page = 1}) async {
  if (isAssign == true) {
    return WorkoutResponse.fromJson(await handleResponse(
        await buildHttpResponse('assign-workout-list?page=$page',
            method: HttpMethod.GET)));
  } else {
    if (isFav != true) {
      return WorkoutResponse.fromJson(await (handleResponse(
          await buildHttpResponse("workout-list?page=$page",
              method: HttpMethod.GET))));
    } else {
      return WorkoutResponse.fromJson(await handleResponse(
          await buildHttpResponse('get-favourite-workout?page=$page',
              method: HttpMethod.GET)));
    }
  }
}

Future<WorkoutTypeResponse> getWorkoutTypeListApi(
    {int mPerPage = WORKOUT_TYPE_PAGE}) async {
  return WorkoutTypeResponse.fromJson(await (handleResponse(
      await buildHttpResponse("workouttype-list", method: HttpMethod.GET))));
}

Future<LevelResponse> getLevelListApi(
    {int? page = 1, int mPerPage = LEVEL_PER_PAGE}) async {
  return LevelResponse.fromJson(await (handleResponse(await buildHttpResponse(
      "level-list?page=$page",
      method: HttpMethod.GET))));
}

Future<BlogResponse> getBlogApi(String? isFeatured, {int? page = 1}) async {
  return BlogResponse.fromJson(await (handleResponse(await buildHttpResponse(
      "post-list?is_featured=$isFeatured&page=$page",
      method: HttpMethod.GET))));
}

Future<GymAllDetails> getGymAllDetailsApi() async {
  return GymAllDetails.fromJson(await (handleResponse(
      await buildHttpResponse("gym_all_details", method: HttpMethod.GET))));
}

Future<ExerciseHistoryResponse> getExerciseHistoryApi(int page) async {
  return ExerciseHistoryResponse.fromJson(await (handleResponse(
      await buildHttpResponse("user_exercise_history_new?page=$page",
          method: HttpMethod.GET))));
  return ExerciseHistoryResponse.fromJson(await (handleResponse(
      await buildHttpResponse("exercise_history_new?page=$page",
          method: HttpMethod.GET))));
  return ExerciseHistoryResponse.fromJson(await (handleResponse(
      await buildHttpResponse("exercise_history", method: HttpMethod.GET))));
}

Future<BlogResponse> getSearchBlogApi({String? mSearch = ""}) async {
  return BlogResponse.fromJson(await (handleResponse(await buildHttpResponse(
      "post-list?title=$mSearch",
      method: HttpMethod.GET))));
}

Future<BlogDetailResponse> getBlogDetailApi(Map req) async {
  return BlogDetailResponse.fromJson(await (handleResponse(
      await buildHttpResponse("post-detail",
          request: req, method: HttpMethod.POST))));
}

Future<DietResponse> getDietApi(String? isFeatured, bool? isCategory,
    {int? page = 1,
    bool? isAssign = false,
    bool? isFav = false,
    int? categoryId}) async {
  if (isFav == true) {
    return DietResponse.fromJson(await (handleResponse(await buildHttpResponse(
        "get-favourite-diet?page=$page",
        method: HttpMethod.GET))));
  } else if (isAssign == true) {
    return DietResponse.fromJson(await (handleResponse(await buildHttpResponse(
        "assign-diet-list?page=$page",
        method: HttpMethod.GET))));
  } else if (isCategory == true) {
    return DietResponse.fromJson(await (handleResponse(await buildHttpResponse(
        "diet-list?categorydiet_id=$categoryId&page=$page",
        method: HttpMethod.GET))));
  } else {
    return DietResponse.fromJson(await (handleResponse(await buildHttpResponse(
        "diet-list?is_featured=$isFeatured&page=$page",
        method: HttpMethod.GET))));
  }
}

Future<CategoryDietResponse> getDietCategoryApi({int page = 1}) async {
  return CategoryDietResponse.fromJson(await (handleResponse(
      await buildHttpResponse("categorydiet-list?page=$page",
          method: HttpMethod.GET))));
}

Future<DashboardResponse> getDashboardApi() async {
  return DashboardResponse.fromJson(await handleResponse(
      await buildHttpResponse('dashboard-detail', method: HttpMethod.GET)));
}

Future<UserGymDetails> getUserGymDetailsApi() async {
  return UserGymDetails.fromJson(await handleResponse(
      await buildHttpResponse('gym_details', method: HttpMethod.GET)));
}

Future<DailyWorkoutCharts> getDailyWorkoutChartsResponse() async {
  return DailyWorkoutCharts.fromJson(await handleResponse(
      await buildHttpResponse('daily_workout_charts', method: HttpMethod.GET)));
}

Future<WeightGraphResponse> getUserDeleteResponse() async {
  return WeightGraphResponse.fromJson(await handleResponse(
      await buildHttpResponse('check_user', method: HttpMethod.GET)));
}

Future<UserAppVersionCheckResponse> getUserAppVersionCheckApi() async {
  return UserAppVersionCheckResponse.fromJson(await handleResponse(
      await buildHttpResponse('user_app_version_check',
          method: HttpMethod.GET)));
}

Future<UserAccountBlockedCheckResponse> userAccountBlockedCheckApi() async {
  return UserAccountBlockedCheckResponse.fromJson(await handleResponse(
      await buildHttpResponse('user_check_status', method: HttpMethod.GET)));
}

Future<WeightGraphResponse> getWeightGraphResponse() async {
  return WeightGraphResponse.fromJson(await handleResponse(
      await buildHttpResponse('weight', method: HttpMethod.GET)));
}

Future<WeightGraphResponse> getWaterGraphResponse() async {
  return WeightGraphResponse.fromJson(await handleResponse(
      await buildHttpResponse('water', method: HttpMethod.GET)));
}

Future getEditExerciseSetsResponse(Map req) async {
  return await handleResponse(await buildHttpResponse('edit_exercise_sets',
      method: HttpMethod.POST, request: req));
}

Future setEditExercisesDurationResponse(Map req) async {
  return await handleResponse(
    await buildHttpResponse(
      'exercise_duration_update_new',
      method: HttpMethod.POST,
      request: req,
    ),
  );
  return await handleResponse(
    await buildHttpResponse(
      'exercise_duration_update',
      method: HttpMethod.POST,
      request: req,
    ),
  );
}

Future<GymOwnerList> getGymOwnerListApi() async {
  return GymOwnerList.fromJson(await handleResponse(
      await buildHttpResponse('gym_owner_list', method: HttpMethod.GET)));
}

Future<ExerciseResponse> getExerciseApi(
    {int? page,
    String? mSearchValue = " ",
    bool? isBodyPart = false,
    int? id,
    bool? isLevel = false,
    bool? isEquipment = false,
    var ids,
    bool? isFilter = false}) async {
  if (mSearchValue.isEmptyOrNull) {
    if (isBodyPart == true) {
      return ExerciseResponse.fromJson(await handleResponse(
          await buildHttpResponse(
              'exercise_list_exercise_new?bodypart_id=$id&page=$page',
              method: HttpMethod.GET)));
      return ExerciseResponse.fromJson(await handleResponse(
          await buildHttpResponse(
              'exercise-list_new?bodypart_id=$id&page=$page',
              method: HttpMethod.GET)));
      return ExerciseResponse.fromJson(await handleResponse(
          await buildHttpResponse('exercise-list?bodypart_id=$id&page=$page',
              method: HttpMethod.GET)));
    } else if (isEquipment == true) {
      return ExerciseResponse.fromJson(await handleResponse(await buildHttpResponse(
          'exercise-list?equipment_id=${isFilter == true ? ids : id}&page=$page',
          method: HttpMethod.GET)));
    } else if (isLevel == true) {
      return ExerciseResponse.fromJson(await handleResponse(
          await buildHttpResponse(
              'exercise-list?level_ids=${isFilter == true ? ids : id}&page=$page',
              method: HttpMethod.GET)));
    } else {
      return ExerciseResponse.fromJson(await handleResponse(
          await buildHttpResponse('exercise-list?page=$page',
              method: HttpMethod.GET)));
    }
  } else {
    if (isBodyPart == true) {
      return ExerciseResponse.fromJson(await handleResponse(
          await buildHttpResponse(
              'exercise-list?bodypart_id=$id&title=$mSearchValue',
              method: HttpMethod.GET)));
    } else if (isEquipment == true) {
      return ExerciseResponse.fromJson(await handleResponse(await buildHttpResponse(
          'exercise-list?equipment_id=${isFilter == true ? ids : id}&title=$mSearchValue',
          method: HttpMethod.GET)));
    } else if (isLevel == true) {
      return ExerciseResponse.fromJson(await handleResponse(await buildHttpResponse(
          'exercise-list?level_ids=${isFilter == true ? ids : id}&title=$mSearchValue',
          method: HttpMethod.GET)));
    } else {
      return ExerciseResponse.fromJson(await handleResponse(
          await buildHttpResponse('exercise-list?title=$mSearchValue',
              method: HttpMethod.GET)));
    }
  }
}

Future<ExerciseDetailResponse> geExerciseDetailApi(int? id) async {
  return ExerciseDetailResponse.fromJson(await handleResponse(
      await buildHttpResponse('exercise-detail-new?id=$id',
          method: HttpMethod.GET)));
  return ExerciseDetailResponse.fromJson(await handleResponse(
      await buildHttpResponse('exercise-detail?id=$id',
          method: HttpMethod.GET)));
}

Future<FitnessBaseResponse> setDietFavApi(Map req) async {
  return FitnessBaseResponse.fromJson(await handleResponse(
      await buildHttpResponse('set-favourite-diet',
          request: req, method: HttpMethod.POST)));
}

Future<FastIntakeResponse> getFastIntakeApi() async {
  return FastIntakeResponse.fromJson(await handleResponse(
      await buildHttpResponse('fast_intake', method: HttpMethod.GET)));
}

Future<MeditationResponse> getMeditationApi() async {
  return MeditationResponse.fromJson(await handleResponse(
      await buildHttpResponse('meditation', method: HttpMethod.GET)));
}

Future setStartMeditationApi(Map req) async {
  return await handleResponse(await buildHttpResponse(
    'start_meditation',
    request: req,
    method: HttpMethod.POST,
  ));
}

Future<MeditationHistory> getMeditationHistoryApi() async {
  return MeditationHistory.fromJson(await handleResponse(
      await buildHttpResponse('meditation-history', method: HttpMethod.GET)));
}

Future<BookReadingResponse> getBookReadingApi() async {
  return BookReadingResponse.fromJson(await handleResponse(
      await buildHttpResponse('book-reading', method: HttpMethod.GET)));
}

Future<BookHistoryResponse> getBookHistoryApi() async {
  return BookHistoryResponse.fromJson(await handleResponse(
      await buildHttpResponse('book-history', method: HttpMethod.GET)));
}

Future getCreateBookApi(Map req) async {
  return await handleResponse(await buildHttpResponse(
    'create-book',
    method: HttpMethod.POST,
    request: req,
  ));
}

Future<FastIntakeHistory> getFastHistoryApi() async {
  return FastIntakeHistory.fromJson(await handleResponse(
      await buildHttpResponse('fast_history', method: HttpMethod.GET)));
}

Future setStartFastApi(Map req) async {
  return await handleResponse(await buildHttpResponse(
    'start_fast',
    request: req,
    method: HttpMethod.POST,
  ));
}

Future<UserTargetDetails> getUserTargetDetailsApi() async {
  return UserTargetDetails.fromJson(await handleResponse(
      await buildHttpResponse('user_diet_target_details',
          method: HttpMethod.GET)));
}

Future<UserTargetDetails> getUserDietTargetDetailsEditApi() async {
  return UserTargetDetails.fromJson(await handleResponse(
      await buildHttpResponse('user_diet_target_details_edit',
          method: HttpMethod.GET)));
}

Future<UserDietTargetDetailsShow> getUserDietTargetDetailsShowApi() async {
  return UserDietTargetDetailsShow.fromJson(await handleResponse(
      await buildHttpResponse('user_diet_target_details_show',
          method: HttpMethod.GET)));
}

Future setUserDietTargetDetailsUpdateApi(Map req) async {
  return await handleResponse(await buildHttpResponse(
    'user_diet_target_details_update',
    request: req,
    method: HttpMethod.POST,
  ));
}

Future<NotificationSettingResponse> getReminderTypeApi() async {
  return NotificationSettingResponse.fromJson(await handleResponse(
      await buildHttpResponse('reminder_type', method: HttpMethod.GET)));
}

Future setUpdateDietCategoryReminderApi(Map req) async {
  return await handleResponse(await buildHttpResponse(
    'update_diet_category_Reminder',
    request: req,
    method: HttpMethod.POST,
  ));
}

Future setDietConsumedApi(Map req) async {
  return await handleResponse(await buildHttpResponse(
    'diet_consumed',
    request: req,
    method: HttpMethod.POST,
  ));
}

Future<ProductCategoryResponse> getProductCategoryApi({int? page = 1}) async {
  return ProductCategoryResponse.fromJson(await (handleResponse(
      await buildHttpResponse("productcategory-list?page=$page",
          method: HttpMethod.GET))));
}

Future<ProductResponse> getProductApi(
    {bool? isCategory = false,
    String? mSearch = "",
    int? productId,
    int? page = 1}) async {
  if (isCategory == true) {
    return ProductResponse.fromJson(await (handleResponse(
        await buildHttpResponse("product-list?productcategory_id=$productId",
            method: HttpMethod.GET))));
  } else {
    if (mSearch.isEmptyOrNull) {
      return ProductResponse.fromJson(await (handleResponse(
          await buildHttpResponse("product-list?page=$page",
              method: HttpMethod.GET))));
    } else {
      return ProductResponse.fromJson(await (handleResponse(
          await buildHttpResponse("product-list?title=$mSearch",
              method: HttpMethod.GET))));
    }
  }
}

Future<UserResponse> getUserDataApi({int? id}) async {
  return UserResponse.fromJson(await (handleResponse(
      await buildHttpResponse("user-detail?id=$id", method: HttpMethod.GET))));
}

Future<WorkoutDetailResponse> getWorkoutDetailApi(int? id) async {
  return WorkoutDetailResponse.fromJson(await (handleResponse(
      await buildHttpResponse("workout-detail?id=$id",
          method: HttpMethod.GET))));
}

Future<WorkoutResponse> getWorkoutFilterListApi(
    {int? page = 1,
    int? id,
    bool? isFilter,
    var ids,
    bool? isLevel = false,
    bool? isType}) async {
  if (isType == true) {
    return WorkoutResponse.fromJson(await handleResponse(
        await buildHttpResponse(
            'workout-list?workout_type_id=${isFilter == true ? ids : id}',
            method: HttpMethod.GET)));
  } else if (isLevel == true) {
    return WorkoutResponse.fromJson(await handleResponse(
        await buildHttpResponse(
            'workout-list?level_ids=${isFilter == true ? ids : id}',
            method: HttpMethod.GET)));
  } else {
    return WorkoutResponse.fromJson(await (handleResponse(
        await buildHttpResponse('workout-list?page=$page',
            method: HttpMethod.GET))));
  }
}

Future<DayExerciseResponse> getDayExerciseApi(int? id) async {
  return DayExerciseResponse.fromJson(await (handleResponse(
      await buildHttpResponse("workoutday-exercise-list?workout_day_id=$id",
          method: HttpMethod.GET))));
}

Future<FitnessBaseResponse> setWorkoutFavApi(Map req) async {
  return FitnessBaseResponse.fromJson(await handleResponse(
      await buildHttpResponse('set-favourite-workout',
          request: req, method: HttpMethod.POST)));
}

Future<DietResponse> getDietFavApi() async {
  return DietResponse.fromJson(await handleResponse(await buildHttpResponse(
      'get-favourite-workout',
      method: HttpMethod.GET)));
}

Future<FitnessBaseResponse> setProgressApi(Map req) async {
  return FitnessBaseResponse.fromJson(await handleResponse(
      await buildHttpResponse('usergraph-save',
          request: req, method: HttpMethod.POST)));
}

Future<FitnessBaseResponse> deleteProgressApi(Map req) async {
  return FitnessBaseResponse.fromJson(await handleResponse(
      await buildHttpResponse('usergraph-delete',
          request: req, method: HttpMethod.POST)));
}

Future<GraphResponse> getProgressApi(String? type,
    {int? page = 1, String? isFilterType, bool? isFilter = false}) async {
  if (isFilter == true) {
    return GraphResponse.fromJson(await handleResponse(await buildHttpResponse(
        'usergraph-list?type=$type&page=$page&duration=$isFilterType',
        method: HttpMethod.GET)));
  } else {
    return GraphResponse.fromJson(await handleResponse(await buildHttpResponse(
        'usergraph-list?type=$type&page=$page',
        method: HttpMethod.GET)));
  }
}

Future<AppSettingResponse> getAppSettingApi() async {
  return AppSettingResponse.fromJson(await handleResponse(
      await buildHttpResponse('get-appsetting', method: HttpMethod.GET)));
}

Future<DietListResponse> getDietListResponseApi() async {
  return DietListResponse.fromJson(await handleResponse(
      await buildHttpResponse('diet_list', method: HttpMethod.GET)));
}

Future getRefreshDietApi(Map req) async {
  return await handleResponse(
    await buildHttpResponse(
      'refresh_diet',
      method: HttpMethod.POST,
      request: req,
    ),
  );
}

Future<GetSettingResponse> getSettingApi() async {
  return GetSettingResponse.fromJson(await handleResponse(
      await buildHttpResponse('get-setting', method: HttpMethod.GET)));
}

// Start Dashboard region
Future<AppConfigurationResponse> getAppConfiguration() async {
  var it = await handleResponse(await buildHttpResponse(
      'mightyblogger/api/v1/blogger/get-configuration',
      method: HttpMethod.GET));
  return AppConfigurationResponse.fromJson(it);
}

//subscription
Future<SubscriptionResponse> getSubscription() async {
  return SubscriptionResponse.fromJson(await (handleResponse(
      await buildHttpResponse("package-list", method: HttpMethod.GET))));
}

Future<SubscribePackageResponse> subscribePackageApi(Map req) async {
  return SubscribePackageResponse.fromJson(await handleResponse(
      await buildHttpResponse('subscribe-package',
          request: req, method: HttpMethod.POST)));
}

// Future<SubscriptionPlanResponse> getSubScriptionPlanList({int page = 2}) async {
//   return SubscriptionPlanResponse.fromJson(await (handleResponse(
//       await buildHttpResponse("subscriptionplan-list?page=$page",
//           method: HttpMethod.GET))));
// }

Future<SubscribePackageResponse> cancelPlanApi(Map req) async {
  return SubscribePackageResponse.fromJson(await handleResponse(
      await buildHttpResponse('cancel-subscription',
          request: req, method: HttpMethod.POST)));
}

Future<PaymentListModel> getPaymentApi() async {
  return PaymentListModel.fromJson(await handleResponse(
      await buildHttpResponse('payment-gateway-list', method: HttpMethod.GET)));
}

Future<DietResponse> getSearchDietApi({String? mSearch = ""}) async {
  return DietResponse.fromJson(await (handleResponse(await buildHttpResponse(
      "diet-list?title=$mSearch",
      method: HttpMethod.GET))));
}

Future<DietModel> getSearchDietListApi() async {
  return DietModel.fromJson(await (handleResponse(
      await buildHttpResponse("diet-list", method: HttpMethod.GET))));
}

Future<NotificationResponse> notificationApi() async {
  return NotificationResponse.fromJson(await handleResponse(
      await buildHttpResponse('notification-list', method: HttpMethod.POST)));
}

Future<NotificationResponse> notificationStatusApi(String? id) async {
  return NotificationResponse.fromJson(await handleResponse(
      await buildHttpResponse('notification-detail?id=$id',
          method: HttpMethod.GET)));
}

Future<WaterIntakeDataResponse> getWaterIntakeDataApi() async {
  return WaterIntakeDataResponse.fromJson(
    await handleResponse(
      await buildHttpResponse('water_intake_data', method: HttpMethod.GET),
    ),
  );
}
